﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using br.procon.si.Core.Data.Dapper;
using System.Data.SqlClient;
using System.Configuration;




namespace br.procon.si.Core.Data.Tests
{
    [TestClass]
    public class DapperUnitOfWorkTest
    {

        private DapperUnitOfWork uow;

        private string conexao = ConfigurationManager.ConnectionStrings[ConfigurationManager.ConnectionStrings.Count - 1].ConnectionString;


        [TestCategory("Data"),TestCategory("Core"),TestCategory("Unitario"), TestCategory("Dapper"),TestMethod]
        public void UnitofWork_ExecutarAcoes_ValidarCommit()
        {
            //ARRANGE
            uow = new DapperUnitOfWork(conexao);
            //ACT 
            uow.BeginTransaction();
            const string proc = "administrativo.pr_incluir_municipio"; // HACK criada proc em dbo para atender os testes
            var retorno1 = uow.Get<int>(proc,
                new SqlParameter("@ds_cidade", "cidade1"),
                new SqlParameter("@ds_estado", "SP"));
            var retorno2 = uow.Get<int>(proc,
               new SqlParameter("@ds_cidade", "cidade2"),
               new SqlParameter("@ds_estado", "RJRJ"));
            uow.SaveChanges();
            //ASSERT
            uow = null;
            Assert.IsTrue(retorno2 > retorno1);
        }

        [TestCategory("Data"), TestCategory("Core"), TestCategory("Unitario"), TestCategory("Dapper"), TestMethod]
        public void UnitofWork_ExecutarAcoes_ValidarCommitExecutandoDispose()
        {
            //ARRANGE
            uow = new DapperUnitOfWork(conexao);
            //ACT 
            uow.BeginTransaction();
            const string proc = "administrativo.pr_incluir_municipio"; // HACK criada proc em dbo para atender os testes
            var retorno1 = uow.Get<int>(proc,
                new SqlParameter("@ds_cidade", "cidade3"),
                new SqlParameter("@ds_estado", "SP"));
            var retorno2 = uow.Get<int>(proc,
               new SqlParameter("@ds_cidade", "cidade4"),
               new SqlParameter("@ds_estado", "RJRJ"));
            uow.SaveChanges();
            //ASSERT
            uow.Dispose();
            Assert.IsTrue(retorno2 > retorno1);
            Assert.IsNull(((DapperUnitOfWork) uow).Connection);
        }


        [TestCategory("Data"), TestCategory("Core"), TestCategory("Unitario"), TestCategory("Dapper"), TestMethod]

        public void UnitofWork_ExecutarAcoesComUmaFalha_ValidarDesfazerAcoes()
        {
            //ARRANGE
            uow = new DapperUnitOfWork(conexao);
            Exception erro =null;
            //ACT 
            try
            {
                uow.BeginTransaction();
                var proc1 = "dd";
                const string proc = "administrativo.pr_incluir_municipio"; // HACK criada proc em dbo para atender os testes
                uow.Get<int>(proc,
                    new SqlParameter("@ds_cidade", "cidade5"),
                    new SqlParameter("@ds_estado", "SP"));
                uow.Get<int>(proc1,
                   new SqlParameter("@ds_cidade", "cidade6"),
                   new SqlParameter("@ds_estado", "SPSPSP"));
                uow.SaveChanges();
            }
            catch(Exception ex)
            {
                erro = ex;
            }
            finally
            {
                uow = null;
            }
            //ASSERT
            Assert.IsNotNull(erro);
        }

        //[TestCategory("Data"), TestCategory("Core"), TestCategory("Unitario"),TestCategory("Dapper"),TestMethod]
        public void UnitofWork_ExecutarAcaoSemTransacao_Validar()
        {
            //ARRANGE
            
            //ACT 
            //const string proc = "administrativo.pr_incluir_municipio"; // HACK criada proc em dbo para atender os testes
            //var retorno1 = DataHelper.Get<int>(proc,
            //    new SqlParameter("@ds_cidade", "cidade16"),
            //    new SqlParameter("@ds_estado", "SP"));
            ////ASSERT
            //Assert.IsTrue(retorno1 > 0);
        }

        [TestCategory("Data"), TestCategory("Core"), TestCategory("Unitario"), TestCategory("Dapper"), TestMethod]
        public void UnitofWork_ExecutarAcaoComTransacao_ValidarFaltaUsoCommit()
        {
            //ARRANGE
            uow = new DapperUnitOfWork(conexao);
            //ACT 
            uow.BeginTransaction();
            const string proc = "administrativo.pr_incluir_municipio"; // HACK criada proc em dbo para atender os testes
            uow.Get<int>(proc,
                new SqlParameter("@ds_cidade", "cidade16"),
                new SqlParameter("@ds_estado", "SP"));
            uow.Get<int>(proc,
               new SqlParameter("@ds_cidade", "cidade17"),
               new SqlParameter("@ds_estado", "SPSPSP"));
            //uow.SaveChanges();
            //ASSERT
            uow.Dispose();
            Assert.IsNull(((DapperUnitOfWork)uow).Connection);
        }
    }
}
