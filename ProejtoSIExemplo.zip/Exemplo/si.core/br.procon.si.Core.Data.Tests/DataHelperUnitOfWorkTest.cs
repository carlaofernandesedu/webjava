﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using br.procon.si.Core.Data.ADO;
using System.Data.SqlClient;
using System.Configuration;



namespace br.procon.si.Core.Data.Tests
{
    [TestClass]
    public class DataHelperUnitOfWorkTest
    {

        private DataHelperUnitOfWork uow;

        private string conexao = ConfigurationManager.ConnectionStrings[ConfigurationManager.ConnectionStrings.Count - 1].ConnectionString;


        [TestCategory("Data"), TestCategory("Core"), TestCategory("Integracao"), TestCategory("DataHelper"), TestMethod]
        public void UnitofWork_ExecutarAcoes_ValidarCommit()
        {
            //ARRANGE
            uow = new DataHelperUnitOfWork(conexao);
            //ACT 
            uow.BeginTransaction();
            const string proc = "administrativo.pr_incluir_municipio"; // HACK criada proc em dbo para atender os testes
            var retorno1 = uow.Get<int>(proc,
                new SqlParameter("@ds_cidade", "cidadecomtransacao1"),
                new SqlParameter("@ds_estado", "SP"));
            var retorno2 = uow.Get<int>(proc,
               new SqlParameter("@ds_cidade", "cidadecomtransacao2"),
               new SqlParameter("@ds_estado", "RJRJ"));
            uow.SaveChanges();
            //ASSERT
            uow = null;
            Assert.IsTrue(retorno2 > retorno1);
        }


        [TestCategory("Data"), TestCategory("Core"), TestCategory("Integracao"), TestCategory("DataHelper"), TestMethod]

        public void UnitofWork_ExecutarAcoesComUmaFalha_ValidarDesfazerAcoes()
        {
            //ARRANGE
            uow = new DataHelperUnitOfWork(conexao);
            Exception erro = null;
            //ACT 
            try
            {
                uow.BeginTransaction();
                var proc1 = "dd";
                const string proc = "administrativo.pr_incluir_municipio"; // HACK criada proc em dbo para atender os testes
                uow.Get<int>(proc,
                    new SqlParameter("@ds_cidade", "cidadetransacaodesfeita5"),
                    new SqlParameter("@ds_estado", "SP"));
                uow.Get<int>(proc1,
                   new SqlParameter("@ds_cidade", "cidade6"),
                   new SqlParameter("@ds_estado", "SPSPSP"));
                uow.SaveChanges();
            }
            catch (Exception ex)
            {
                erro = ex;
            }
            finally
            {
                //uow.CloseConnection();
                uow.Dispose();
            }
            //ASSERT
            Assert.IsNotNull(erro);
        }

        [TestCategory("Data"), TestCategory("Core"), TestCategory("Integracao"), TestCategory("DataHelper"), TestMethod]
        public void UnitofWork_ExecutarAcaoSemTransacao_Validar()
        {
            //ARRANGE
            uow = new DataHelperUnitOfWork(conexao);
            //ACT 
            const string proc = "administrativo.pr_incluir_municipio"; // HACK criada proc em dbo para atender os testes
            var retorno1 = uow.Get<int>(proc,
                new SqlParameter("@ds_cidade", "cidadeSemTransacao16"),
                new SqlParameter("@ds_estado", "SP"));
            //ASSERT
            Assert.IsTrue(retorno1 > 0);
        }

        [TestCategory("Data"), TestCategory("Core"), TestCategory("Integracao"), TestCategory("DataHelper"), TestMethod]
        public void UnitofWork_ExecutarAcaoComTransacao_ValidarFaltaUsoCommit()
        {
            //ARRANGE
            uow = new DataHelperUnitOfWork(conexao);
            //ACT 
            uow.BeginTransaction();
            const string proc = "administrativo.pr_incluir_municipio"; // HACK criada proc em dbo para atender os testes
            uow.Get<int>(proc,
                new SqlParameter("@ds_cidade", "cidadeSemUsodoCommit16"),
                new SqlParameter("@ds_estado", "SP"));
            uow.Get<int>(proc,
               new SqlParameter("@ds_cidade", "cidadeSemUsodocommit17"),
               new SqlParameter("@ds_estado", "SPSPSP"));
            uow.Dispose();
            //ASSERT
            //uow.CloseConnection();
            Assert.IsNull(((DataHelperUnitOfWork)uow).Connection);
        }
    }
}
