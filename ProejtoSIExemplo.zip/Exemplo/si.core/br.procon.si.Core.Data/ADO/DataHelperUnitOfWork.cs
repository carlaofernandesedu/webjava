﻿using br.procon.si.Core.Domain.Helpers;
using br.procon.si.Core.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace br.procon.si.Core.Data.ADO
{
    public class DataHelperUnitOfWork : IUnitOfWork, IDisposable
    {
        private readonly string _connectionString;

        private SqlTransaction _transaction { get; set; }

        private SqlConnection _connection { get; set; }

        private bool _disposed;

        private bool _ehtransaction { get; set; }

        private int _commandTimeout;

        public string ConnectionString
        {
            get { return _connectionString; }
        }

        public DataHelperUnitOfWork(string connectionString)
            : this(connectionString, 300)
        {
        }

        public DataHelperUnitOfWork(string connectionString, int commandTimeout)
        {
            _connectionString = connectionString;

            _commandTimeout = commandTimeout;
        }

        public void SetCommandTimeout(int commandTimeout)
        {
            _commandTimeout = commandTimeout;
        }

        #region "Transações"
        public SqlConnection Connection
        {
            get
            {
                return _connection;
            }
        }

        public SqlTransaction Transaction
        {
            get
            {
                return _transaction;
            }
        }

        public void BeginTransaction()
        {
            _connection = new SqlConnection(this._connectionString);

            _connection.Open();

            _transaction = _connection.BeginTransaction();

            _ehtransaction = true;
        }

        public void SaveChanges()
        {
            try
            {
                _transaction.Commit();
            }
            catch
            {
                throw;
            }
            finally
            {
                _ehtransaction = false;

                if (_transaction != null) _transaction.Dispose();

                if (_connection != null && _connection.State == ConnectionState.Open) _connection.Close();

                _transaction = null;

                _connection = null;
            }
        }
        #endregion

        public static TOut Cast<TOut>(object sourceIn) where TOut : new()
        {
            if (sourceIn == null) return default(TOut);

            return CastSetValue<TOut>(sourceIn);
        }

        public static IEnumerable<TOut> CastList<TOut, TIn>(TIn[] sourceIn) where TOut : new()
        {
            IList<TOut> result = new List<TOut>();

            Parallel.ForEach(sourceIn, item =>
            {
                result.Add(CastSetValue<TOut>(item));
            });

            return result.ToList();
        }

        private static TOut CastSetValue<TOut>(object sourceIn) where TOut : new()
        {
            var resultOut = new TOut();

            Parallel.ForEach(sourceIn.GetType().GetProperties(), propIn =>
            {
                var propOut = typeof(TOut).GetProperty(propIn.Name);

                if (propOut != null) propOut.SetValue(resultOut, propIn.GetValue(sourceIn));
            });

            return resultOut;
        }

        #region Get
        public T Get<T>(string query) where T : new()
        {
            return Get<T>(query, string.Empty);
        }

        public T Get<T>(string query, params SqlParameter[] parameter) where T : new()
        {
            return Get<T>(query, string.Empty, parameter);
        }

        private T Get<T>(string query, SqlParameterCollection parameter) where T : new()
        {
            var obj = new SqlParameter[parameter.Count];

            parameter.CopyTo(obj, 0);

            return Get<T>(query, string.Empty, obj.ToArray());
        }

        private T Get<T>(string query, string catalog) where T : new()
        {
            return Get<T>(query, catalog, new SqlParameter[] { });
        }

        private T Get<T>(string query, string catalog, params SqlParameter[] parameter) where T : new()
        {
            var source = Get(query, catalog, parameter);

            return Cast<T>(source.Select().FirstOrDefault());
        }
        #endregion

        #region List
        public IEnumerable<T> List<T>(string query) where T : new()
        {
            return List<T>(query, string.Empty).ToList();
        }

        public IEnumerable<T> List<T>(string query, params SqlParameter[] parameter) where T : new()
        {
            return List<T>(query, string.Empty, parameter).ToList();
        }

        private IEnumerable<T> List<T>(string query, SqlParameterCollection parameter) where T : new()
        {
            SqlParameter[] obj = new SqlParameter[parameter.Count];

            parameter.CopyTo(obj, 0);

            return List<T>(query, string.Empty, obj.ToList().ToArray()).ToList();
        }

        private IEnumerable<T> List<T>(string query, string catalog) where T : new()
        {
            return List<T>(query, catalog, new SqlParameter[] { }).ToList();
        }

        private IEnumerable<T> List<T>(string query, string catalog, params SqlParameter[] parameter) where T : new()
        {
            var source = Get(query, catalog, parameter);

            return (from DataRow row in source.Rows select Cast<T>(row)).ToList();
        }

        public IEnumerable<T> List<T>(string query, out int totalRegistros, params SqlParameter[] parameter) where T : new()
        {
            var source = Get(query, string.Empty, parameter);

            var result = from DataRow row in source.Rows
                         select Cast<T>(row);

            var qryTotal = (from DataRow row in source.Rows select row["totalregistros"]).FirstOrDefault();

            totalRegistros = (int)(qryTotal ?? 0);

            return result;
        }
        #endregion

        #region Generic's DataBase
        private static T Cast<T>(DataRow row) where T : new()
        {
            if (row == null) return default(T);

            var source = new T();

            if (source.GetType().IsPrimitive)
            {
                return (T)Convert.ChangeType(row.Table.Rows[0][0], typeof(T));
            }

            foreach (DataColumn column in row.Table.Columns)
            {
                Type type = typeof(T);

                object value = row[column.ColumnName];

                PropertyInfo property = GetColumnAttributeProperty(type, column);

                if (property != null && row[column.ColumnName].GetType() != typeof(DBNull))
                {
                    PropertySetValue(source, property, value);
                }
                else
                {
                    CascadingPropertySetValue<T>(source, type, row, column, value);
                }
            }

            return source;
        }

        private static void CascadingPropertySetValue<T>(T source, Type type, DataRow row, DataColumn column, object value) where T : new()
        {
            IEnumerable<PropertyInfo> cascadingProperties = type.GetProperties()
                .Where(w => w.GetCustomAttributes(true).Any(a => a is CascadingTypeAttribute))
                .ToList();

            if (cascadingProperties.Any())
            {
                foreach (PropertyInfo cascadingProperty in cascadingProperties)
                {
                    Type innerType = cascadingProperty.PropertyType;

                    PropertyInfo innerProperty = GetColumnAttributeProperty(innerType, column);

                    if (innerProperty != null && row[column.ColumnName].GetType() != typeof(DBNull))
                    {
                        object innerSource = innerType.GetConstructor(new Type[] { }).Invoke(new object[] { });

                        PropertySetValue(innerSource, innerProperty, value);

                        type.GetProperty(cascadingProperty.Name).SetValue(source, innerSource);
                    }
                }
            }
        }

        private static PropertyInfo GetColumnAttributeProperty(Type type, DataColumn column)
        {
            PropertyInfo innerProperty = type.GetProperty(column.ColumnName) ?? type.GetProperties()
                .FirstOrDefault(f => f.GetCustomAttributes(true)
                    .Any(x => x is ColumnAttribute && ((ColumnAttribute)x).Name == column.ColumnName));

            return innerProperty;
        }

        private static void PropertySetValue(object source, PropertyInfo property, object value)
        {
            if (property.PropertyType.BaseType == typeof(Enum))
            {
                property.SetValue(source, Enum.Parse(property.PropertyType, value.ToString()));
            }
            else if (property.PropertyType.IsGenericType && property.PropertyType.GetGenericArguments()[0].BaseType == typeof(Enum))
            {
                property.SetValue(source, Enum.Parse(property.PropertyType.GetGenericArguments()[0], value.ToString()));
            }
            else
            {
                property.SetValue(source, value);
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CA2100:Review SQL queries for security vulnerabilities")]
        private DataTable GetWithoutTransaction(string query, string catalog, params SqlParameter[] parameter)
        {
            DataTable dt = null;
            try
            {
                dt = new DataTable();

                using (var cn = new SqlConnection(this._connectionString))
                {
                    var cmd = cn.CreateCommand();

                    cmd.CommandTimeout = _commandTimeout;

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.CommandText = query;

                    if (parameter.Any()) cmd.Parameters.AddRange(parameter);

                    cn.Open();

                    cmd.Connection = cn;

                    if (!string.IsNullOrEmpty(catalog)) cn.ChangeDatabase(catalog);

                    using (var reader = cmd.ExecuteReader())
                    {
                        dt.Load(reader);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CA2100:Review SQL queries for security vulnerabilities")]
        private DataTable GetWithTransaction(string query, string catalog, params SqlParameter[] parameter)
        {
            DataTable dt = null;

            try
            {
                dt = new DataTable();

                using (var cmd = new SqlCommand())
                {
                    cmd.CommandTimeout = 300;

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.CommandText = query;

                    if (parameter.Any()) cmd.Parameters.AddRange(parameter);

                    cmd.Transaction = _transaction;

                    cmd.Connection = _connection;

                    if (!string.IsNullOrEmpty(catalog)) _connection.ChangeDatabase(catalog);

                    using (var reader = cmd.ExecuteReader())
                    {
                        dt.Load(reader);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CA2100:Review SQL queries for security vulnerabilities")]
        private DataTable Get(string query, string catalog, params SqlParameter[] parameter)
        {
            DataTable result = null;

            if (_ehtransaction == false || _transaction == null)
            {
                result = GetWithoutTransaction(query, catalog, parameter);
            }
            else
            {
                result = GetWithTransaction(query, catalog, parameter);
            }

            return result;
        }
        #endregion

        private static object GetValue(Object aux)
        {
            var s = aux as string;

            return s != null ? s.Trim() : aux;
        }

        #region Dispose
        public void Dispose()
        {
            ManualDispose(true);

            GC.SuppressFinalize(this);
        }

        public void ManualDispose(bool disposing)
        {
            _ehtransaction = false;

            if (!_disposed)
            {
                if (disposing)
                {
                    if (_connection != null)
                    {
                        if (_connection.State == ConnectionState.Open)
                        {
                            _connection.Close();
                        }

                        _connection.Dispose();

                        _connection = null;
                    }
                }

                _disposed = true;
            }
        }

        ~DataHelperUnitOfWork()
        {
            ManualDispose(false);
        }
        #endregion
    }
}
