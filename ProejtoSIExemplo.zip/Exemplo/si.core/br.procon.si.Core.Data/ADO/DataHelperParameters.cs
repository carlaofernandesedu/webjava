﻿using System;
using System.Data.SqlClient;

namespace br.procon.si.Core.Data.ADO
{
    public static class DataHelperParameters
    {
       public static SqlParameter CreateParameter(string nome, object parametro)

       {
           var sqlparam = new SqlParameter();
           sqlparam.ParameterName = nome;
           sqlparam.Value = parametro ?? DBNull.Value;
            return sqlparam;
        }

       public static SqlParameter CreateParameter(string nome, dynamic parametro, dynamic valorNulo)
       {
           var sqlparam = new SqlParameter();
           sqlparam.ParameterName = nome;
           
           if (parametro == null || parametro == valorNulo)
           {
               sqlparam.Value = DBNull.Value;
           }
           else
           {
               sqlparam.Value = (object)parametro;               
           }
           return sqlparam;
       }
    }
}
