﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;


namespace br.procon.si.Core.Data.ADO
{
    public static class DataHelper
    {
        public static TOut Cast<TOut>(object sourceIn)
          where TOut : new()
        {

            if (sourceIn == null)
                return default(TOut);
            var resultOut = new TOut();
            foreach (var propIn in sourceIn.GetType().GetProperties())
            {
                var propOut = typeof(TOut).GetProperty(propIn.Name);
                if (propOut != null)
                    propOut.SetValue(resultOut, propIn.GetValue(sourceIn));
            }
            return resultOut;
        }
        public static IEnumerable<TOut> CastList<TOut, TIn>(TIn[] sourceIn)
          where TOut : new()
        {

            foreach (var item in sourceIn)
            {
                var resultOut = new TOut();
                foreach (var propIn in typeof(TIn).GetProperties())
                {
                    var propOut = typeof(TOut).GetProperty(propIn.Name);
                    if (propOut != null)
                        propOut.SetValue(resultOut, propIn.GetValue(item));
                }
                yield return resultOut;
            }

        }
        #region Get
        public static T Get<T>(string query) where T : new()
        {
            return Get<T>(query, string.Empty);
        }
        public static T Get<T>(string query, params SqlParameter[] parameter) where T : new()
        {
            return Get<T>(query, string.Empty, parameter);
        }
        public static T Get<T>(string query, SqlParameterCollection parameter) where T : new()
        {
            SqlParameter[] obj = new SqlParameter[parameter.Count];
            parameter.CopyTo(obj, 0);
            return Get<T>(query, string.Empty, obj.ToArray());
        }
        public static T Get<T>(string query, string catalog) where T : new()
        {
            return Get<T>(query, catalog, new SqlParameter[] { });
        }
        public static T Get<T>(string query, string catalog, params SqlParameter[] parameter)
            where T : new()
        {
            var source = Get(query, catalog, parameter);
            return Cast<T>(source.Select().FirstOrDefault());
            // TODO Quebrou ao editar objetos.
            //return (T)source.Select().FirstOrDefault().ItemArray[0];
        }
        #endregion
        #region List
        public static IEnumerable<T> List<T>(string query, string catalog, params SqlParameter[] parameter)
            where T : new()
        {
            var source = Get(query, catalog, parameter);
            return from DataRow row in source.Rows select Cast<T>(row);
        }

        public static IEnumerable<T> List<T>(string query) where T : new()
        {
            return List<T>(query, string.Empty);
        }
        public static IEnumerable<T> List<T>(string query, params SqlParameter[] parameter) where T : new()
        {
            return List<T>(query, string.Empty, parameter);
        }
        public static IEnumerable<T> List<T>(string query, SqlParameterCollection parameter) where T : new()
        {
            SqlParameter[] obj = new SqlParameter[parameter.Count];
            parameter.CopyTo(obj, 0);
            return List<T>(query, string.Empty, obj.ToList().ToArray());
        }
        public static IEnumerable<T> List<T>(string query, string catalog) where T : new()
        {
            return List<T>(query, catalog, new SqlParameter[] { });
        }
        #endregion
        #region Generic's DataBase
        private static T Cast<T>(DataRow dr) where T : new()
        {
            if (dr == null)
                return default(T);
            var source = new T();
            if (source.GetType().IsPrimitive)
            {
                return (T)Convert.ChangeType(dr.Table.Rows[0][0], typeof(T));
            }
            foreach (DataColumn column in dr.Table.Columns)
            {
                Type t = typeof(T);
                var p = t.GetProperty(column.ColumnName) ??
                    t.GetProperties().Where(q => q.GetCustomAttributes(true).Where(x => x is System.ComponentModel.DataAnnotations.Schema.ColumnAttribute
                        && ((System.ComponentModel.DataAnnotations.Schema.ColumnAttribute)x).Name == column.ColumnName).Count() > 0).FirstOrDefault();

                if (p != null && dr[column.ColumnName].GetType().Name != "DBNull")
                {
                    var val = dr[column.ColumnName];

                    if (p.PropertyType.BaseType == typeof(Enum))
                    {
                        p.SetValue(source, Enum.Parse(p.PropertyType, val.ToString()));
                    }
                    else if (p.PropertyType.IsGenericType && p.PropertyType.GetGenericArguments()[0].BaseType == typeof(Enum))
                    {
                        p.SetValue(source, Enum.Parse(p.PropertyType.GetGenericArguments()[0], val.ToString()));
                    }
                    else
                    {
                        p.SetValue(source, val);
                    }
                }
                else
                {
                    var props = t.GetProperties().Where(q => q.GetCustomAttributes(true).Where(x => x is br.procon.si.Core.Domain.Helpers.CascadingTypeAttribute).Count() > 0);

                    if (props.Count() > 0)
                    {
                        foreach (var item in props)
                        {

                            Type t2 = item.PropertyType;
                            var p2 = t2.GetProperty(column.ColumnName) ??
                                t2.GetProperties().Where(q => q.GetCustomAttributes(true).Where(x => x is System.ComponentModel.DataAnnotations.Schema.ColumnAttribute
                                && ((System.ComponentModel.DataAnnotations.Schema.ColumnAttribute)x).Name == column.ColumnName).Count() > 0).FirstOrDefault();

                            if (p2 != null && dr[column.ColumnName].GetType().Name != "DBNull")
                            {
                                var val = dr[column.ColumnName];

                                if (p2.PropertyType.BaseType == typeof(Enum))
                                {
                                    p2.SetValue(t.GetProperty(item.Name).GetValue(source), Enum.Parse(p2.PropertyType, val.ToString()));
                                }
                                else if (p2.PropertyType.IsGenericType && p2.PropertyType.GetGenericArguments()[0].BaseType == typeof(Enum))
                                {
                                    p2.SetValue(t.GetProperty(item.Name).GetValue(source), Enum.Parse(p2.PropertyType.GetGenericArguments()[0], val.ToString()));
                                }
                                else
                                {
                                    p2.SetValue(t.GetProperty(item.Name).GetValue(source), val);
                                }
                            }
                        }
                    }
                }
            }
            return source;
        }
        private static ConnectionStringSettings _connectionStringSettings;
        public static ConnectionStringSettings ConnectionString
        {
            get
            {
                return _connectionStringSettings ??
                       (_connectionStringSettings =
                           ConfigurationManager.ConnectionStrings[ConfigurationManager.ConnectionStrings.Count - 1]);
            }
        }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CA2100:Review SQL queries for security vulnerabilities")]
        private static DataTable Get(string query, string catalog, params SqlParameter[] parameter)
        {
            DataTable dt = null;
            SqlCommand cmd = null;
            try
            {
                dt = new DataTable();
                cmd = new SqlCommand();
                cmd.CommandTimeout = 300;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = query;
                if (parameter.Any())
                {
                    cmd.Parameters.AddRange(parameter);
                }

                using (SqlConnection cn = new SqlConnection(ConnectionString.ConnectionString))
                {
                    cmd.Connection = cn;
                    cn.Open();
                    if (!string.IsNullOrEmpty(catalog))
                        cn.ChangeDatabase(catalog);
                    var reader = cmd.ExecuteReader();
                    dt.Load(reader);
                }
            }
            finally
            {
                if (cmd != null)
                    cmd.Dispose();
            }

            return dt;
        }

        #endregion
        private static object GetValue(Object aux)
        {
            var s = aux as string;
            return s != null ? s.Trim() : aux;
        }
    }
}
