﻿using MySql.Data.MySqlClient;
using System;
using Dapper;


namespace br.procon.si.Core.Data.ADO
{
    public static class DataHelperParametersMySQL
    {
       public static MySqlParameter CreateParameter(string nome, object parametro)

       {
           var sqlparam = new MySqlParameter();
           sqlparam.ParameterName = nome;
           sqlparam.Value = parametro ?? DBNull.Value;
            return sqlparam;
        }

       public static MySqlParameter CreateParameter(string nome, dynamic parametro, dynamic valorNulo)
       {
           var sqlparam = new MySqlParameter();
           sqlparam.ParameterName = nome;
           
           if (parametro == null || parametro == valorNulo)
           {
               sqlparam.Value = DBNull.Value;
           }
           else
           {
               sqlparam.Value = (object)parametro;               
           }
           return sqlparam;
       }
    }
}
