﻿using System;
using MySql.Data.MySqlClient;
using br.procon.si.Core.Domain.Interfaces;
using Dapper;
using System.Data;
using System.Linq;
using System.Collections.Generic;

namespace br.procon.si.Core.Data.Dapper
{
    public class DapperUnitOfWorkMySQL : IUnitOfWork, IDisposable
    {
        private readonly string _connectionString;
        private MySqlTransaction _transaction { get; set; }
        private MySqlConnection _connection { get; set; }
        private bool _disposed;
        private bool _ehtransaction { get; set; }
        private int _commandTimeout;

        public string ConnectionString
        {
            get { return _connectionString; }
        }

        public DapperUnitOfWorkMySQL(string connectionString)
        {
            _connectionString = connectionString;
            _commandTimeout = 300;
        }

        //TODO [TIME] refatorar para  ser somente um construtor inserindo a informacao de timeout 
        public DapperUnitOfWorkMySQL(string connectionString, int commandTimeout)
        {
            _connectionString = connectionString;
            _commandTimeout = commandTimeout;
        }

        public void SetCommandTimeout(int commandTimeout)
        {
            _commandTimeout = commandTimeout;
        }


        public MySqlConnection Connection
        {
            get
            {
                return _connection;
            }
        }
        #region "transacoes"
        public MySqlTransaction Transaction
        {
            get
            {
                return _transaction;
            }
        }

        public void BeginTransaction()
        {
            _connection = new MySqlConnection(this._connectionString);
            _connection.Open();
            _transaction = _connection.BeginTransaction();
            _ehtransaction = true;
        }

        public void SaveChanges()
        {
            try
            {
                _transaction.Commit();
            }
            catch
            {
                throw;
            }
            finally
            {
                _ehtransaction = false;
                if (_transaction != null)
                    _transaction.Dispose();

                if (_connection != null)
                {
                    if (_connection.State == ConnectionState.Open)
                    {
                        _connection.Close();
                    }
                }

                _transaction = null;
                _connection = null;

            }
        }
        #endregion

        public IEnumerable<T> List<T>(string query, params MySqlParameter[] parameter) where T : new()
        {
            //using (IDbConnection conn = new MySqlConnection(this._connectionString))
            //{
            //    return conn.Query<T>(sql: query, param: ConvertTo(parameter), commandTimeout: _commandTimeout, commandType: CommandType.Text);
            //}
            if (_ehtransaction == false || _transaction == null)
            {
                return GetWithoutTransaction<T>(query, parameter);
            }
            else
            {
                return GetWithTransaction<T>(query, parameter);
            }

        }

        public T Get<T>(string query, params MySqlParameter[] parameter) where T : new()
        {
            //using (IDbConnection conn = new MySqlConnection(this._connectionString))
            //{
            //    return conn.Query<T>(sql: query, param: ConvertTo(parameter), commandTimeout: _commandTimeout, commandType: CommandType.Text).AsEnumerable().FirstOrDefault();
            //}
            return List<T>(query, parameter).AsEnumerable().FirstOrDefault();
        }

        //public T Get<T>(Dictionary<string,string> parameter, string query) where T : new()
        //{
        //    var querymodified = query; 
        //    if (parameter !=null && parameter.Count > 0) 
        //    {
        //        foreach (var item in parameter)
        //        {
        //            querymodified = querymodified.Replace(item.Key, item.Value);
        //        }
        //    }


        //    using (IDbConnection conn = new MySqlConnection(this._connectionString))
        //    {
        //        return conn.Query<T>(sql: querymodified, param: null, commandTimeout: _commandTimeout, commandType: CommandType.Text).AsEnumerable().FirstOrDefault();
        //    }
        //}


        private IEnumerable<T> GetWithTransaction<T>(string query, params MySqlParameter[] parameter) where T : new()
        {
           return _connection.Query<T>(sql: query, param: ConvertTo(parameter), transaction: _transaction, commandTimeout: _commandTimeout, commandType: CommandType.Text);
        }

        private IEnumerable<T> GetWithoutTransaction<T>(string query, params MySqlParameter[] parameter) where T : new()
        {
            using (IDbConnection conn = new MySqlConnection(this._connectionString))
            {
                return conn.Query<T>(sql: query, param: ConvertTo(parameter), commandTimeout: _commandTimeout, commandType: CommandType.Text);
            }
        }


        public int Execute(string query, params MySqlParameter[] parameter)
        {
            if (_ehtransaction == false || _transaction == null)
            {
                using (IDbConnection conn = new MySqlConnection(this._connectionString))
                {
                    return conn.Execute(sql: query, param: ConvertTo(parameter), commandTimeout: _commandTimeout, commandType: CommandType.Text);
                }
            }
            else
            {
                return _connection.Execute(sql: query, param: ConvertTo(parameter), transaction: _transaction, commandTimeout: _commandTimeout, commandType: CommandType.Text);
            }
        }

        private DynamicParameters ConvertTo(MySqlParameter[] paramsmysql)
        {
           DynamicParameters paramsdap = null;
           if (paramsmysql != null)
           {
               paramsdap = new DynamicParameters();
               foreach(var item in paramsmysql) 
               {
                    paramsdap.Add(item.ParameterName, item.Value);
               }
           }
           return paramsdap;
        }

        #region Dispose
        public void Dispose()
        {
            ManualDispose(true);
            GC.SuppressFinalize(this);
        }
        public void ManualDispose(bool disposing)
        {
            _ehtransaction = false;
            if (!_disposed)
            {
                if (disposing)
                {
                    if (_connection != null)
                    {
                        if (_connection.State == ConnectionState.Open)
                        {
                            _connection.Close();
                        }
                        _connection.Dispose();
                        _connection = null;
                    }
                }
                _disposed = true;
            }
        }

        ~DapperUnitOfWorkMySQL()
        {
            ManualDispose(false);
        }

        #endregion
    }
}
