﻿using System;
using System.Text.RegularExpressions;

namespace br.procon.si.Core.Domain.ValueObjects
{

    public static class InscricaoEstadual
    {
        public static string PatternMascaraInscricaoEstadual
        {
            get
            {
                return @"(\d{3})(\d{3})(\d{3})(\d{3})";
            }
        }

        public static string FormatarMascaraIE(string texto)
        {
            if (string.IsNullOrEmpty(texto))
                return String.Empty;

            var regex = new Regex(PatternMascaraInscricaoEstadual);
            var retorno = regex.Replace(texto, "$1.$2.$3.$4");

            return retorno;
        }
    }
}
