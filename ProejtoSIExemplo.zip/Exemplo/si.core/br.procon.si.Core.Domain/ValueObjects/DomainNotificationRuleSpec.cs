﻿using br.procon.si.Core.Domain.Events;
using br.procon.si.Core.Domain.Interfaces;

namespace br.procon.si.Core.Domain.ValueObjects
{
    public class DomainNotificationRuleSpec<TEntity> : ISpecification<TEntity>
    {
        private readonly string message = string.Empty;
        private readonly bool result = true;

        public DomainNotificationRuleSpec(DomainNotification notification)
        {
            if (notification != null)
            {
                message = notification.Value;
                result = false;
            }
        }

        public bool IsSatisfiedBy(TEntity entity)
        {
            return result;
        }


        public string MensagemDeRetorno
        {
            get { return message; }
        }
    }
}