﻿using System;
using br.procon.si.Core.Domain.Helpers;

namespace br.procon.si.Core.Domain.ValueObjects
{
    public class AveriguacaoPreliminarVO
    {
        public string NumeroAveriguacaoPreliminar { get; private set; }

        public AveriguacaoPreliminarVO() { }

        public AveriguacaoPreliminarVO(string averiguacaoPreliminar)
        {
            NumeroAveriguacaoPreliminar = averiguacaoPreliminar;
        }

        public static bool ValidarAp(string apuracao)
        {
            System.Text.RegularExpressions.Regex rgx = new System.Text.RegularExpressions.Regex(@"[\.-]");
            apuracao = rgx.Replace(apuracao, string.Empty);

            string coef = "23456789";
            int digito = int.Parse(apuracao.Substring(8, 1));
            int r = 0;
            int T = 0;

            apuracao = apuracao.Substring(0, 2) + int.Parse(apuracao.Substring(2, 6));

            for (int k = 0; k < apuracao.Length; k++)
            {
                T = T + int.Parse(apuracao.Substring(k, 1)) * int.Parse(coef.Substring(k, 1));
            }
            r = T % 11;
            if (r < 2)
            {
                return digito == 0;
            }
            else
            {
                return digito == (11 - r);
            }
        }
    }
}
