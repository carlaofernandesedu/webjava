﻿namespace br.procon.si.Core.Domain.ValueObjects
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;


    public class FiltroBase
    {
        [Display(Name = "Código")]
        public int? Codigo { get; set; }

        public string Termo { get; set; }

        /// <summary>
        /// Ativo ou Inativo
        /// </summary>
        [Display(Name = "Status")]
        public bool? Status { get; set; }

        /// <summary>
        /// Data de criação do registro.
        /// </summary>
        [Display(Name = "Data Criação"), DataType(DataType.DateTime)]
        public virtual DateTime DataCriacao { get; set; }

        /// <summary>
        /// Usuário que criou o registro.
        /// </summary>
        [Display(Name = "Usuário Criação")]
        public int IdUsuarioCriacao { get; set; }

        /// <summary>
        /// Data da última alteração do registro.
        /// </summary>
        [Display(Name = "Data Alteração")]
        public DateTime DataAlteracao { get; set; }

        /// <summary>
        /// Usuário responsável pela última alteração do registro.
        /// </summary>
        [Display(Name = "Usuário Alteração")]
        public int UsuarioAlteracao { get; set; }
        
        public int PaginaAtual { get; set; }

        private int _inicio;
        public int Inicio
        {
            get
            {
                return _inicio;
            }
            set
            {
                _inicio = value;

                PaginaAtual = (_inicio / _qtdItensPorPagina) + 1;
            }
        }

        private int _qtdItensPorPagina;
        public int QtdItensPorPagina
        {
            get
            {
                return _qtdItensPorPagina;
            }
            set
            {
                _qtdItensPorPagina = value;

                PaginaAtual = (_inicio / _qtdItensPorPagina) + 1;
            }
        }

        public int TotalRegistros { get; set; }

        public bool Paginado { get; set; }

        public KeyValuePair<string, int>? Ordenacao { get; set; }

        public FiltroBase()
        {
            PaginaAtual = 1;
            QtdItensPorPagina = Int32.MaxValue;
        }

        public FiltroBase(int paginaAtual, int qtdItensPorPagina)
        {
            PaginaAtual = paginaAtual;
            QtdItensPorPagina = qtdItensPorPagina;
        }
    }
}
