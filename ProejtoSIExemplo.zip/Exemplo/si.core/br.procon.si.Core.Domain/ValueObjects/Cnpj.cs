﻿using System;
using br.procon.si.Core.Domain.Helpers;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.RegularExpressions;


namespace br.procon.si.Core.Domain.ValueObjects
{
    public class Cnpj
    {

        [Column("cd_cnpj")]
        public string Codigo { get; private set; }

        public Cnpj()
        {

        }

        public static string PatternCnpj
        {
            get { return "^(\\d{2})(\\d{3})(\\d{3})(\\d{4})(\\d{2})$"; }
        }


        public Cnpj(string cnpj)
        {
            Codigo = cnpj;
        }

        public static string FormatarMascaraCnpj(string texto)
        {
            if (string.IsNullOrEmpty(texto))
                return null;

            var regExp = new Regex(PatternCnpj);
            return regExp.Replace(texto, "$1.$2.$3/$4-$5");
        }


        public static string ToCnpj(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return value;

            var pattern = "^(\\d{2})(\\d{3})(\\d{3})(\\d{4})(\\d{2})$";
            var regExp = new Regex(pattern);
            return regExp.Replace(value, "$1.$2.$3/$4-$5");
        }

        public static bool Validar(string cnpj)
        {
            System.Text.RegularExpressions.Regex rgx = new System.Text.RegularExpressions.Regex(@"[\./-]");
            cnpj = rgx.Replace(cnpj, string.Empty);

            if (cnpj == string.Empty) return false;

            if (cnpj.Length != 14)
                return false;

            // Elimina CNPJs invalidos conhecidos
            if (cnpj == "00000000000000" ||
                cnpj == "11111111111111" ||
                cnpj == "22222222222222" ||
                cnpj == "33333333333333" ||
                cnpj == "44444444444444" ||
                cnpj == "55555555555555" ||
                cnpj == "66666666666666" ||
                cnpj == "77777777777777" ||
                cnpj == "88888888888888" ||
                cnpj == "99999999999999")
                return false;

            // Valida DVs
            int tamanho = cnpj.Length - 2;
            string numeros = cnpj.Substring(0, tamanho);
            string digitos = cnpj.Substring(tamanho);
            int soma = 0;
            int pos = tamanho - 7;
            for (int i = tamanho; i >= 1; i--)
            {
                soma += int.Parse("0" + numeros.Substring(tamanho - i, 1)) * pos--;
                if (pos < 2)
                    pos = 9;
            }
            int resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
            if (resultado != int.Parse("0" + digitos.Substring(0, 1)))
                return false;

            tamanho = tamanho + 1;
            numeros = cnpj.Substring(0, tamanho);
            soma = 0;
            pos = tamanho - 7;
            for (int i = tamanho; i >= 1; i--)
            {
                soma += int.Parse("0" + numeros.Substring(tamanho - i, 1)) * pos--;
                if (pos < 2)
                    pos = 9;
            }
            resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
            if (resultado != int.Parse("0" + digitos.Substring(1, 1)))
                return false;

            return true;
        }



    }
}