﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Core.Domain.ValueObjects.Enums
{
    public enum TipoNotificacao
    {
        Email = 1,
        Facebook = 2,
        Twitter = 3
    }
}
