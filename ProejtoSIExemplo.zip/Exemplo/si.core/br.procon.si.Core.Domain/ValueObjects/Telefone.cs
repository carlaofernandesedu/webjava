﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.RegularExpressions;

namespace br.procon.si.Core.Domain.ValueObjects
{
    public static class Telefone
    {
        public static string FormatarMascaraTelefone(string texto)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(texto))
                {
                    return null;
                }

                if (texto.Contains("("))
                {
                    return texto;
                }

                var ddd = texto.Substring(0, 2);
                var inicio = texto.Length > 10 ? texto.Substring(2, 5) : texto.Substring(2, 4);
                var final = texto.Length > 10 ? texto.Substring(7) : texto.Substring(6);

                return string.Concat("(", ddd, ") ", inicio, "-", final);
            }
            catch (Exception)
            {
                return null;
            }
        }

    }
}
