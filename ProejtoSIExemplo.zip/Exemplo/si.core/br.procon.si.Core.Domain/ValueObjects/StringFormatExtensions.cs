﻿using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace br.procon.si.Core.Domain.ValueObjects
{
    public static class StringFormatExtensions
    {
        #region Propriedades

        public static string PatternPontuacao => @"[^\w\s]";

        public static string PatternCaracteresEspeciais => "[^0-9a-zA-Z]+";

        public static string PatternCaracteresEspeciaiseAlfabeticos => "[^0-9]+";

        public static string PatternRemoverTodosOsEspacos => @"\s+";

        public static string PatternRemoverMultiplosEspacos => @"\s+";

        public static string PatternRemoverTagsHtml => @"<(.*?)>";

        #endregion Propriedades

        #region Remover Pontuação

        public static string RemoverPontuacao(this string texto)
        {
            if (string.IsNullOrEmpty(texto))
                return null;

            return Regex.Replace(texto, PatternPontuacao, "");
        }

        #endregion Remover Pontuação

        #region Remover Acentuação

        public static string RemoverAcentuacao(this string texto)
        {
            if (string.IsNullOrEmpty(texto))
                return null;

            var retorno = new StringBuilder();
            foreach (var c in texto.Normalize(NormalizationForm.FormD))
            {
                if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
                    retorno.Append(c);
            }

            return retorno.ToString();
        }

        #endregion Remover Acentuação

        #region "Remover Caracteres e Espacos"

        public static string RemoverEspacos(this string texto)
        {
            return RemoverEspacos(texto, true, true, true, true);
        }

        public static string RemoverEspacos(this string texto,
            bool inicio = false, bool fim = false, bool interno = false, bool todos = false)
        {
            if (string.IsNullOrEmpty(texto))
                return null;

            string retorno = string.Empty;

            if (inicio && !fim)
            {
                retorno = texto.TrimStart();
            }
            else if (fim && !inicio)
            {
                retorno = texto.TrimEnd();
            }
            else if (inicio && fim)
            {
                retorno = texto.Trim();
            }

            if (interno)
            {
                if (texto.Length >= 3)
                {
                    string aux = texto;
                    texto = texto.Substring(1, texto.Length - 2);
                    retorno = aux.Substring(0, 1) + texto.Replace(" ", string.Empty) + aux.Substring(aux.Length - 1, 1);
                }
                else
                    retorno = texto;
            }
            else if (todos)
            {
                retorno = Regex.Replace(texto, PatternRemoverTodosOsEspacos, string.Empty);
            }

            return retorno;
        }

        public static string RemoverMultiplosEspacos(this string texto)
        {
            return Regex.Replace(texto, PatternRemoverMultiplosEspacos, " ");
        }

        /// <summary>
        /// Precisa validar o retorno deste métodos
        /// </summary>
        /// <param name="texto"></param>
        /// <returns></returns>
        public static string RemoverCaracteresEspeciais(this string texto, string[] exceto = null)
        {
            if (string.IsNullOrEmpty(texto))
                return null;

            if (exceto != null)
            {
                string novoPattern = "[^0-9a-zA-Z";
                for (int i = 0; i < exceto.Count(); i++)
                {
                    novoPattern += exceto[i];
                }
                novoPattern += "]+";
                return Regex.Replace(texto, novoPattern, "");
            }

            return Regex.Replace(texto, PatternCaracteresEspeciais, "");
        }

        public static string RemoverCaracteresEspeciaiseAlfabeticos(this string texto)
        {
            if (string.IsNullOrEmpty(texto))
                return null;

            return Regex.Replace(texto, PatternCaracteresEspeciaiseAlfabeticos, "");
        }
        #endregion "Remover Caracteres e Espacos"

        #region Remover Tags Html 
        public static string RemoverTagsHtml(this string texto)
        {
            if (string.IsNullOrEmpty(texto)) return null;

            texto = Regex.Replace(texto, PatternRemoverTagsHtml, "");
            texto = texto.Replace("&nbsp;", " ");

            return texto;
        }

        #endregion
    }
}