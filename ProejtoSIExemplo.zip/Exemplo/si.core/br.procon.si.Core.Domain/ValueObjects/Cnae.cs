﻿using System.Text.RegularExpressions;

namespace br.procon.si.Core.Domain.ValueObjects
{
    public static class Cnae
    {
        public static string FormatarMascaraCnae(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return null;

            var pattern = "^(\\d{4})(\\d{1})(\\d{2})$";
            var regExp = new Regex(pattern);
            return regExp.Replace(texto, "$1-$2/$3");
        }
    }
}
