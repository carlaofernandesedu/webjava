﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.RegularExpressions;

namespace br.procon.si.Core.Domain.ValueObjects
{
    public class Cpf
    {
        public const int ValorMaxCpf = 11;

        [Column("cd_cpf")]
        public string Codigo { get; private set; }

        public Cpf()
        {

        }

        public Cpf(string cpf)
        {
            Codigo = cpf;
        }

        public static string FormatarMascaraCpf(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return value;

            var pattern = "^(\\d{3})(\\d{3})(\\d{3})(\\d{2})$";
            var regExp = new Regex(pattern);
            return regExp.Replace(value, "$1.$2.$3-$4");
        }


        public string GetCpfCompleto()
        {
            var cpf = Codigo.ToString();

            if (string.IsNullOrEmpty(cpf))
                return "";

            while (cpf.Length < 11)
                cpf = "0" + cpf;

            return cpf;
        }

        public static bool Validar(string cpf)
        {
            System.Text.RegularExpressions.Regex rgx = new System.Text.RegularExpressions.Regex(@"[\.-]");
            cpf = rgx.Replace(cpf, string.Empty);

            if (String.IsNullOrEmpty(cpf)) return false;
            // Elimina CPFs invalidos conhecidos    
            if (cpf.Length != 11 ||
                cpf == "00000000000" ||
                cpf == "11111111111" ||
                cpf == "22222222222" ||
                cpf == "33333333333" ||
                cpf == "44444444444" ||
                cpf == "55555555555" ||
                cpf == "66666666666" ||
                cpf == "77777777777" ||
                cpf == "88888888888" ||
                cpf == "99999999999")
                return false;
            // Valida 1o digito 
            int add = 0;
            for (int i = 0; i < 9; i++)
                add += int.Parse(cpf.Substring(i, 1)) * (10 - i);
            int rev = 11 - (add % 11);
            if (rev == 10 || rev == 11)
                rev = 0;
            if (rev != int.Parse(cpf.Substring(9, 1)))
                return false;
            // Valida 2o digito 
            add = 0;
            for (int i = 0; i < 10; i++)
                add += int.Parse(cpf.Substring(i, 1)) * (11 - i);
            rev = 11 - (add % 11);
            if (rev == 10 || rev == 11)
                rev = 0;
            if (rev != int.Parse(cpf.Substring(10, 1)))
                return false;
            return true;
        }
    }
}