﻿using System;
using br.procon.si.Core.Domain.Interfaces;

namespace br.procon.si.Core.Domain.ValueObjects
{
    public abstract class Aggregate : IAggregate, ISelfValidation
    {
        public Aggregate()
        {
            IdentificadorGlobal = Guid.NewGuid();
            ValidationResult = new ValidationResult();
        }

        public Aggregate(Guid id)
        {
            IdentificadorGlobal = id;
            ValidationResult = new ValidationResult();
        }

        public Guid IdentificadorGlobal { get; protected set; }

        public DateTime DataOperacao
        {
            get
            {
                return DateTime.Now;
            }
        }

        public int IdUsuarioOperacao
        {
            get;
            set;
        }

        public abstract bool IsValid { get; }

        public ValidationResult ValidationResult { get; private set; }

        public virtual void AdicionarResultadoDeValidacao(ValidationError resultado)
        {
            if (ValidationResult == null)
                ValidationResult = new ValidationResult();

            ValidationResult.Add(resultado);
        }

    }
}