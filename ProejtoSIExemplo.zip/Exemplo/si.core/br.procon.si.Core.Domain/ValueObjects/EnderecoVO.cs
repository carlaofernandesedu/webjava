﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Core.Domain.ValueObjects
{
    public static class EnderecoVO
    {
        public static string Formatar(string logradouro, string numero, string complemento, string bairro, string cidade, string uf, string cep)
        {
            //Logradouro, Numero Complemento -Bairro - Cidade / UF - CEP: @Cep.FormatarMascaraCep(Model.CEP)

            var sb = new StringBuilder();

            if (!string.IsNullOrWhiteSpace(logradouro))
            {
                sb.Append(logradouro);
            }

            if (!string.IsNullOrWhiteSpace(numero))
            {
                sb.Append(", ");
                sb.Append(numero);
            }

            if (!string.IsNullOrWhiteSpace(complemento))
            {
                sb.Append(complemento);
            }

            if (!string.IsNullOrWhiteSpace(bairro))
            {
                sb.Append(" - ");
                sb.Append(bairro);
            }

            if (!string.IsNullOrWhiteSpace(cidade))
            {
                sb.Append(" - ");
                sb.Append(cidade);
            }

            if (!string.IsNullOrWhiteSpace(uf))
            {
                sb.Append(" / ");
                sb.Append(uf);
            }

            if (!string.IsNullOrWhiteSpace(cep))
            {
                sb.Append(" - ");
                sb.Append(cep);
            }

            return sb.ToString();
        }
    }
}
