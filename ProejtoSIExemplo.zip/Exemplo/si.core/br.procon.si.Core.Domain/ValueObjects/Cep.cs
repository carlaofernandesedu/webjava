﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Linq;

namespace br.procon.si.Core.Domain.ValueObjects
{
    public class Cep
    {
        public const int ValorMaxCpf = 11;

        [Column("cd_cep")]
        public string Codigo { get; private set; }

        public Cep()
        {

        }

        public Cep(string cep)
        {
            Codigo = cep;
        }

        public static string FormatarMascaraCep(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return null;

            var pattern = "^(\\d{5})(\\d{3})$";
            var regExp = new Regex(pattern);
            return regExp.Replace(texto, "$1-$2");
        }


        public static string ObterZona(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return null;

            texto = texto.RemoverCaracteresEspeciais();

            int result = 0;
            if (!Int32.TryParse(texto, out result))
                return null;

            List<dynamic> listZonas = new List<dynamic>();

            listZonas.Add(new { Regiao = "Centro", CEPInicio = 01000000, CEPFim = 01599999 });           
            listZonas.Add(new { Regiao = "Norte", CEPInicio = 02000000, CEPFim = 03999999 });            
            listZonas.Add(new { Regiao = "Leste", CEPInicio = 08000000, CEPFim = 08499999 });         
            listZonas.Add(new { Regiao = "Sul", CEPInicio = 04000000, CEPFim = 04999999 });           
            listZonas.Add(new { Regiao = "Oeste", CEPInicio = 05000000, CEPFim = 05899999 });           
            listZonas.Add(new { Regiao = "GSP", CEPInicio = 06000000, CEPFim = 07999999 });          
            listZonas.Add(new { Regiao = "GSP", CEPInicio = 08500000, CEPFim = 09999999 });

            var zonaResult = listZonas.SingleOrDefault(z => z.CEPInicio <= result && z.CEPFim >= result);
     
            if (zonaResult != null)
                return zonaResult.Regiao;
            else
                return null;

        }

    }
}