﻿using System;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Globalization;

namespace br.procon.si.Core.Domain.ValueObjects
{
    public static class DateFormatExtensions
    {
        public static string FormataDataLonga(string data)
        {
            string[] meses = { "janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro" };
            string[] mesesFormatados = { "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro" };

            for (int i = 0; i < meses.Length; i++)
            {
                if (data.Contains(meses[i]))
                {
                    data = data.Replace(meses[i], mesesFormatados[i]);
                    break;
                }
            }

            string[] dias = { "segunda-feira", "terça-feira", "quarta-feira", "quinta-feira", "sexta-feira", "sábado", "domingo" };
            string[] diasFormatados = { "Segunda-Feira", "Terça-Feira", "Quarta-Feira", "Quinta-Feira", "Sexta-Feira", "Sábado", "Domingo" };

            for (int i = 0; i < dias.Length; i++)
            {
                if (data.Contains(dias[i]))
                {
                    data = data.Replace(dias[i], diasFormatados[i]);
                    break;
                }
            }

            return data;
        }


        public static string FormataDataPorExtenso(DateTime data)
        {
            CultureInfo culture = new CultureInfo("pt-BR");
            DateTimeFormatInfo dtfi = culture.DateTimeFormat;

            int dia = data.Day;
            int ano = data.Year;
            string mes = culture.TextInfo.ToTitleCase(dtfi.GetMonthName(data.Month));
            string dataExtenso = dia + " de " + mes + " de " + ano;

            return dataExtenso.ToUpper(new CultureInfo("pt-BR"));
        }
    }
}
