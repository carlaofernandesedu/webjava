﻿using System;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace br.procon.si.Core.Domain.Helpers
{
    public static class TextoHelper
    {
        private static string PatternPontuacao
        {
            get
            {
                return @"[^\w\s]";
            }
        }

        private static string PatternCaracteresEspeciais
        {
            get
            {
                return "[^0-9a-zA-Z]+";
            }
        }




        public static string RemoverAcentuacao(this string texto)
        {
            if (string.IsNullOrEmpty(texto))
                return null;

            var retorno = new StringBuilder();
            foreach (var c in texto.Normalize(NormalizationForm.FormD))
            {
                if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
                    retorno.Append(c);
            }
            return retorno.ToString();
        }


        /// <summary>
        /// Por que não utilizar Slug?
        /// </summary>
        /// <param name="texto"></param>
        /// <returns></returns>
        //public static string FormatarTextoParaUrl(string texto)
        //{
        //    texto = RemoverAcentuacao(texto);

        //    var textoretorno = texto.Replace(" ", "");

        //    const string permitidos = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmonopqrstuvwxyz0123456789-_";

        //    for (var i = 0; i < texto.Length; i++)
        //        if (!permitidos.Contains(texto.Substring(i, 1))) { textoretorno = textoretorno.Replace(texto.Substring(i, 1), ""); }

        //    return textoretorno;
        //}

        /*
         Conceito de Slug
         * 
         public static string GenerateSlug(this string phrase) 
         { 
             string str = phrase.RemoveAccent().ToLower(); 
         
             str = Regex.Replace(str, @"[^a-z0-9\s-]", ""); // invalid chars           
             str = Regex.Replace(str, @"\s+", " ").Trim(); // convert multiple spaces into one space   
             str = str.Substring(0, str.Length <= 45 ? str.Length : 45).Trim(); // cut and trim it   
             str = Regex.Replace(str, @"\s", "-"); // hyphens   
         
             return str; 
         } 
         
         public static string RemoveAccent(this string txt) 
         { 
             byte[] bytes = System.Text.Encoding.GetEncoding("Cyrillic").GetBytes(txt); 
             return System.Text.Encoding.ASCII.GetString(bytes); 
         }
         
         */

        /// <summary>
        /// Desnecessário
        /// </summary>
        /// <param name="valor"></param>
        /// <param name="tamanho"></param>
        /// <returns></returns>
        public static string AjustarTexto(string valor, int tamanho)
        {
            if (valor.Length > tamanho)
            {
                valor = valor.Substring(1, tamanho);
            }
            return valor;
        }

        public static string ToTitleCase(string texto)
        {
            return ToTitleCase(texto, false);
        }

        public static string ToTitleCase(string texto, bool manterOqueJaEstiverMaiusculo)
        {
            texto = texto.Trim();

            if (!manterOqueJaEstiverMaiusculo)
                texto = texto.ToLower();

            var textInfo = new CultureInfo("pt-BR", false).TextInfo;
            return textInfo.ToTitleCase(texto);
        }

        public static string RemoverCaracteresEspeciais(this string texto)
        {
            if (string.IsNullOrEmpty(texto))
                return null;

            return Regex.Replace(texto, PatternCaracteresEspeciais, "");
        }

    }
}