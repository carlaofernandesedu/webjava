﻿using System;


namespace br.procon.si.Core.Domain.Helpers
{
    public class CascadingTypeAttribute : Attribute
    {
    }
}
