﻿using System;

namespace br.procon.si.Core.Domain.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        void BeginTransaction();
        void SaveChanges();

    }
}