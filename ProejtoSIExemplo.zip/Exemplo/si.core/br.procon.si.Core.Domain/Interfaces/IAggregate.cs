using System;

namespace br.procon.si.Core.Domain.Interfaces
{
    public interface IAggregate
    {
        Guid IdentificadorGlobal { get; }
    }
}