﻿namespace br.procon.si.Core.Domain.Interfaces
{
    public interface ISpecification<in TEntity>
    {
        bool IsSatisfiedBy(TEntity entity);

        string MensagemDeRetorno { get; }
    }
}