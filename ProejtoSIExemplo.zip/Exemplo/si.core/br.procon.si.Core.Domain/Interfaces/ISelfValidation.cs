﻿using br.procon.si.Core.Domain.ValueObjects;

namespace br.procon.si.Core.Domain.Interfaces
{
    public interface ISelfValidation
    {
        ValidationResult ValidationResult { get; }
        bool IsValid { get; }
    }
}