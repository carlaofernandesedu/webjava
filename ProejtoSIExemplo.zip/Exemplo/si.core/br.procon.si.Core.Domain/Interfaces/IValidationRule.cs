﻿namespace br.procon.si.Core.Domain.Interfaces
{
    public interface IValidationRule<in TEntity>
    {
        string ErrorMessage { get; }
        bool Valid(TEntity entity);
    }
}