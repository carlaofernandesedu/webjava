﻿using br.procon.si.Core.Domain.ValueObjects;

namespace br.procon.si.Core.Domain.Interfaces
{
    public interface IValidation<in TEntity>
    {
        ValidationResult Valid(TEntity entity);
    }
}