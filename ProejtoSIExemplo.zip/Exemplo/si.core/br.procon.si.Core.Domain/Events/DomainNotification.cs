﻿using System;
using br.procon.si.Core.Domain.Interfaces;
using br.procon.si.Core.Domain.ValueObjects;
using System.Linq;
using System.Collections.Generic;

namespace br.procon.si.Core.Domain.Events
{
    public class DomainNotification : IDomainEvent
    {
        public string Key { get; private set; }
        public string Value { get; private set; }
        public DateTime DataOcorrencia { get; private set; }
        public int Versao { get; private set; }

        public DomainNotification(string key, string value)
        {
            this.Versao = 1;
            this.Key = key;
            this.Value = value;
            this.DataOcorrencia = DateTime.Now;
        }

        public static List<DomainNotification> ConvertTo(ValidationResult validationResult)
        {
            if (validationResult == null) return null;
            var notifications = validationResult.Errors.Select(validationError => new DomainNotification(validationError.ToString(), validationError.Message)).ToList();
            return notifications.ToList();
        }
    }
}