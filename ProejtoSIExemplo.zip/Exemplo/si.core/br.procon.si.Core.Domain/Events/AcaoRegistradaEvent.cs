﻿using System;
using System.Reflection;
using br.procon.si.Core.Domain.Interfaces;
using System.Linq.Expressions;

namespace br.procon.si.Core.Domain.Events
{
    public class AcaoRegistradaEvent : IDomainEvent
    {
        public MethodBase Metodo { get; private set; }
        public int Codigo { get; private set; }
        public int TipoAcao { get; private set; }
        public DateTime DataOcorrencia { get; private set; }
        public int IdUsuario { get; private set; }
        public Guid? Identificador { get; private set; }
        public int Versao { get; private set; }
        public string Entidade { get; private set; }

        public Expression<Func<object>>[] Parametros;

        public string Mensagem;

        /// <summary>
        /// Nome da aplicação // acrescentado por Daniel em 20170626
        /// </summary>
        public string Aplicacao { get; set; }

        public AcaoRegistradaEvent(int tipoacao, int idUsuario, int codigo, string entidade)
        {
            Versao = 1;
            IdUsuario = idUsuario;
            Entidade = entidade;
            DataOcorrencia = DateTime.Now;
            Codigo = codigo;
            TipoAcao = tipoacao;
        }

        /// <summary>
        /// v1
        /// </summary>
        /// <param name="tipoacao"></param>
        /// <param name="idUsuario"></param>
        /// <param name="codigo"></param>
        /// <param name="entidade"></param>
        /// <param name="metodo"></param>
        /// <param name="identificador"></param>
        public AcaoRegistradaEvent(int tipoacao,int idUsuario, int codigo,string entidade,MethodBase metodo = null, Guid identificador = default(Guid))
        {
            Versao = 1;
            IdUsuario = idUsuario;
            Entidade = entidade; 
            DataOcorrencia = DateTime.Now;
            Codigo = codigo;
            TipoAcao = tipoacao;
            Metodo = metodo;
            Identificador = identificador;
        }

        /// <summary>
        /// v2
        /// </summary>
        /// <param name="idUsuario"></param>
        /// <param name="metodo"></param>
        /// <param name="parametros"></param>
        public AcaoRegistradaEvent(int idUsuario,  MethodBase metodo, params Expression<Func<object>>[] parametros)
        {
            Versao = 2;
            IdUsuario = idUsuario;
            DataOcorrencia = DateTime.Now;
            TipoAcao = Acao; 
            Parametros = parametros;
            Metodo = metodo;
        }

        /// <summary>
        /// v3
        /// </summary>
        /// <param name="idUsuario"></param>
        /// <param name="informacao"></param>
        public AcaoRegistradaEvent(int idUsuario, string informacao)
        {
            Versao = 3;
            IdUsuario = idUsuario;
            DataOcorrencia = DateTime.Now;
            TipoAcao = Acao;
            Mensagem = informacao;
        }

        public static readonly int Acao = 2;
        public static readonly int Insert = 3;
        public static readonly int Update = 4;
        public static readonly int Delete = 5;
        public static readonly int StatusAlterado = 6;
    }
}