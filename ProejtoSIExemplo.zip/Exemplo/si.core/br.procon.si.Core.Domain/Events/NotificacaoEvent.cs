﻿using br.procon.si.Core.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Core.Domain.Events
{
    public class NotificacaoEvent : IDomainEvent
    {
        public int Versao { get; private set; }

        public DateTime DataOcorrencia { get; private set; }

        public Guid Identificador { get; private set; }

        public NotificacaoEvent()
        {
            Versao = 1;
        }
    }
}
