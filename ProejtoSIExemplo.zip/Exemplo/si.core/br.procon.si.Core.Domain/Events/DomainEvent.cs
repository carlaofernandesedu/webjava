﻿using br.procon.si.Core.Domain.Interfaces;
using System.Threading.Tasks;

namespace br.procon.si.Core.Domain.Events
{
    public static class DomainEvent
    {
        public static IContainer Container { get; set; }

        public static void Raise<T>(T args) where T : IDomainEvent
        {
            if (Container == null) return;

            var obj = Container.GetInstance(typeof(IHandler<T>));
            if (obj == null) return;
            ((IHandler<T>)obj).Handle(args);
        }

        public static Task RaiseAsync<T>(T args) where T : IDomainEvent
        {
            if (Container == null) return new Task(() => { });
            var obj = Container.GetInstance(typeof(IHandler<T>));
            if (obj == null) return new Task(() => { });
            return ((IHandler<T>)obj).HandleAsync(args);
        }
    }
}