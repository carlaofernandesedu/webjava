﻿using System;
using System.Reflection;
using br.procon.si.Core.Domain.Interfaces;
using System.Linq.Expressions;


namespace br.procon.si.Core.Domain.Events
{
    public class EmailEnviadoEvent : IDomainEvent
    {

        public DateTime DataOcorrencia { get; private set; }
        public Guid Identificador { get; private set; }
        public int Versao { get; private set; }
        public string Assunto { get; private set; }
        public string Destinatario { get; private set; }
        public string Mensagem { get; private set; }

        public EmailEnviadoEvent(string assunto, string destinatario, string mensagem, Guid identificador)
        {
            Versao = 1;
            Assunto = assunto;
            Destinatario = destinatario;
            Mensagem = mensagem;
            DataOcorrencia = DateTime.Now;
            Identificador = identificador;
        }
    }
}
