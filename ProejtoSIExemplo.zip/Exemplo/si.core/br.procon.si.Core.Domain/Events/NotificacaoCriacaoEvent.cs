﻿using br.procon.si.Core.Domain.Interfaces;
using System;

namespace br.procon.si.Core.Domain.Events
{
    public class NotificacaoCriacaoEvent : IDomainEvent
    {
        public DateTime DataOcorrencia { get; private set; }
        public Guid Identificador { get; private set; }
        public int Versao { get; private set; }

        public int Id { get; set; }
        public int IdFormaNotificacao { get; set; }
        public string NomeDestinatario { get; set; }
        public string Destinatario { get; set; }
        public string Assunto { get; set; }
        public string Mensagem { get; set; }
        public int IdUsuarioCriacao { get; set; }
        public int IdUsuarioInternet { get; set; }

        public NotificacaoCriacaoEvent(Guid identificador, int idFormaNotificacao, string nomeDestinatario, string destinatario, string assunto, string mensagem, int idUsuarioCriacao)
        {
            Versao = 1;
            DataOcorrencia = DateTime.Now;
            Identificador = identificador;

            this.IdFormaNotificacao = idFormaNotificacao;
            this.NomeDestinatario = nomeDestinatario;
            this.Destinatario = destinatario;
            this.Assunto = assunto;
            this.Mensagem = mensagem;
            this.IdUsuarioCriacao = idUsuarioCriacao;
        }

        public NotificacaoCriacaoEvent(Guid identificador, int idUsuarioInternet,string nomeDestinatario, string assunto, string mensagem, int idUsuarioCriacao)
        {
            Versao = 2;
            DataOcorrencia = DateTime.Now;
            Identificador = identificador;
            this.IdUsuarioInternet = idUsuarioInternet;
            this.NomeDestinatario = nomeDestinatario;
            this.Assunto = assunto;
            this.Mensagem = mensagem;
            this.IdUsuarioCriacao = idUsuarioCriacao;
        }
    }
}