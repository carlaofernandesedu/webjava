﻿using System;
using br.procon.si.Core.Domain.Interfaces;

namespace br.procon.si.Core.Domain.Events
{
    public class ErroLancadoEvent : IDomainEvent
    {
        public Exception Erro { get; private set; }
        public string Servico { get; private set; }
        public string Metodo { get; private set; }
        public DateTime DataOcorrencia { get; private set; }
        public int IdUsuario { get; private set; }
        public Guid? Identificador { get; private set; }
        public int Versao { get; private set; }

        public ErroLancadoEvent(Exception erro, int idUsuario, string servico, string metodo) : this(erro, idUsuario, servico, metodo, null)
        {
        }

        public ErroLancadoEvent(Exception erro, int idUsuario, string servico, string metodo, Guid? identificador)
        {
            Versao = 1;
            IdUsuario = idUsuario;
            Erro = erro;
            Metodo = metodo;
            Servico = servico;
            Identificador = identificador;
            DataOcorrencia = DateTime.Now;
        }
    }
}