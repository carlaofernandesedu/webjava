﻿using System;
using System.Reflection;
using br.procon.si.Core.Domain.Interfaces;
using System.Linq.Expressions;

namespace br.procon.si.Core.Domain.Events
{
    public class ProtocoloSolicitadoEvent : IDomainEvent
    {
        public DateTime DataOcorrencia { get; private set; }
        public int IdUsuario { get; private set; }
        public Guid Identificador { get; private set; }
        public int Versao { get; private set; }

        public dynamic DadosSolicitante {get; private set; }
        
        public ProtocoloSolicitadoEvent(int idUsuario, Guid identificadorOperacao)
        {
            Versao = 1;
            IdUsuario = idUsuario;
            DataOcorrencia = DateTime.Now;
            Identificador = identificadorOperacao;
        }

        public ProtocoloSolicitadoEvent(int idUsuario, Guid identificadorOperacao, dynamic dadosSolicitante)
        {
            Versao = 2;
            IdUsuario = idUsuario;
            DataOcorrencia = DateTime.Now;
            Identificador = identificadorOperacao;
            DadosSolicitante = dadosSolicitante;
        }
    }
}