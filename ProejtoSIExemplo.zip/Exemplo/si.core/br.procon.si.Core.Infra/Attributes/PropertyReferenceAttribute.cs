﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Core.Infra.Attributes
{
    public class PropertyReferenceAttribute : Attribute
    {
        public string OtherPropertyName { get; private set; }

        public PropertyReferenceAttribute(string propertyName)
        {
            OtherPropertyName = propertyName;
        }
    }
}
