﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Reflection;
using System.Linq.Expressions;

namespace br.procon.si.Core.Infra.Models
{
    /// <summary>
    /// Classe que representa uma Aplicação.
    /// </summary>
    public class LogAplicacao
    {
        #region Construtores

        /// <summary>
        /// Construtor Padrão.
        /// </summary>
        public LogAplicacao() { }

        #endregion

        #region Propriedades Públicas

        public Exception Ex { get; set; }

        [Column("id_log_aplicacao")]
        [Display(Name = "Código")]
        public int Codigo { get; set; }
        [Column("dt_log")]
        [Display(Name = "Data")]
        public DateTime Data { get; set; }
        [Column("id_usuario")]
        public int IdUsuario { get; set; }

        [Column("ds_login")]
        [Display(Name = "Usuário")]
        public string Usuario { get; set; }

        [Display(Name = "Ação")]
        public TipoLog TipoLog { 
            get 
            {
                return (TipoLog)IdTipoLog;
            }
            set
            {
                IdTipoLog = (int)value;
            }
        }

        [Column("id_tipo_log")]
        public int IdTipoLog { get; set; }


        [Column("ds_aplicacao")]
        public string Aplicacao { get; set; }
        
        [Column("ds_recurso")]
        [Display(Name = "Recurso")]
        public string Recurso { get; set; }
        [Column("ds_tabela")]
        public string Tabela { get; set; }
        [Column("ds_registro")]
        public string Registro { get; set; }
        [Column("ds_mensagem")]
        [Display(Name = "Mensagem")]
        public string Mensagem { get; set; }
        [Display(Name = "StackTrace")]
        public string StackTrace { get; set; }
        [Column("ds_exception")]
        public string Exception { get; set; }

        [Column("ds_razao_social")]
        public string Empresa { get; set; }

        [Column("ds_classe")]
        public string NomeClasse { get; set; }
        [Column("ds_metodo")]
        public string NomeMetodo { get; set; }
        [Column("ds_parametros")]
        public string ParametrosSerializados { get; set; }
        public MethodBase Metodo {get; set;}
        public Expression<Func<object>>[] Parametros { get; set; }

        [Column("nr_ip_usuario")]
        
        public string IpUsuario { get; set; }

        #endregion

        public void DefinirIpUsuario(string IpUsuario)
        {
            this.IpUsuario = IpUsuario;
        }
        public static class LogAplicacaoFactory
        {
            public static LogAplicacao LogAplicacaoporErro(string aplicacao, Exception ex, int idUsuario, DateTime dataOcorrencia, TipoLog tipo)
            {
                return new LogAplicacao()
                {
                    Data = dataOcorrencia,
                    Aplicacao = aplicacao,
                    TipoLog = tipo,
                    IdUsuario = idUsuario,
                    Mensagem = ex.Message,
                    StackTrace = ex.StackTrace,
                    Exception = ex.ToString(),
                    Ex = ex
                };
            }

            public static LogAplicacao LogAplicacaoporErro(string aplicacao, Exception ex, int idUsuario, DateTime dataOcorrencia, TipoLog tipo, Expression<Func<object>>[] parametros)
            {
                return new LogAplicacao()
                {
                    Data = dataOcorrencia,
                    Aplicacao = aplicacao,
                    TipoLog = tipo,
                    IdUsuario = idUsuario,
                    Mensagem = ex.Message,
                    StackTrace = ex.StackTrace,
                    Exception = ex.ToString(),
                    Ex = ex,
                    Parametros = parametros
                };
            }

            public static LogAplicacao LogAplicacaoporErro(Exception ex, int idUsuario, string nomePagina, DateTime dataOcorrencia, TipoLog tipo)
            {
                return new LogAplicacao()
                {
                    Data = dataOcorrencia,
                    Aplicacao = "Fiscalização",
                    TipoLog = tipo,
                    IdUsuario = idUsuario,
                    Mensagem = ex.Message,
                    StackTrace = ex.StackTrace,
                    Recurso = nomePagina,
                    Exception = ex.ToString(),
                    Ex = ex
                };
            }

            public static LogAplicacao LogAplicacaoporAcao(int idUsuario, string nomePagina, string idregistro, string tabela, DateTime dataOcorrencia, TipoLog tipo)
            {
                return new LogAplicacao()
                {
                    Data = dataOcorrencia,
                    Aplicacao = "Fiscalização",
                    TipoLog = tipo,
                    IdUsuario = idUsuario,
                    Registro = idregistro,
                    Mensagem = tabela.ToLower().IndexOf("service") > -1 ? String.Format("{0} do registro {1} via servico {2}", tipo, idregistro, tabela) : String.Format("{0} do registro {1} na tabela {2}", tipo, idregistro, tabela),
                    Tabela = tabela,
                    Recurso = nomePagina,
                    NomeClasse = string.Empty,
                    NomeMetodo = string.Empty
                };
            }

            public static LogAplicacao LogAplicacaoporAcao(int idUsuario, string nomePagina, string idregistro, string tabela, DateTime dataOcorrencia, TipoLog tipo, MethodBase metodo)
            {
                return new LogAplicacao()
                {
                    Data = dataOcorrencia,
                    Aplicacao = "Fiscalização",
                    TipoLog = tipo,
                    IdUsuario = idUsuario,
                    Registro = idregistro,
                    Mensagem = tabela.ToLower().IndexOf("service") > -1 ? String.Format("{0} do registro {1} via servico {2}", tipo, idregistro, tabela) : String.Format("{0} do registro {1} na tabela {2}", tipo, idregistro, tabela),
                    Tabela = tabela,
                    Recurso = nomePagina,
                    NomeClasse = (metodo != null) ? metodo.DeclaringType.FullName : string.Empty,
                    NomeMetodo = (metodo != null) ? metodo.Name : string.Empty
                };
            }

            public static LogAplicacao LogAplicacaoporMetodo(int idUsuario, string nomePagina, DateTime dataOcorrencia, TipoLog tipo, MethodBase metodo, Expression<Func<object>>[] parametros)
            {
                return new LogAplicacao()
                {
                    Data = dataOcorrencia,
                    Aplicacao = "Fiscalização",
                    TipoLog = tipo,
                    IdUsuario = idUsuario,
                    Mensagem = "log detalhado",
                    NomeClasse = metodo.DeclaringType.FullName,
                    Metodo = metodo,
                    NomeMetodo = metodo.Name,
                    Parametros = parametros,
                    Recurso = nomePagina
                 };
            }

            public static LogAplicacao LogAplicacaoporMensagem(int idUsuario, DateTime dataOcorrencia, TipoLog tipo, string mensagem)
            {
                return LogAplicacaoporMensagem(null, idUsuario, dataOcorrencia, tipo, mensagem);
            }
            public static LogAplicacao LogAplicacaoporMensagem(string aplicacao, int idUsuario, DateTime dataOcorrencia, TipoLog tipo, string mensagem)
            {
                return new LogAplicacao()
                {
                    Data = dataOcorrencia,
                    Aplicacao = string.IsNullOrEmpty(aplicacao) ? "Fiscalização" : aplicacao,
                    TipoLog = tipo,
                    IdUsuario = idUsuario,
                    Mensagem = mensagem,
                    Recurso = ""
                };
            }
        }   

    }
}
