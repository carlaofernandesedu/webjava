﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Core.Infra
{
    public abstract class ObjetoPaginaLista
    {
        private ObjetoPaginaListaCaracteristicas _caracteristicas;

        public ObjetoPaginaLista()
        {
            _caracteristicas = _caracteristicas ?? new ObjetoPaginaListaCaracteristicas();
        }

        public string Id { get; set; }

        [Column("Acoes")]
        public IEnumerable<ObjetoPaginaListaAcao> Acoes { get; set; }

        public bool PodeEditar { get; set; }

        public ObjetoPaginaListaCaracteristicas Caracteristicas
        {
            get
            {
                return _caracteristicas;
            }
            set
            {
                _caracteristicas = value;
            }
        }
    }

    public class ObjetoPaginaListaAcao
    {
        public string Label { get; set; }

        public string Url { get; set; }

        public string Icone { get; set; }

        public string Tipo { get; set; }

        public string Title { get; set; }

        public string Classe { get; set; }

        public bool Disabled { get; set; }
    }

    public class ObjetoPaginaListaCaracteristicas
    {
        public bool Destaque { get; set; }

        public int? Colcentralizar { get; set; }
    }
}