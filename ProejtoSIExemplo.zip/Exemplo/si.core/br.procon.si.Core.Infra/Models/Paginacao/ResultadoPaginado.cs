﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Core.Infra
{

    public class ResultadoPaginado<T>
    {
        public int Total { get; private set; }
        public int PaginaAtual { get; private set; }
        public int QtdItensPorPagina { get; private set; }

        public IEnumerable<T> Itens { get; set; }

        public ResultadoPaginado(int total, int paginaAtual, int qtdItensPorPagina, IEnumerable<T> itens)
        {
            this.PaginaAtual = paginaAtual;
            this.QtdItensPorPagina = qtdItensPorPagina;
            this.Total = total;
            this.Itens = itens;
        }
    }
}
