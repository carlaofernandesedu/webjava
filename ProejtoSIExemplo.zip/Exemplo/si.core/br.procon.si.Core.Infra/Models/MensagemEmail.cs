﻿namespace br.procon.si.Core.Infra.Interfaces
{
    public class MensagemEmail
    {
        public string Subject { get; set; }
        public string Body { get; set; }
        public string Destination { get; set; }
    }
}