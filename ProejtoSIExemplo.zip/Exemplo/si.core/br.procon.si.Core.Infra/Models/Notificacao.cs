﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Core.Infra.Models
{
    public class Notificacao
    {
        [Display(Name = "Id")]
        [Column("id_notificacao")]
        public int Id { get; set; }

        [Display(Name = "Forma de Notificacao")]
        [Column("id_forma_notificacao")]
        public int IdFormaNotificacao { get; set; }

        [Display(Name = "Nome do Destinatário")]
        [Column("no_destinatario")]
        public string NomeDestinatario { get; set; }

        [Display(Name = "Email")]
        [Column("ds_destinatario")]
        public string Destinatario { get; set; }

        [Display(Name = "Assunto")]
        [Column("ds_assunto")]
        public string Assunto { get; set; }

        [Display(Name = "Mensagem")]
        [Column("ds_mensagem")]
        public string Mensagem { get; set; }

        [Display(Name = "Enviada")]
        [Column("bl_enviado")]
        public bool Enviada { get; set; }

        [Display(Name = "Data de Envio")]
        [Column("dt_envio")]
        public DateTime? DataEnvio { get; set; }

        [Display(Name = "Número de Tentativas")]
        [Column("nr_tentativas_envio")]
        public int Tentativas { get; set; }

        [Display(Name = "Data de Criação")]
        [Column("dt_criacao")]
        public DateTime DataCriacao { get; set; }

        [Display(Name = "Usuário de Criação")]
        [Column("id_usuario_criacao")]
        public int IdUsuarioCriacao { get; set; }

        [Display(Name = "Data de Alteração")]
        [Column("dt_alteracao")]
        public DateTime? DataAlteracao { get; set; }

        [Display(Name = "Usuário de Alteração")]
        [Column("id_usuario_alteracao")]
        public int? UsuarioAlteracao { get; set; }
    }
}