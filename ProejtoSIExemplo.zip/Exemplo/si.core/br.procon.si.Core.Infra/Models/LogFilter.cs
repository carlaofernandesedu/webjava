﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Core.Infra.Models
{
    public class LogFilter
    {
        public int? Codigo { get; set; }
        public int? IdEmpresa { get; set; }
        public int? IdAplicacao { get; set; }
        public int? IdPerfil { get; set; }
        public int? IdRecurso { get; set; }
        public int? IdUsuario { get; set; }
        public TipoLog? Acao { get; set; }
        public DateTime? DataInicial { get; set; }
        public DateTime? DataFinal { get; set; }
        public string Arquivo { get; set; }
    }
}

