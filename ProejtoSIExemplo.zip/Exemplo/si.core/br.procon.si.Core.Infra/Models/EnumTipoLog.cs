﻿namespace br.procon.si.Core.Infra.Models
{
    public enum TipoLog
    {
        Erro = 1,
        Acao = 2,
        Insert = 3,
        Update = 4,
        Delete = 5,
        StatusAlterado = 6
    }
}
