﻿using System;


namespace br.procon.si.Core.Infra.Helpers
{
    public class CascadingTypeAttribute : Attribute
    {
    }
}
