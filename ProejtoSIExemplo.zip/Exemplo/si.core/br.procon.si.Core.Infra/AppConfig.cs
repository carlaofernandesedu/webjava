﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace br.procon.si.Core.Infra
{
    public static class AppConfig
    {
        private static string _conexaoBancodeDados;
        public static string ConexaoBancoDeDados
        {
            get { return _conexaoBancodeDados; }
            set { _conexaoBancodeDados = value; }
        }

        private static SmtpSection _smtpSection;
        public static SmtpSection SmtpSection
        {
            get { return _smtpSection; }
            set { _smtpSection = value; }
        }

        private static int _hourStart;
        public static int HourStart
        {
            get { return _hourStart; }
            set { _hourStart = value; }
        }
        private static int _hourEnd;
        public static int HourEnd
        {
            get { return _hourEnd; }
            set { _hourEnd = value; }
        }
        private static int _timeSchedule;
        public static int TimeSchedule
        {
            get { return _timeSchedule; }
            set { _timeSchedule = value; }
        }


        private static string _facebookAppId;
        public static string FacebookAppId
        {
            get { return _facebookAppId; }
            set { _facebookAppId = value; }
        }

        private static string _facebookAppSecret;
        public static string FacebookAppSecret
        {
            get { return _facebookAppSecret; }
            set { _facebookAppSecret = value; }
        }

        private static string _twitterAppKey;
        public static string TwitterAppKey
        {
            get { return _twitterAppKey; }
            set { _twitterAppKey = value; }
        }

        private static string _twitterAppSecret;
        public static string TwitterAppSecret
        {
            get { return _twitterAppSecret; }
            set { _twitterAppSecret = value; }
        }

        private static int _idUsuarioNotificacao;
        public static int IdUsuarioNotificacao
        {
            get { return _idUsuarioNotificacao; }
            set { _idUsuarioNotificacao = value; }
        }

        private static string _proxy;
        public static string Proxy
        {
            get { return _proxy; }
            set { _proxy = value; }
        }

        public static int UsuarioAplicacao {
            get
            {
                var configId = ConfigurationManager.AppSettings["UsuarioAplicacao"];

                if (string.IsNullOrWhiteSpace(configId))
                {
                    configId = "1";
                }

                var id = Convert.ToInt32(configId);

                return id;
            }
        }


        public static void Inicializar()
        {
            _conexaoBancodeDados = ConfigurationManager.ConnectionStrings[ConfigurationManager.ConnectionStrings.Count - 1].ConnectionString;
            _smtpSection = (SmtpSection)ConfigurationManager.GetSection("system.net/mailSettings/smtp");

            _hourStart = Convert.ToInt32(ConfigurationManager.AppSettings["HourStart"]);
            _hourEnd = Convert.ToInt32(ConfigurationManager.AppSettings["HourEnd"]);
            _timeSchedule = Convert.ToInt32(ConfigurationManager.AppSettings["TimeSchedule"]);

            _facebookAppId = ConfigurationManager.AppSettings["facebookAppId"];
            _facebookAppSecret = ConfigurationManager.AppSettings["facebookAppSecret"];

            _twitterAppKey = ConfigurationManager.AppSettings["twitterAppKey"];
            _twitterAppSecret = ConfigurationManager.AppSettings["twitterAppSecret"];

            _idUsuarioNotificacao = Convert.ToInt32(ConfigurationManager.AppSettings["idUsuarioNotificacao"]);


            _proxy = ConfigurationManager.AppSettings["proxy"] ?? string.Empty;
        }
    }
}