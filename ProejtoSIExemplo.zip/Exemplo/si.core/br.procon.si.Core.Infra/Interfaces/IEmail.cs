﻿using System.Threading.Tasks;

namespace br.procon.si.Core.Infra.Interfaces
{
    public interface IEmail
    {
        Task EnviarAsync(MensagemEmail mensagem);
        void Enviar(MensagemEmail mensagem);
    }
}
