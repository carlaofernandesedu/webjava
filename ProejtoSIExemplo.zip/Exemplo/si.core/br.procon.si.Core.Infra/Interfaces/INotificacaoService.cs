﻿using br.procon.si.Core.Infra.Models;
using System;
using System.Collections.Generic;

namespace br.procon.si.Core.Infra.Interfaces
{
    public interface INotificacaoService
    {
        void Criar(int idFormaNotificacao, string nomeDestinatario, string destinatario, string assunto, string mensagem, int idUsuarioCriacao);

        void Atualizar(int idNotificacao, int idFormaNotificacao, string nomeDestinatario, string destinatario, string assunto, string mensagem, bool enviado, DateTime? dataEnvio, DateTime? dataAlteracao, int? idUsuarioAlteracao, int numeroTentativas);

        IEnumerable<Notificacao> Obter(Notificacao filtro, bool? enviadas);
    }
}