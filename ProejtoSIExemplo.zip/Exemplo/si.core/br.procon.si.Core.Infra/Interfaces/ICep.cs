﻿namespace br.procon.si.Core.Infra.Interfaces
{
    public interface ICep
    {
        string GetEnderecoByCep(string cep);
    }
}
