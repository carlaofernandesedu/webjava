﻿
using System;
using System.Threading.Tasks;
namespace br.procon.si.Core.Infra.Interfaces
{
    public interface INotificacaoProviderService
    {
        void Enviar(string destinatario, string mensagem, string assunto);
    }
}
