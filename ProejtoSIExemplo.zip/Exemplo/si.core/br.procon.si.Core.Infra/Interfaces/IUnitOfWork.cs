﻿using System;

namespace br.procon.si.Core.Infra.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        void BeginTransaction();
        void SaveChanges();

    }
}