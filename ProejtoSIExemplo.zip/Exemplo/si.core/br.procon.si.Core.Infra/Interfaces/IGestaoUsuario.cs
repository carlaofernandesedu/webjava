﻿using br.procon.si.Core.Infra.Models;

namespace br.procon.si.Core.Infra.Interfaces
{
    public interface IGestaoUsuario
    {
        SignInStatus Login(LoginViewModel vmodel);

        bool PersistirUsuario(RegisterViewModel vmodel);
    }
}
