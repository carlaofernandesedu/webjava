﻿using br.procon.si.Core.Infra.Models;
using System.Collections.Generic;

namespace br.procon.si.Core.Infra.Interfaces
{
    public interface ILog
    {
        void Save(LogAplicacao log);
        IEnumerable<LogAplicacao> Search(LogFilter filtro);
    }
}
