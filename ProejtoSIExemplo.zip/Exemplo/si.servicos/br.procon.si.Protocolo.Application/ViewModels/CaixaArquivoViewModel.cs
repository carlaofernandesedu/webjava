﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace br.procon.si.Protocolo.Application.ViewModels
{
    public class CaixaArquivoViewModel : BaseViewModel
    {
        #region Propriedade

        public int Id { get; set; }

        [Required(ErrorMessage = "O campo 'Identificação' é de preenchimento obrigatório.")]
        [Display(Name = "Identificação")]
        public string Codigo { get; set; }

        [Required(ErrorMessage = "O campo 'Descrição' é de preenchimento obrigatório.")]
        [Display(Name = "Descrição")]
        public string Descricao { get; set; }

        [Display(Name = "Ativo")]
        public bool Ativo { get; set; }

        [Display(Name = "Série Documental")]
        public short? IdSerieDocumental { get; set; }

        [Display(Name = "Série Documental")]
        public string SerieDocumental { get; set; }

        [Display(Name = "UA")]
        public int IdUa { get; set; }

        [Display(Name = "Período Início")]
        public DateTime? PeriodoInicio { get; set; }

        [Display(Name = "Período Fim")]
        public DateTime? PeriodoFim { get; set; }

        [Display(Name = "UA Produtora")]
        public Int16? IdUAProdutora { get; set; }

        public int? IdLocalArquivo { get; set; }

        public int? IdMovelArquivo { get; set; }

        [Display(Name = "Divisão")]
        public int? IdMovelDivisao { get; set; }

        #region Geração de Proposta

        [Display(Name = "UA")]
        public string NomeUA { get; set; }

        [Display(Name = "Item")]
        public int Item { get; set; }

        [Display(Name = "Nº Proposta")]
        public string PropostaDescricao { get; set; }

        [Display(Name = "Período")]
        public string PeriodoDescricao
        {
            get
            {
                var sb = new StringBuilder();

                if (this.PeriodoInicio.HasValue)
                {
                    sb.Append(" De ");
                    sb.Append(this.PeriodoInicio.Value.ToShortDateString());
                    sb.Append(" ");
                }

                if (this.PeriodoFim.HasValue)
                {
                    sb.Append("Até ");
                    sb.Append(this.PeriodoFim.Value.ToShortDateString());
                }

                return sb.ToString();
            }
        }

        public decimal NrVolumeDocumento { get; set; }

        public string Local { get; set; }

        public string Movel { get; set; }

        public string Divisao { get; set; }

        public string Caixa { get; set; }

        public int IdProposta { get; set; }

        public br.procon.si.Protocolo.Domain.ValueObjects.Enums.EnumSituacaoPropostaEliminacaoItem Situacao { get; set; }

        #endregion Geração de Proposta

        #endregion Propriedade

        #region Construtor

        public CaixaArquivoViewModel()
        {
        }

        public CaixaArquivoViewModel(int id, string codigo, string descricao, bool ativo, int idMovelDivisao, int idUa, short? idSerieDocumental)
        {
            Id = id;
            Codigo = codigo;
            Descricao = descricao;
            Ativo = ativo;
            IdMovelDivisao = idMovelDivisao;
            IdUa = idUa;
            IdSerieDocumental = idSerieDocumental;
        }

        #endregion Construtor
    }
}