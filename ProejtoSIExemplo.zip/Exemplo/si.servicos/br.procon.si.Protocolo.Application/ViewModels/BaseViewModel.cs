﻿namespace br.procon.si.Protocolo.Application.ViewModels
{
    public class BaseViewModel
    {
        public virtual int IdUsuarioOperacao { get; set; }
    }
}