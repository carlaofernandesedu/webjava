﻿using br.procon.si.Protocolo.Domain.ValueObjects.Enums;
using System.ComponentModel.DataAnnotations;

namespace br.procon.si.Protocolo.Application.ViewModels
{
    public class DocumentoCaixaArquivoViewModel : BaseViewModel
    {
        #region Propriedade

        public int IdCaixaArquivo { get; set; }

        public int IdDocumentoVolume { get; set; }

        [Display(Name = "Protocolo")]
        public string NumeroProtocoloFormatado { get; set; }

        [Display(Name = "Processo")]
        public string NumeroProcessoFormatado { get; set; }

        [Display(Name = "Série Documental")]
        public string SerieDocumentalFormatada { get; set; }

        [Display(Name = "Volume")]
        public decimal Volume { get; set; }

        public EnumTipoArquivamento TipoArquivamento { get; set; }

        public int NumeroProtocolo { get; set; }

        public int AnoProtocolo { get; set; }

        public int IdDocumento { get; set; }

        [Display(Name = "Assunto")]
        public string AssuntoDocumento { get; set; }

        #endregion Propriedade

        #region Construtor

        public DocumentoCaixaArquivoViewModel()
        {
        }

        public DocumentoCaixaArquivoViewModel(int idCaixaArquivo, int idDocumentoVolume, string numeroProtocoloFormatado, string numeroProcessoFormatado, string serieDocumentalFormatada, decimal volume)
        {
            IdCaixaArquivo = idCaixaArquivo;
            IdDocumentoVolume = idDocumentoVolume;
            NumeroProtocoloFormatado = numeroProtocoloFormatado;
            NumeroProcessoFormatado = numeroProcessoFormatado;
            SerieDocumentalFormatada = serieDocumentalFormatada;
            Volume = volume;
        }

        #endregion Construtor
    }
}