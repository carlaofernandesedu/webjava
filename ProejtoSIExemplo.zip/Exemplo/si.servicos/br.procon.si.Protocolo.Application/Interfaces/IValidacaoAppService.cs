﻿using br.procon.si.Core.Domain.ValueObjects;

namespace br.procon.si.Protocolo.Application.Interfaces
{
    public interface IValidacaoAppService
    {
        ValidationResult ObterUltimasNotificacoesDeDominio();
    }
}