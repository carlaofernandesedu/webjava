﻿using br.procon.si.Protocolo.Application.ViewModels;
using System;
using System.Collections.Generic;

namespace br.procon.si.Protocolo.Application.Interfaces
{
    public interface ICaixaArquivoAppService : IDisposable, IValidacaoAppService
    {
        IEnumerable<CaixaArquivoViewModel> ObterCaixasArquivosPorCodigoDescricao(string codigo, string descricao, bool? ativo);

        CaixaArquivoViewModel SalvarCaixaArquivo(CaixaArquivoViewModel viewModel);

        CaixaArquivoViewModel ExcluirCaixaArquivo(CaixaArquivoViewModel viewModel);

        CaixaArquivoViewModel ObterCaixaArquivo(int id_caixa_arquivo);

        List<DocumentoCaixaArquivoViewModel> ObterDocumentosDaCaixa(int id_caixa_arquivo);
    }
}