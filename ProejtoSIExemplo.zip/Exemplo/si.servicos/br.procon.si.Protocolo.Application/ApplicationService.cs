﻿using br.procon.si.Core.Domain.Interfaces;
using br.procon.si.Core.Domain.ValueObjects;
using br.procon.si.Core.Domain.Events;
using System.Reflection;
using System.Linq.Expressions;
using System;
using br.procon.si.Protocolo.Application.Interfaces;
using System.Linq;



namespace br.procon.si.Protocolo.Application
{
    public class ApplicationService : IValidacaoAppService, IDisposable
    {
       private readonly IUnitOfWork _unitOfWork;
       protected bool HabilitarLogDetalhado = true;
       private string _identUow;

        public ApplicationService(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
            _identUow = string.Empty;
        }

        protected ValidationResult ValidationResult { get; set; }

        public ValidationResult ObterUltimasNotificacoesDeDominio()
        {
            var retorno = new ValidationResult();
            if (ValidationResult != null)
            {
                foreach (var item in ValidationResult.Errors)
                {
                    retorno.Add(item);
                }
                ValidationResult = new ValidationResult();
            }
            return retorno;
        }

        public  void BeginTransaction()
        {
            #if (!DEBUG)
                 _unitOfWork.BeginTransaction();
                 _identUow = Guid.NewGuid().ToString();
            #endif
            //if (!String.IsNullOrEmpty(_identUow))
            //    LogarEvento(AcaoRegistradaEvent.Acao, 0, 0, "transacao_por_service " + _identUow, MethodBase.GetCurrentMethod());
        }

        public void Commit()
        {
 
            #if (!DEBUG)
                _unitOfWork.SaveChanges();
            #endif 
            //if (!String.IsNullOrEmpty(_identUow))
            //    LogarEvento(AcaoRegistradaEvent.Acao, 0, 0, "transacao_por_service " + _identUow, MethodBase.GetCurrentMethod());
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public void Dispose(bool disposing)
        {
            if (disposing)
            {
                _unitOfWork.Dispose();
                //if (!String.IsNullOrEmpty(_identUow))
                //    LogarEvento(AcaoRegistradaEvent.Acao, 0, 0, "transacao_por_service " + _identUow, MethodBase.GetCurrentMethod()); 
            }
        }

        public void LogarDetalhesEvento(int idUsuario, string informacao)
        {
            try
            {
                if (HabilitarLogDetalhado)
                {
                    DomainEvent.Raise<AcaoRegistradaEvent>(new AcaoRegistradaEvent(idUsuario, informacao));
                }
            }
            catch { }
        }
        public void LogarDetalhesEvento(int idUsuario, MethodBase metodo, params Expression<Func<object>>[] parametros)
        {
            try
            {
                if (HabilitarLogDetalhado)
                {
                   DomainEvent.Raise<AcaoRegistradaEvent>(new AcaoRegistradaEvent(idUsuario, metodo, parametros));
                }
            }
            catch { }
        }

        public void LogarEvento(int tipoacao, int idUsuario,int codigo, string entidade,MethodBase metodo = null, Guid identificador = default(Guid))
        {
            try
            {
              DomainEvent.Raise<AcaoRegistradaEvent>(new AcaoRegistradaEvent(tipoacao, idUsuario,codigo,entidade,metodo,identificador));
            }
            catch { }
        }

        

    }
}
