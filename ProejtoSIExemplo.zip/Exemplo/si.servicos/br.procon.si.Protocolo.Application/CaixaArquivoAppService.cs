﻿using br.procon.si.Core.Domain.Events;
using br.procon.si.Core.Domain.Interfaces;
using br.procon.si.Protocolo.Application.Interfaces;
using br.procon.si.Protocolo.Application.ViewModels;
using br.procon.si.Protocolo.Domain.Interfaces;
using System.Collections.Generic;
using System.Reflection;

namespace br.procon.si.Protocolo.Application
{
    public class CaixaArquivoAppService : ApplicationService, ICaixaArquivoAppService
    {
        private readonly ICaixaArquivoRepository _caixaArquivoRepository;
        private readonly ICaixaArquivoService _caixaArquivoService;
  
        public CaixaArquivoAppService(ICaixaArquivoService caixaArquivoService,
            ICaixaArquivoRepository caixaArquivoRepository,
            IUnitOfWork uow)
            : base(uow)
        {
            _caixaArquivoService = caixaArquivoService;
            _caixaArquivoRepository = caixaArquivoRepository;
        }


        public IEnumerable<CaixaArquivoViewModel> ObterCaixasArquivosPorCodigoDescricao(string codigo, string descricao, bool? ativo)
        {
            return Adapters.CaixaArquivoAdapter.ConverterParaViewModel(_caixaArquivoService.ObterCaixasArquivosPorCodigoDescricao(codigo, descricao, ativo));
        }


        public CaixaArquivoViewModel SalvarCaixaArquivo(CaixaArquivoViewModel viewModel)
        {
            LogarDetalhesEvento(viewModel.IdUsuarioOperacao, MethodBase.GetCurrentMethod(), () => viewModel);
            LogarEvento(AcaoRegistradaEvent.Insert, viewModel.IdUsuarioOperacao, viewModel.Id, this.GetType().Name, MethodBase.GetCurrentMethod());

            if (viewModel.IdLocalArquivo.Equals(null))
                viewModel.IdLocalArquivo = 0;

            if (viewModel.IdMovelArquivo.Equals(null))
                viewModel.IdMovelArquivo = 0;

            if (viewModel.IdMovelDivisao.Equals(null))
                viewModel.IdMovelDivisao = 0;

            var dominio = Adapters.CaixaArquivoAdapter.ConverterParaDominio(viewModel);

            BeginTransaction();
            var retorno = _caixaArquivoService.SalvarCaixaArquivo(dominio);
            Commit();

            base.ValidationResult = retorno.ValidationResult;
            return Adapters.CaixaArquivoAdapter.ConverterParaViewModel(retorno);
        }

        public CaixaArquivoViewModel ExcluirCaixaArquivo(CaixaArquivoViewModel viewModel)
        {
            LogarDetalhesEvento(viewModel.IdUsuarioOperacao, MethodBase.GetCurrentMethod(), () => viewModel);
            LogarEvento(AcaoRegistradaEvent.Delete, viewModel.IdUsuarioOperacao, viewModel.Id, this.GetType().Name, MethodBase.GetCurrentMethod());

            var dominio = Adapters.CaixaArquivoAdapter.ConverterParaDominio(viewModel);

            BeginTransaction();
            var retorno = _caixaArquivoService.ExcluirCaixaArquivo(dominio);
            Commit();

            base.ValidationResult = retorno.ValidationResult;
            return Adapters.CaixaArquivoAdapter.ConverterParaViewModel(retorno);
        }

        public CaixaArquivoViewModel ObterCaixaArquivo(int id_caixa_arquivo)
        {
            CaixaArquivoViewModel viewModel = Adapters.CaixaArquivoAdapter.ConverterParaViewModel(_caixaArquivoRepository.Obter(id_caixa_arquivo));

            return viewModel;
        }

        public List<DocumentoCaixaArquivoViewModel> ObterDocumentosDaCaixa(int id_caixa_arquivo)
        {
            var model = Adapters.DocumentoCaixaArquivoAdapter.ConverterParaViewModel(_caixaArquivoRepository.ObterDocumentosDaCaixa(id_caixa_arquivo));

            return model;
        }

    }
}