﻿using br.procon.si.Protocolo.Application.ViewModels;
using br.procon.si.Protocolo.Domain.Entities;
using System.Collections.Generic;

namespace br.procon.si.Protocolo.Application.Adapters
{
    public static class CaixaArquivoAdapter
    {
        public static CaixaArquivo ConverterParaDominio(this CaixaArquivoViewModel viewModel)
        {
            CaixaArquivo caixa = CaixaArquivo.CaixaArquivoFactory.CaixaArquivo(viewModel.Id, viewModel.Codigo, viewModel.Descricao, viewModel.Ativo, (int)viewModel.IdMovelDivisao, viewModel.IdUa, viewModel.IdSerieDocumental);
            caixa.DefinirIdUAProdutora(viewModel.IdUAProdutora);//caixa.DefinirIdUAProdutora(Convert.ToInt16(viewModel.IdUAProdutora));
            caixa.DefinirDataInicio(viewModel.PeriodoInicio);
            caixa.DefinirDataFim(viewModel.PeriodoFim);
            caixa.IdUsuarioOperacao = viewModel.IdUsuarioOperacao;
            return caixa;
        }

        public static List<CaixaArquivo> ConverterParaDominio(this IEnumerable<CaixaArquivoViewModel> colViewModel)
        {
            List<CaixaArquivo> retorno = new List<CaixaArquivo>();

            if (colViewModel != null)
            {
                foreach (CaixaArquivoViewModel view in colViewModel)
                {
                    retorno.Add(ConverterParaDominio(view));
                }
            }

            return retorno;
        }

        public static CaixaArquivoViewModel ConverterParaViewModel(this CaixaArquivo dominio)
        {
            CaixaArquivoViewModel viewModel = new CaixaArquivoViewModel(dominio.Id, dominio.Codigo, dominio.Descricao, dominio.Ativo, dominio.IdMovelDivisao, dominio.IdUa, dominio.IdSerieDocumental);

            viewModel.Id = dominio.Id;
            viewModel.Codigo = dominio.Codigo;
            viewModel.Descricao = dominio.Descricao;
            viewModel.IdSerieDocumental = dominio.IdSerieDocumental;
            viewModel.IdMovelDivisao = dominio.IdMovelDivisao;
            viewModel.IdUAProdutora = dominio.IdUAProdutora;
            viewModel.PeriodoInicio = dominio.DtInicio;
            viewModel.PeriodoFim = dominio.DtFim;
            viewModel.Ativo = dominio.Ativo;
            viewModel.SerieDocumental = dominio.SerieDocumental;

            return viewModel;
        }

        public static List<CaixaArquivoViewModel> ConverterParaViewModel(this IEnumerable<CaixaArquivo> colDom)
        {
            List<CaixaArquivoViewModel> retorno = new List<CaixaArquivoViewModel>();

            if (colDom != null)
            {
                foreach (CaixaArquivo dom in colDom)
                {
                    retorno.Add(ConverterParaViewModel(dom));
                }
            }

            return retorno;
        }
    }
}