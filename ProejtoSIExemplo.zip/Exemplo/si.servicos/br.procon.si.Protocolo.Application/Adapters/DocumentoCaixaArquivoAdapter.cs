﻿using br.procon.si.Protocolo.Application.ViewModels;
using br.procon.si.Protocolo.Domain.ValueObjects;
using System.Collections.Generic;

namespace br.procon.si.Protocolo.Application.Adapters
{
    public static class DocumentoCaixaArquivoAdapter
    {
        public static DocumentoCaixaArquivoViewModel ConverterParaViewModel(this DocumentoCaixaArquivo dominio)
        {
            return new DocumentoCaixaArquivoViewModel(dominio.IdCaixaArquivo, dominio.IdDocumentoVolume, dominio.NumeroProtocoloFormatado, string.Empty, dominio.SerieDocumentalFormatada, dominio.Volume);
        }

        public static List<DocumentoCaixaArquivoViewModel> ConverterParaViewModel(this IEnumerable<DocumentoCaixaArquivo> colDom)
        {
            List<DocumentoCaixaArquivoViewModel> retorno = new List<DocumentoCaixaArquivoViewModel>();

            if (colDom != null)
            {
                foreach (DocumentoCaixaArquivo dom in colDom)
                {
                    retorno.Add(ConverterParaViewModel(dom));
                }
            }

            return retorno;
        }
    }
}