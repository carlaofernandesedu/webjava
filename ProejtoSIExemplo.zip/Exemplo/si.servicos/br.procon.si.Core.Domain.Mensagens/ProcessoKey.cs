﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Core.Domain.Mensagens
{
    public static partial class Dicionario
    {
        public static partial class ErrosChaves
        {

        }

        public static partial class CriticasChaves
        {
            public const string Processo_Atribuicao_Protocolo = "Processo_Atribuicao_Protocolo";
            public const string Processo_Ua_Posse = "Processo_Ua_Posse";
            public const string Processo_Ua_Produtora = "Processo_Ua_Produtora";
            public const string Processo_Sigiloso = "Processo_Sigiloso";
            public const string Processo_Tramitacao = "Processo_Tramitacao";
            public const string Processo_Documento_Juntada_Usuario_Pertencente = "Processo_Documento_Juntada_Usuario_Pertencente";
            public const string Processo_Documento_Volume_Data_Abertura = "Processo_Documento_Volume_Data_Abertura";
            public const string Processo_Documento_Volume_Numero_Volume = "Processo_Documento_Volume_Primeiro_Volume";
            public const string Processo_Documento_Volume_Situacao_Em_Aberto = "Processo_Documento_Volume_Situacao_Em_Aberto";
            public const string Processo_Documento_Movimentacao_bl_Movimentacao_Manual = "Processo_Documento_Movimentacao_bl_Movimentacao_Manual";
            public const string Processo_Documento_Movimentacao_Data_Movimentacao_Inferior_Data_Autuacao_Processo = "Processo_Documento_Movimentacao_Data_Movimentacao_Inferior_Data_Autuacao_Processo";
            public const string Processo_Documento_Descricao = "Processo_Documento_Descricao";
            public const string Processo_Documento_Apensar_Processo_Principal = "Processo_Documento_Apensar_Processo_Principal";
            public const string Processo_Documento_Apensar_Processo_Desapensamento = "Processo_Documento_Apensar_Processo_Desapensamento";
            public const string Processo_Documento_Apensar_Processo_Apensado = "Processo_Documento_Apensar_Processo_Apensado";
            public const string Processo_Documento_Apensar_Alterar_Data = "Processo_Documento_Apensar_Alterar_Data";
            public const string Processo_Documento_Desapensar_Alterar_Data = "Processo_Documento_Desapensar_Alterar_Data";           
            public const string Processo_Documento_Apensar_Data_Movimentacao_Posterior = "Processo_Documento_Apensar_Data_Movimentacao_Posterior";
            public const string Processo_Solicitacao_Autuacao_Cancelamento_Status_Aberta = "Processo_Solicitacao_Autuacao_Cancelamento_Status_Aberta";
            public const string Processo_Documento_Apensar_Existecia_Circular = "Processo_Documento_Apensar_Existecia_Circular";
            public const string Processo_Documento_Apensar_Duplicidade = "Processo_Documento_Apensar_Duplicidade";
            public const string Processo_Solicitacao_Atuacao_Duplicidade = "Processo_Solicitacao_Atuacao_Duplicidade";
            public const string Processo_Solicitacao_Procedimento_Duplicidade = "Processo_Solicitacao_Procedimento_Duplicidade";
            public const string Processo_Em_Remessa = "Processo_Em_Remessa";
            public const string Processo_Em_Encaminhamento_Remessa = "Processo_Em_Encaminhamento_Remessa";
            public const string Processo_Incorporado = "Processo_Incorporado";
            public const string Processo_Arquivado = "Processo_Arquivado";
            public const string Processo_Unidade_Administrativa_divergente = "Processo_Unidade_Administrativa_divergente";
            public const string Processo_Solicitacao_Situacao_Deve_ser_Pendente = "Processo_Solicitacao_Situacao_Deve_ser_Pendente";
            public const string Processo_Solicitacao_Procedimento_Documento_Encaminhado_Para_Outro_Destino = "Processo_Solicitacao_Procedimento_Documento_Encaminhado_Para_Outro_Destino";
            public const string Processo_Solicitacao_Procedimento_Cancelar_Documento_Encaminhado_Destino = "Processo_Solicitacao_Procedimento_Cancelar_Documento_Encaminhado_Destino";
            public const string Processo_Documento_Volume_Existe_Juntada_Incorporado = "Protocolo_Documento_Volume_Existe_Juntada_Incorporado";
            public const string Processo_SolicitacaoAutuacaoValidarAcoesSpec = "Processo_SolicitacaoAutuacaoValidarAcoesSpec";
        }
    }
}