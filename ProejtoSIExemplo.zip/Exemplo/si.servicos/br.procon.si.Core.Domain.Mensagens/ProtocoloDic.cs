﻿using System.Collections.Generic;

namespace br.procon.si.Core.Domain.Mensagens
{
    public static partial class Dicionario
    {
        private static Dictionary<string, string> dicProtocolo;

        private static Dictionary<string, string> ObterDicionarioProtocolo()
        {
            var dicionario = new Dictionary<string, string>(3);

            dicionario.Add(CriticasChaves.Protocolo_Nome, "Informe um nome");
            dicionario.Add(CriticasChaves.Protocolo_ExcluirPartes, "É necessário 2 partes para poder excluir");
            dicionario.Add(ErrosChaves.Protocolo_ExclusaoLogica, "Erro de operação");
            dicionario.Add(CriticasChaves.Processo_Documento_Volume_Data_Abertura, "A Data de abertura do 'Primeiro Volume' de um processo não pode ser alterada");
            dicionario.Add(CriticasChaves.Protocolo_Documento_Valido, "Número de protocolo inválido");
            dicionario.Add(CriticasChaves.Protocolo_MovelArquivoUaUsuarioDivergeUaLocalArquivo, "A Unidade Administrativa do usuário é diferente da Unidade Administrativa do Local do Arquivo");
            dicionario.Add(CriticasChaves.Protocolo_MovelArquivoDivisaoDuplicada, "Móvel contém divisões duplicadas");
            dicionario.Add(CriticasChaves.Protocolo_MovelArquivoNaoPodeExcluirDivisaoComCaixaAssociada, "Não é possível excluir. Móvel de aquivo possui divisões com caixas de arquivos associadas");
            dicionario.Add(CriticasChaves.Protocolo_DivisaoArquivoNaoPodeExcluirPossuiCaixaAssociada, "Não é possível excluir. Divisão possui caixa de arquivo associada");
            dicionario.Add(CriticasChaves.Protocolo_MovelArquivoCodigoDuplicado, "Já existe um móvel cadastrado com o mesmo código");
            dicionario.Add(CriticasChaves.Protocolo_MovelArquivoUaAtribuicaoProtocolo, "Unidade Administrativa do usuário não possui Atribuição de Protocolo");
            dicionario.Add(CriticasChaves.Protocolo_CaixaArquivoCodigoDuplicado, "Já existe uma caixa de arquivo cadastrada com o mesmo código");
            dicionario.Add(CriticasChaves.Protocolo_CaixaArquivoUaUsuarioDivergeUaCaixa, "A Unidade Administrativa do usuário é diferente da Unidade Administrativa da caixa de arquivo");
            dicionario.Add(CriticasChaves.Protocolo_CaixaArquivoNaoPodeExcluirCaixaComDocumento, "Não é possível excluir. Caixa de arquivo possui documento associado");
            dicionario.Add(CriticasChaves.Protocolo_ArquivamentoCaixaDeveEstarAtiva, "Caixa de Arquivo deve estar ativa");
            dicionario.Add(CriticasChaves.Protocolo_ArquivamentoVolumeDeveEstarEmAndamento, "Volume deve estar na situação \"Em Andamento\"");
            dicionario.Add(CriticasChaves.Protocolo_ArquivamentoVolumeDeveEstarDesarquivadoSemReabertura, "Volume deve estar na situação \"Desarquivado Sem Reabertura\"");
            dicionario.Add(CriticasChaves.Protocolo_ArquivamentoVolumeDeveEstarArquivado, "Volume deve estar na situação \"Arquivado\"");
            dicionario.Add(CriticasChaves.Protocolo_ArquivamentoDocumentoDevePertencerUaUsuario, "Documento deve pertencer a mesma Unidade Administrativa do usuário");
            dicionario.Add(CriticasChaves.Protocolo_ArquivamentoDocumentoDevePossuirMesmaSerieDocumentalDaCaixa, "Documento deve possuir a mesma série documental da caixa de arquivos");
            dicionario.Add(CriticasChaves.Protocolo_ArquivamentoCaixaDevePertencerUaUsuario, "Caixa de Arquivo deve pertencer a mesma Unidade Administrativa do usuário");
            dicionario.Add(CriticasChaves.Protocolo_Status_Valido, "Status do protocolo inválido");
            dicionario.Add(CriticasChaves.Protocolo_ArquivamentoDocumentoDevePossuirMesmaUAProdutoraDaCaixa, "Caixa de arquivo e documento devem ser da mesma unidade administrativa");
            dicionario.Add(CriticasChaves.Protocolo_ArquivamentoDocumentoDeveEstarNoPeriodoDeDataDaCaixa, "Data do Documento deve corresponder ao período da caixa");
            dicionario.Add(CriticasChaves.Protocolo_ModeloDocumentoSerieDocumentalClassificacaoDeveSerAvulso, "Classificação da série documental deve ser do tipo avulso");
            dicionario.Add(CriticasChaves.Protocolo_DocumentoSimplesUARestricao, "Documento possui restrição de unidade administrativa");
            dicionario.Add(CriticasChaves.Protocolo_DocumentoSimplesUACriacao, "Documento é diferente da unidade administrativa");
            dicionario.Add(CriticasChaves.Protocolo_CaixaArquivoExistePropostaEliminacao, "Caixa já possui uma proposta de eliminação em andamento");
            dicionario.Add(CriticasChaves.Protocolo_CaixaArquivoExisteArquivamento, "Caixa já possui um histórico de arquivamento");
            dicionario.Add(CriticasChaves.Protocolo_ArquivamentoDeveValidarDuplicidadeSpec, "O volume informado já foi arquivado!");
            dicionario.Add(CriticasChaves.Protocolo_CaixaArquivoDeveValidarEdicao, "Caixa já possui processos arquivados, informações de temporalidade não podem ser alteradas!");
            dicionario.Add(CriticasChaves.Protocolo_ArquivamentoDeveValidarDocumentoEmAndamento, "Processo em andamento e com série documental não pode ser arquivado nessa caixa!");
            dicionario.Add(CriticasChaves.Protocolo_DocumentoDevePossuiDataAprovacaoConta, "Documento deve possui uma data de aprovação de conta!");

            return dicionario;
        }

        public static Dictionary<string, string> Protocolo
        {
            get
            {
                if (dicProtocolo == null)
                    dicProtocolo = ObterDicionarioProtocolo();

                return dicProtocolo;
            }
        }
    }
}