﻿namespace br.procon.si.Core.Domain.Mensagens
{
    public static partial class Dicionario
    {
        public static partial class ErrosChaves
        {
        }

        public static partial class CriticasChaves
        {
            public const string Atendimento_consumidor_naopreferencial = "Atendimento_consumidor_naopreferencial";
            public const string Atendimento_AlertaCpfAssociadoOutroUsuario = "Atendimento_AlertaCpfAssociadoOutroUsuario";
            public const string Atendimento_AlertaDuplicidadeCpf = "Atendimento_AlertaDuplicidadeCpf";
            public const string Atendimento_AlertaDadosRg = "Atendimento_AlertaDadosRg";
            public const string Atendimento_AlertaTipoDeficiencia = "Atendimento_AlertaTipoDeficiencia";
            public const string Atendimento_EmAtendimentoPeloTecnico = "Atendimento_EmAtendimentoPeloTecnico";
            public const string Atendimento_AtendimentoEncerradoPeloTecnico = "Atendimento_AtendimentoEncerradoPeloTecnico";
            public const string Atendimento_AtendimentoGrupoFornecedorDuplicado = "Atendimento_AtendimentoGrupoFornecedorDuplicado";
            public const string Atendimento_AtendimentoGrupoFornecedorCNPJDuplicado = "Atendimento_AtendimentoGrupoFornecedorCNPJDuplicado";
            public const string Atendimento_AtendimentoGrupoFornecedorFornecedorTipoInverso = "Atendimento_AtendimentoGrupoFornecedorFornecedorTipoInverso";
            public const string Atendimento_classificacaoinvalido = "Atendimento_classificacaoinvalido";
            public const string Atendimento_datacompra_invalido = "Atendimento_datacompra_invalido";
            public const string Atendimento_descricaoinvalido = "Atendimento_descricaoinvalido";
            public const string Atendimento_descricaominmaxinvalido = "Atendimento_descricaominmaxinvalido";
            public const string Atendimento_descricaoreclamacaoinvalido = "Atendimento_descricaoreclamacaoinvalido";
            public const string Atendimento_documentonvalido = "Atendimento_documentonvalido";
            public const string Atendimento_dtnascimentoinvalido = "Atendimento_dtnascimentoinvalido";
            public const string Atendimento_emailinvalido = "Atendimento_emailinvalido";
            public const string Atendimento_endereconumeroinvalido = "Atendimento_endereconumeroinvalido";
            public const string Atendimento_estadoinvalido = "Atendimento_estadoinvalido";
            public const string Atendimento_meioaquisicaoinvalido = "Atendimento_meioaquisicaoinvalido";
            public const string Atendimento_logradouroinvalido = "Atendimento_logradouroinvalido";
            public const string Atendimento_nomefornecedorinvalido = "Atendimento_nomefornecedorinvalido";
            public const string Atendimento_objetoreclamado_invalido = "Atendimento_objetoreclamado_invalido";
            public const string Atendimento_operacaonaopermitida = "Atendimento_operacaonaopermitida";
            public const string Atendimento_parametroinvalido = "Atendimento_parametroinvalido";
            public const string Atendimento_pedidoconsumidorinvalido = "Tipo Pedido Obrigatório";
            public const string Atendimento_registronaoencontrado = "Atendimento_registronaoencontrado";
            public const string Atendimento_usuarioinvalido = "Atendimento_usuarioinvalido";
            public const string Atendimento_ValidarIteracao = "Atendimento_ValidarIteracao";
            public const string Atendimento_ValidarInsercaoIteracao = "Atendimento_InserirIteracao";
            public const string Atendimento_AquisicaoAnexo_Excluir = "Atendimento_AquisicaoAnexo_Excluir";
            public const string Atendimento_AquisicaoAnexo_TamanhoArquivo = "Atendimento_AquisicaoAnexo_TamanhoArquivo";
            public const string Atendimento_AquisicaoAnexo_NumeroMaxArquivo = "Atendimento_AquisicaoAnexo_NumeroMaxArquivo";
            public const string Atendimento_AtendimentoInteracaoValidarFluxo = "Atendimento_AtendimentoInteracaoValidarFluxo";
            public const string Atendimento_AtendimentoFichaValidarAtribuicao = "Atendimento_AtendimentoFichaValidarAtribuicao";
            public const string Atendimento_AtendimentoFichaValidarRegrasFuncionais = "Atendimento_AtendimentoFichaValidarRegrasFuncionais";
            public const string Atendimento_descricaoconsultaobrigatoria = "Atendimento_descricaoconsultaobrigatoria";
            public const string Atendimento_classificacaoobrigatorio = "Atendimento_classificacaoobrigatorio";
            public const string Atendimento_AtendimentoFichaConsultaCriada = "Atendimento_AtendimentoFichaConsultaCriada";
            public const string Atendimento_MensagemConsultaCancelada = "Atendimento_MensagemConsultaCancelada";            
            public const string Atendimento_FormaPagamentoInvalida = "Atendimento_FormaPagamentoInvalida";  
            public const string Atendimento_DescricaoObrigatoria = "Atendimento_DescricaoObrigatoria"; 

            public const string Atendimento_consumidor_nomeobrigatorio = "Atendimento_consumidor_nomeobrigatorio";
            public const string Atendimento_cpfinvalido = "Atendimento_cpfinvalido";
            public const string Atendimento_consumidor_dtnascimentoinvalido = "Atendimento_consumidor_dtnascimentoinvalido";
            public const string Atendimento_consumidor_sexoobrigatorio = "Atendimento_consumidor_sexoobrigatorio";
            public const string Atendimento_consumidor_cepobrigatorio = "Atendimento_consumidor_cepobrigatorio";
            public const string Atendimento_consumidor_numeroLogradouroinvalido = "Atendimento_consumidor_numeroLogradouroinvalido";
            public const string Atendimento_consumidor_logradouroobrigatorio = "Atendimento_consumidor_logradouroobrigatorio";
            public const string Atendimento_consumidor_cidadeobrigatoria = "Atendimento_consumidor_cidadeobrigatoria";
            public const string Atendimento_MensagemNaoEPossivelGerarCip = "Atendimento_MensagemNaoEPossivelGerarCip";
            public const string Atendimento_consumidorsexoinvalido = "Atendimento_consumidorsexoinvalido";
            public const string Atendimento_AquisicaoAnexo_ExtensaoArquivo = "Atendimento_AquisicaoAnexo_ExtensaoArquivo";
            public const string AtendimentoInteracao_PodeBuscarTecnicoSpec = "AtendimentoInteracao_PodeBuscarTecnicoSpec";

        }

        public static partial class InfoChaves
        {
            public const string Atendimento_SucessoOperacao = "Atendimento_SucessoOperacao";
            public const string Atendimento_SucessoAlteracao = "Atendimento_SucessoAlteracao";
            public const string Atendimento_AquisicaoAnexo_AnexoExcluido = "Atendimento_AquisicaoAnexo_AnexoExcluido";
            public const string Atendimento_SucessoCancelamento = "Atendimento_SucessoCancelamento";
            public const string Atendimento_SolicitacaoAtendimentoIncluida = "Atendimento_SolicitacaoAtendimentoIncluida";
        }
    }
}