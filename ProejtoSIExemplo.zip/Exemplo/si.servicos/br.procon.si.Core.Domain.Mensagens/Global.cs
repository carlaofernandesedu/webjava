﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Core.Domain.Mensagens
{
    public static partial class  Dicionario
    {
        public static partial class ErrosChaves { }
        public static partial class InfoChaves { }
        public static partial class CriticasChaves { }
    } 
}
