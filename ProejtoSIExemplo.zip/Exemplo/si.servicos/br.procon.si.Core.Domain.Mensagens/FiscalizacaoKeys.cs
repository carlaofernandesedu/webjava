﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Core.Domain.Mensagens
{
    public static partial class Dicionario
    {
        public static partial class ErrosChaves
        {
            public const string Fiscalizacao_Chave1 = "Fiscalizacao_Chave1";
        }
        public static partial class CriticasChaves
        {
            
        }
        public static partial class InfoChaves
        {

        }
    }
}
