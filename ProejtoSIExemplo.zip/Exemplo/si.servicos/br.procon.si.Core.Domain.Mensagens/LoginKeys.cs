﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Core.Domain.Mensagens
{
    public static partial class Dicionario
    {
        public static partial class ErrosChaves
        {
        }

        public static partial class CriticasChaves
        {
            public const string Login_UsuarioOuSenhaErrada = "Login_UsuarioOuSenhaErrada";
            public const string Login_UsuarioBloqueado = "Login_UsuarioBloqueado";
            public const string Login_EmailDuplicado = "Login_EmailDuplicado";
            public const string Login_SenhaEmbraco = "Login_SenhaEmbraco";
            public const string Login_EmailIncorreto = "Login_EmailIncorreto";
            public const string Login_NomeIncorreto = "Login_NomeIncorreto";
            public const string Login_SenhaIncorreta = "Login_SenhaIncorreta";
            public const string Login_ConfirmacaoSenhaIncorreta = "Login_ConfirmacaoSenhaIncorreta";
            public const string Login_UsuarioCriado = "Login_UsuarioCriado";
        }

        public static partial class InfoChaves
        {
        }
    }
}
