﻿using System.Collections.Generic;

namespace br.procon.si.Core.Domain.Mensagens
{
    public static partial class Dicionario
    {
        private static Dictionary<string, string> dicAtendimento;

        private static Dictionary<string, string> ObterDicionarioAtendimento()
        {
            var dicionario = new Dictionary<string, string>(2);
            dicionario.Add(InfoChaves.Atendimento_SucessoOperacao, "Operação Concluída com Sucesso!");
            dicionario.Add(InfoChaves.Atendimento_SucessoAlteracao, "Registro alterado com sucesso!");
            dicionario.Add(InfoChaves.Atendimento_SucessoCancelamento, "Operação Cancelada com sucesso");
            dicionario.Add(InfoChaves.Atendimento_SolicitacaoAtendimentoIncluida, "Solicitação de atendimento registrada com sucesso!O prazo máximo de retorno deste atendimento é de {0} dias");
            dicionario.Add(InfoChaves.Atendimento_AquisicaoAnexo_AnexoExcluido, "Anexo removido com sucesso");
            dicionario.Add(CriticasChaves.Atendimento_AlertaDuplicidadeCpf, "Este documento já está cadastrado no Sistema, porém há divergência na data de nascimento");
            dicionario.Add(CriticasChaves.Atendimento_AlertaDadosRg, "Os dados do Rg são de preenchimento obrigatório.");
            dicionario.Add(CriticasChaves.Atendimento_AlertaTipoDeficiencia, "O Tipo de Deficiência são de preenchimento obrigatório.");
            dicionario.Add(CriticasChaves.Atendimento_EmAtendimentoPeloTecnico, "Ficha em atendimento Pelo Técnico.");
            dicionario.Add(CriticasChaves.Atendimento_AtendimentoEncerradoPeloTecnico, "Atendimento encerrado Pelo técnico.");
            dicionario.Add(CriticasChaves.Atendimento_AtendimentoGrupoFornecedorDuplicado, "Já existe um grupo com este nome.");
            dicionario.Add(CriticasChaves.Atendimento_AtendimentoGrupoFornecedorCNPJDuplicado, "Fornecedor já se encontra ativo em outro grupo.");
            dicionario.Add(CriticasChaves.Atendimento_AtendimentoGrupoFornecedorFornecedorTipoInverso, "Não é possivel alterar o grupo de Simulação para Estatistico.");
            dicionario.Add(CriticasChaves.Atendimento_estadoinvalido, "Estado Obrigatório");
            dicionario.Add(CriticasChaves.Atendimento_meioaquisicaoinvalido, "Meio de Aquisição obrigatório");
            dicionario.Add(CriticasChaves.Atendimento_logradouroinvalido, "Atendimento_logradouroinvalido");
            dicionario.Add(CriticasChaves.Atendimento_nomefornecedorinvalido, "Informe Nome do Fornecedor");
            dicionario.Add(CriticasChaves.Atendimento_objetoreclamado_invalido, "Atendimento_objetoreclamado_invalido");
            dicionario.Add(CriticasChaves.Atendimento_operacaonaopermitida, "Operação não permitida");
            dicionario.Add(CriticasChaves.Atendimento_parametroinvalido, "Atendimento_parametroinvalido");
            dicionario.Add(CriticasChaves.Atendimento_pedidoconsumidorinvalido, "Pedido obrigatório");
            dicionario.Add(CriticasChaves.Atendimento_registronaoencontrado, "Atendimento_registronaoencontrado");
            dicionario.Add(CriticasChaves.Atendimento_ValidarIteracao, "Não é possível editar uma iteração para este tipo de atendimento");
            dicionario.Add(CriticasChaves.Atendimento_AquisicaoAnexo_Excluir, "Não é possível excluir o anexo.");
            dicionario.Add(CriticasChaves.Atendimento_AtendimentoInteracaoValidarFluxo, "Procedimento não permitido.");
            dicionario.Add(CriticasChaves.Atendimento_AtendimentoFichaValidarAtribuicao, "Atribuição não permitida.");
            dicionario.Add(CriticasChaves.Atendimento_AtendimentoFichaValidarRegrasFuncionais, "Ação não permitida");
            dicionario.Add(CriticasChaves.Atendimento_ValidarInsercaoIteracao, "Informe uma interação");
            dicionario.Add(CriticasChaves.Atendimento_descricaoconsultaobrigatoria, "Descrição deve ter no mínimo 50 caracteres");
            dicionario.Add(CriticasChaves.Atendimento_classificacaoobrigatorio, "Informe uma classificação");
            dicionario.Add(CriticasChaves.Atendimento_AtendimentoFichaConsultaCriada, "Solicitação efetuada com sucesso! Solicitação será atendida até {0}");
            dicionario.Add(CriticasChaves.Atendimento_MensagemConsultaCancelada, "Cancelamento realizado pelo usuário");
            dicionario.Add(CriticasChaves.Atendimento_emailinvalido, "Email não informado ou inválido");
            dicionario.Add(CriticasChaves.Atendimento_consumidor_nomeobrigatorio, "Campo Nome obrigatório");
            dicionario.Add(CriticasChaves.Atendimento_cpfinvalido, "CPF não informado ou inválido");
            dicionario.Add(CriticasChaves.Atendimento_consumidor_dtnascimentoinvalido, "Data de Nascimento não informado ou inválido");
            dicionario.Add(CriticasChaves.Atendimento_consumidor_sexoobrigatorio, "Campo sexo preenchimento obrigatório");
            dicionario.Add(CriticasChaves.Atendimento_consumidor_numeroLogradouroinvalido, "Numero do Logradouro não informado ou inválido");
            dicionario.Add(CriticasChaves.Atendimento_consumidor_cepobrigatorio, "CEP obrigatório");
            dicionario.Add(CriticasChaves.Atendimento_consumidor_logradouroobrigatorio, "Logradouro obrigatório");
            dicionario.Add(CriticasChaves.Atendimento_consumidor_cidadeobrigatoria, "Cidade obrigatória");
            dicionario.Add(CriticasChaves.Atendimento_usuarioinvalido, "Codigo Usuario nao informado");
            dicionario.Add(CriticasChaves.Atendimento_MensagemNaoEPossivelGerarCip, "Não é possível gerar uma Cip para este atendimento!");
            dicionario.Add(CriticasChaves.Atendimento_AlertaCpfAssociadoOutroUsuario, "Já existe um CPF associado a outro usuário!");
            dicionario.Add(CriticasChaves.Atendimento_AquisicaoAnexo_TamanhoArquivo, "Tamanho do arquivo excedeu o permitido para upload");
            dicionario.Add(CriticasChaves.Atendimento_AquisicaoAnexo_NumeroMaxArquivo, "Numero maximo de Arquivos armazenados atingido");
            dicionario.Add(CriticasChaves.Atendimento_AquisicaoAnexo_ExtensaoArquivo, "Extensão de arquivo não permitida");
            dicionario.Add(CriticasChaves.Atendimento_FormaPagamentoInvalida, "Forma de pagamento obrigatoria");
            dicionario.Add(CriticasChaves.AtendimentoInteracao_PodeBuscarTecnicoSpec, "Não é permitido a busca por nome do técnico");

            return dicionario;
        }

        public static Dictionary<string, string> Atendimento
        {
            get
            {
                if (dicAtendimento == null)
                    dicAtendimento = ObterDicionarioAtendimento();

                return dicAtendimento;
            }
        }
    }
}