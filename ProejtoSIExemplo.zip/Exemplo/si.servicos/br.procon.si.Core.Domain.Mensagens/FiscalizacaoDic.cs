﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Core.Domain.Mensagens
{
    public static partial class Dicionario
    {
        private static Dictionary<string, string> dicFiscalizacao;
        private static Dictionary<string,string> ObterDicionarioFiscalizacao()
        {
            var dicionario = new Dictionary<string, string>(1);
            dicionario.Add(ErrosChaves.Fiscalizacao_Chave1, "z");
            return dicionario;
        }
        public static Dictionary<string, string> Fiscalizacao
        {
            get
            {
                if (dicFiscalizacao == null)
                   dicFiscalizacao = ObterDicionarioFiscalizacao();

                return dicFiscalizacao;
            }
        }
    }
}
