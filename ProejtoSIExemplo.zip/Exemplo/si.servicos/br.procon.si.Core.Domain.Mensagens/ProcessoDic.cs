﻿using System.Collections.Generic;

namespace br.procon.si.Core.Domain.Mensagens
{
    public static partial class Dicionario
    {
        private static Dictionary<string, string> dicProcesso;

        private static Dictionary<string, string> ObterDicionarioProcesso()
        {
            var dicionario = new Dictionary<string, string>();
            dicionario.Add(CriticasChaves.Processo_Atribuicao_Protocolo, "Processo sem atribuição de Protocolo.");
            dicionario.Add(CriticasChaves.Processo_Ua_Posse, "Processo sem UA de Posse");
            dicionario.Add(CriticasChaves.Processo_Ua_Produtora, "Processo sem UA Produtora");
            dicionario.Add(CriticasChaves.Processo_Tramitacao, "Processo sem acesso de tramitação");
            dicionario.Add(CriticasChaves.Processo_Sigiloso, "Processo Sigiloso");
            dicionario.Add(CriticasChaves.Processo_Documento_Juntada_Usuario_Pertencente, "Somente o usuário pertencente à unidade pode modificar a juntada");
            dicionario.Add(CriticasChaves.Processo_Documento_Movimentacao_bl_Movimentacao_Manual, "Registro não deve ser excluído");
            dicionario.Add(CriticasChaves.Processo_Documento_Movimentacao_Data_Movimentacao_Inferior_Data_Autuacao_Processo, "Data de movimentação não deve ser inferior a data de autuação do processo");
            dicionario.Add(CriticasChaves.Processo_Documento_Volume_Numero_Volume, "O 'primeiro volume' de um processo não pode ser excluido");
            dicionario.Add(CriticasChaves.Processo_Documento_Volume_Situacao_Em_Aberto, "A situação do volume de ser 'Em andamento'");
            dicionario.Add(CriticasChaves.Processo_Documento_Volume_Data_Abertura, "Não é possível alterar a data do Volume 1.");
            dicionario.Add(CriticasChaves.Processo_Documento_Descricao, "Descrição do documento deve ser obrigatório");
            dicionario.Add(CriticasChaves.Processo_Solicitacao_Autuacao_Cancelamento_Status_Aberta, "Status da solicitação não permite cancelamento.");
            dicionario.Add(CriticasChaves.Processo_Documento_Apensar_Processo_Principal, "O apensamento deve ocorrer obrigatoriamente a partir do processo principal");
            dicionario.Add(CriticasChaves.Processo_Documento_Apensar_Processo_Desapensamento, "Este processo encontra-se desapensado");
            dicionario.Add(CriticasChaves.Processo_Documento_Apensar_Processo_Apensado, "Este processo encontra-se apensado");
            dicionario.Add(CriticasChaves.Processo_Documento_Apensar_Alterar_Data, "Existem movimentações entre as datas de apensamento");
            dicionario.Add(CriticasChaves.Processo_Documento_Apensar_Data_Movimentacao_Posterior, "Existem registros de movimentações posteriores à data do apensamento");
            dicionario.Add(CriticasChaves.Processo_Documento_Desapensar_Alterar_Data, "Existem movimentações entre as datas de desapensamento");
            dicionario.Add(CriticasChaves.Processo_Documento_Apensar_Existecia_Circular, "O processo não pode ser apensamedo no mesmo");
            dicionario.Add(CriticasChaves.Processo_Documento_Apensar_Duplicidade, "O processo está apensado ou contém um apensamento, favor desapensar para salvar o processo.");
            dicionario.Add(CriticasChaves.Processo_Solicitacao_Atuacao_Duplicidade, "Documento não pode ser anexado! Já existe uma solicitação aberta");
            dicionario.Add(CriticasChaves.Processo_Solicitacao_Procedimento_Duplicidade, "Documento não pode ser anexado! Já existe uma solicitação aberta");
            dicionario.Add(CriticasChaves.Processo_Em_Remessa, "Este processo encontra-se em remessa");
            dicionario.Add(CriticasChaves.Processo_Em_Encaminhamento_Remessa, "Este processo encontra-se em encaminhamento para a Remessa");
            dicionario.Add(CriticasChaves.Processo_Incorporado, "Documento não pode ser anexado! Já existe uma solicitação aberta");
            dicionario.Add(CriticasChaves.Processo_Arquivado, "Este processo encontra-se arquivado");
            dicionario.Add(CriticasChaves.Processo_Unidade_Administrativa_divergente, "Unidade Administrativa divergente do documento ou do documento secundario");
            dicionario.Add(CriticasChaves.Processo_Solicitacao_Situacao_Deve_ser_Pendente, "A solicitação deve estar com a situação 'pendente' para ser cancelada");
            dicionario.Add(CriticasChaves.Processo_Solicitacao_Procedimento_Documento_Encaminhado_Para_Outro_Destino, "O documento encontra-se encaminhado para outro destino");
            dicionario.Add(CriticasChaves.Processo_Solicitacao_Procedimento_Cancelar_Documento_Encaminhado_Destino, "O Documento já encontra-se encaminhado. Remova o documento do encaminhamento para efetivar esta operação.");
            dicionario.Add(CriticasChaves.Processo_Documento_Volume_Existe_Juntada_Incorporado, "Já existe um documento Juntado ou Incorporado a este volume.");
            dicionario.Add(CriticasChaves.Processo_SolicitacaoAutuacaoValidarAcoesSpec, "Operação não permitida.");
            return dicionario;
        }

        public static Dictionary<string, string> Processo
        {
            get
            {
                if (dicProcesso == null)
                    dicProcesso = ObterDicionarioProcesso();

                return dicProcesso;
            }
        }
    }
}