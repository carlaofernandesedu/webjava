﻿using System.Collections.Generic;

namespace br.procon.si.Core.Domain.Mensagens
{
    public static partial class Dicionario
    {
        private static Dictionary<string, string> dicLogin;
        private static Dictionary<string, string> ObterDicionarioLogin()
        {
            var dicionario = new Dictionary<string, string>(2);
            dicionario.Add(CriticasChaves.Login_UsuarioOuSenhaErrada, "E-mail ou senha inválido. Informe novamente, por favor.");
            dicionario.Add(CriticasChaves.Login_UsuarioBloqueado, "Você excedeu o número de tentativas. Usuário bloqueado por 24 horas.");
            dicionario.Add(CriticasChaves.Login_EmailDuplicado, "Este usuário já está cadastrado no Sistema! Efetue o login ou informe outro");
            dicionario.Add(CriticasChaves.Login_SenhaEmbraco, "Senha ou Confirma Senha em Branco , favor preenche-la!");
            dicionario.Add(CriticasChaves.Login_EmailIncorreto, "Email não informado ou incorreto. Favor verificar");
            dicionario.Add(CriticasChaves.Login_NomeIncorreto, "Nome não informado ou incorreto. Favor verificar");
            dicionario.Add(CriticasChaves.Login_SenhaIncorreta, "Senha inválida. Favor verificar");
            dicionario.Add(CriticasChaves.Login_ConfirmacaoSenhaIncorreta, "Confirmacao de Senha incorreta. Favor verificar");
            dicionario.Add(CriticasChaves.Login_UsuarioCriado, "Usuário criado com sucesso! Você será redirecionado para a sua área");
            return dicionario;
        }
        public static Dictionary<string, string> Login
        {
            get { return dicLogin ?? (dicLogin = ObterDicionarioLogin()); }
        }
    }
}
