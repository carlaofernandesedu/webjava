﻿namespace br.procon.si.Core.Domain.Mensagens
{
    public static partial class Dicionario
    {
        public static partial class ErrosChaves
        {
            public const string Protocolo_ExclusaoLogica = "Protocolo_ExclusaoLogica";
        }

        public static partial class CriticasChaves
        {
            public const string Protocolo_Nome = "Protocolo_Nome";
            public const string Protocolo_ExcluirPartes = "Protocolo_ExcluirPartes";
            public const string Protocolo_Documento_Valido = "Protocolo_Documento_Valido";
            public const string Protocolo_MovelArquivoDivisaoDuplicada = "Protocolo_MovelArquivoDivisaoDuplicada";
            public const string Protocolo_MovelArquivoNaoPodeExcluirDivisaoComCaixaAssociada = "Protocolo_MovelArquivoPossuiCaixaAssociada";
            public const string Protocolo_MovelArquivoCodigoDuplicado = "Protocolo_MovelArquivoCodigoDuplicado";
            public const string Protocolo_MovelArquivoUaAtribuicaoProtocolo = "Protocolo_MovelArquivoUaAtribuicaoProtocolo";
            public const string Protocolo_MovelArquivoUaUsuarioDivergeUaLocalArquivo = "Protocolo_MovelArquivoUaUsuarioDivergeUaLocalArquivo";
            public const string Protocolo_DivisaoArquivoNaoPodeExcluirPossuiCaixaAssociada = "Protocolo_DivisaoArquivoNaoPodeExcluirPossuiCaixaAssociada";
            public const string Protocolo_CaixaArquivoCodigoDuplicado = "Protocolo_CaixaArquivoCodigoDuplicado";
            public const string Protocolo_CaixaArquivoUaUsuarioDivergeUaCaixa = "Protocolo_CaixaArquivoUaUsuarioDivergeUaCaixa";
            public const string Protocolo_CaixaArquivoNaoPodeExcluirCaixaComDocumento = "Protocolo_CaixaArquivoNaoPodeExcluirCaixaComDocumento";
            public const string Protocolo_ArquivamentoCaixaDeveEstarAtiva = "Protocolo_ArquivamentoCaixaDeveEstarAtiva";
            public const string Protocolo_ArquivamentoVolumeDeveEstarEmAndamento = "Protocolo_ArquivamentoVolumeDeveEstarEmAndamento";
            public const string Protocolo_ArquivamentoVolumeDeveEstarDesarquivadoSemReabertura = "Protocolo_ArquivamentoVolumeDeveEstarDesarquivadoSemReabertura";
            public const string Protocolo_ArquivamentoVolumeDeveEstarArquivado = "Protocolo_ArquivamentoVolumeDeveEstarArquivado";
            public const string Protocolo_ArquivamentoDocumentoDevePertencerUaUsuario = "Protocolo_ArquivamentoDocumentoDevePertencerUaUsuario";
            public const string Protocolo_ArquivamentoDocumentoDevePossuirMesmaSerieDocumentalDaCaixa = "Protocolo_ArquivamentoDocumentoDevePossuirMesmaSerieDocumentalDaCaixa";
            public const string Protocolo_ArquivamentoCaixaDevePertencerUaUsuario = "Protocolo_ArquivamentoCaixaDevePertencerUaUsuario";
            public const string Protocolo_Status_Valido = "Protocolo_Status_Valido";
            public const string Protocolo_ArquivamentoDocumentoDevePossuirMesmaUAProdutoraDaCaixa = "Protocolo_ArquivamentoDocumentoDevePossuirMesmaUAProdutoraDaCaixa";
            public const string Protocolo_ArquivamentoDocumentoDeveEstarNoPeriodoDeDataDaCaixa = "Protocolo_ArquivamentoDocumentoDeveEstarNoPeriodoDeDataDaCaixa";
            public const string Protocolo_ModeloDocumentoSerieDocumentalClassificacaoDeveSerAvulso = "Protocolo_ModeloDocumentoSerieDocumentalClassificacaoDeveSerAvulso";
            public const string Protocolo_DocumentoSimplesUARestricao = "Protocolo_DocumentoSimplesUARestricao";
            public const string Protocolo_DocumentoSimplesUACriacao = "Protocolo_DocumentoSimplesUACriacao";
            public const string Protocolo_CaixaArquivoExistePropostaEliminacao = "Protocolo_CaixaArquivoExistePropostaEliminacao";
            public const string Protocolo_CaixaArquivoExisteArquivamento = "Protocolo_CaixaArquivoExisteArquivamento";
            public const string Protocolo_ArquivamentoDeveValidarDuplicidadeSpec = "Protocolo_ArquivamentoDeveValidarDuplicidadeSpec";
            public const string Protocolo_CaixaArquivoDeveValidarEdicao = "Protocolo_CaixaArquivoDeveValidarEdicao";
            public const string Protocolo_ArquivamentoDeveValidarDocumentoEmAndamento = "Protocolo_ArquivamentoDeveValidarDocumentoEmAndamento";
            public const string Protocolo_DocumentoDevePossuiDataAprovacaoConta = "Protocolo_DocumentoDevePossuiDataAprovacaoConta";
        }

        public static partial class InfoChaves
        {
        }
    }
}