﻿
namespace br.procon.si.Core.Domain.Mensagens
{
    public static partial class Dicionario
    {
        public static partial class ErrosChaves
        {
            //public const string Global_Chave1 = "Global_Chave1";
        }

        public static partial class TitulosChaves
        {
            public const string Global_Informacao = "Global_Informacao";
            public const string Global_Alerta = "Global_Alerta";
            public const string Global_Erro = "Global_Erro";
        }

        public static partial class InfoChaves
        {
            public const string Global_ExecutadoComSucesso = "Global_ExecutadoComSuceso";
            public const string Global_IncluidoComSucesso = "Global_IncluidoComSucesso";
            public const string Global_AlteradoComSucesso = "Global_AlteradoComSucesso";
        }

    }
}
