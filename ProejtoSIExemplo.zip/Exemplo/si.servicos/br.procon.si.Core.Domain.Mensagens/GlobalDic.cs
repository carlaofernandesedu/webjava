﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Core.Domain.Mensagens
{
    public static partial class Dicionario
    {
        private static Dictionary<string, string> dicGlobal;
        private static Dictionary<string, string> ObterDicionarioGlobal()
        {
            var dicionario = new Dictionary<string, string>(1);
            //dicionario.Add(ErrosChaves.Global_Chave1, "z");
            dicionario.Add(TitulosChaves.Global_Informacao, "Informação");
            dicionario.Add(TitulosChaves.Global_Alerta, "Alerta");
            dicionario.Add(TitulosChaves.Global_Erro, "Erro");
            dicionario.Add(InfoChaves.Global_AlteradoComSucesso, "Registro alterado com sucesso");
            dicionario.Add(InfoChaves.Global_IncluidoComSucesso, "Registro incluído com sucesso");
            dicionario.Add(InfoChaves.Global_ExecutadoComSucesso, "Operacão executada com sucesso");
            return dicionario;
        }  
        public static Dictionary<string, string> Global
        {
            get
            {
                if (dicGlobal == null)
                    dicGlobal = ObterDicionarioGlobal();

                return dicGlobal;
            }
        }
     }
}
