﻿using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Infra;
using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Dynamic;
using System.Linq;
using System.Reflection;
using System.Security;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;
using br.procon.si.Protocolo.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.ValueObjects;

namespace br.procon.si.Protocolo.Infra
{
    public class RelatorioProtocolo : IRelatorioProtocolo
    {
        ReportViewer _reportViewer = null;
        ReportParameterInfoCollection parametrosRDLC;


        public byte[] PDF<T>(T model, string localizacaoRDLC) where T : class
        {
            _reportViewer = new ReportViewer();
            _reportViewer.LocalReport.SetBasePermissionsForSandboxAppDomain(new PermissionSet(PermissionState.Unrestricted));
            _reportViewer.ProcessingMode = ProcessingMode.Local;
            _reportViewer.LocalReport.ReportPath = localizacaoRDLC;
            parametrosRDLC = _reportViewer.LocalReport.GetParameters();
            listaDeParametros(model);

            var _byte = ObterBytesPDF(_reportViewer);

            return _byte;
        }

        public byte[] ObterTermoEncerramentoBytePDF(RelatorioDocumentoVolume model, string localizacaoRDLC)
        {
            _reportViewer = new ReportViewer();
            _reportViewer.LocalReport.SetBasePermissionsForSandboxAppDomain(new PermissionSet(PermissionState.Unrestricted));
            _reportViewer.ProcessingMode = ProcessingMode.Local;
            _reportViewer.LocalReport.ReportPath = localizacaoRDLC;
            parametrosRDLC = _reportViewer.LocalReport.GetParameters();
            listaDeParametros(model);
            var _byte = ObterBytesPDF(_reportViewer);
            return _byte;
        }       

        public byte[] ObterFolhaLiderBytePDF(FolhaLiderDocumentoVolume model, string localizacaoRDLC)
        {
            _reportViewer = new ReportViewer();
            _reportViewer.LocalReport.SetBasePermissionsForSandboxAppDomain(new PermissionSet(PermissionState.Unrestricted));
            _reportViewer.ProcessingMode = ProcessingMode.Local;
            _reportViewer.LocalReport.ReportPath = localizacaoRDLC;
            parametrosRDLC = _reportViewer.LocalReport.GetParameters();
            listaDeParametros(model);
            var _byte = ObterBytesPDF(_reportViewer);
            return _byte;
        }

        public byte[] ObterTermoApensamentoBytePDF(RelatorioDocumentoApensar model, string localizacaoRDLC)
        {
            _reportViewer = new ReportViewer();
            _reportViewer.LocalReport.SetBasePermissionsForSandboxAppDomain(new PermissionSet(PermissionState.Unrestricted));
            _reportViewer.ProcessingMode = ProcessingMode.Local;
            _reportViewer.LocalReport.ReportPath = localizacaoRDLC;
            parametrosRDLC = _reportViewer.LocalReport.GetParameters();
            listaDeParametros(model);
            var _byte = ObterBytesPDF(_reportViewer);
            return _byte;
        }

        public byte[] ObterTermoDesapensamentoBytePDF(RelatorioDocumentoApensar model, string localizacaoRDLC)
        {
            _reportViewer = new ReportViewer();
            _reportViewer.LocalReport.SetBasePermissionsForSandboxAppDomain(new PermissionSet(PermissionState.Unrestricted));
            _reportViewer.ProcessingMode = ProcessingMode.Local;
            _reportViewer.LocalReport.ReportPath = localizacaoRDLC;
            parametrosRDLC = _reportViewer.LocalReport.GetParameters();
            listaDeParametros(model);
            var _byte = ObterBytesPDF(_reportViewer);
            return _byte;
        }

        public byte[] ObterTermoSolicitacaoAutuacaoBytePDF(RelatorioSolicitacaoAutuacao model, string localizacaoRDLC)
        {
            _reportViewer = new ReportViewer();
            _reportViewer.LocalReport.SetBasePermissionsForSandboxAppDomain(new PermissionSet(PermissionState.Unrestricted));
            _reportViewer.ProcessingMode = ProcessingMode.Local;
            _reportViewer.LocalReport.ReportPath = localizacaoRDLC;
            parametrosRDLC = _reportViewer.LocalReport.GetParameters();
            listaDeParametros(model);
            var _byte = ObterBytesPDF(_reportViewer);
            return _byte;
        }

        public byte[] ObterFolhaDespachoBytePDF(RelatorioDocumentoDadosProcesso model, string localizacaoRDLC)
        {
            _reportViewer = new ReportViewer();
            _reportViewer.LocalReport.SetBasePermissionsForSandboxAppDomain(new PermissionSet(PermissionState.Unrestricted));
            _reportViewer.ProcessingMode = ProcessingMode.Local;
            _reportViewer.LocalReport.ReportPath = localizacaoRDLC;
            parametrosRDLC = _reportViewer.LocalReport.GetParameters();
            listaDeParametros(model);
            var _byte = ObterBytesPDF(_reportViewer);
            return _byte;
        }

        public byte[] ObterBytesPDF(ReportViewer report)
        {
            string reportType = "PDF";
            string mimeType;
            string encoding;
            string fileNameExtension;
            string deviceInfo =
            "<DeviceInfo>" +
            "  <OutputFormat>PDF</OutputFormat>" +
            "  <PageWidth>8.3in</PageWidth>" +
            "  <PageHeight>11in</PageHeight>" +
            "  <MarginTop>0.1in</MarginTop>" +
            "  <MarginLeft>0.5in</MarginLeft>" +
            "  <MarginRight>0.1in</MarginRight>" +
            "  <MarginBottom>0.1in</MarginBottom>" +
            "</DeviceInfo>";

            Warning[] warnings;
            string[] streams;
            byte[] renderedBytes;

            renderedBytes = report.LocalReport.Render(
                reportType,
                deviceInfo,
                out mimeType,
                out encoding,
                out fileNameExtension,
                out streams,
                out warnings);

            return renderedBytes;
        }

        public void listaDeParametros<T>(T model)
        {
            PropertyInfo[] propriedades = model.GetType().GetProperties();
            foreach (PropertyInfo prop in propriedades)
            {
                if (prop.Name != "IsValid")
                {
                    var nome = prop.Name;
                    var valor = prop.GetValue(model) ?? "";

                    if (filtrarParametersRdlc(nome))
                        _reportViewer.LocalReport.SetParameters(new ReportParameter(nome, valor.ToString()));

                }
            }
        }

        public bool filtrarParametersRdlc(string _name)
        {
            foreach (var item in parametrosRDLC)
            {
                if (item.Name == _name)
                    return true;
            }
            return false;
        }

        public byte[] ObterDocumentoSimplesBytePDF(RelatorioDocumentoSimples model, string localizacaoRDLC)
        {
            _reportViewer = new ReportViewer();
            _reportViewer.LocalReport.SetBasePermissionsForSandboxAppDomain(new PermissionSet(PermissionState.Unrestricted));
            _reportViewer.ProcessingMode = ProcessingMode.Local;
            _reportViewer.LocalReport.ReportPath = localizacaoRDLC;
            parametrosRDLC = _reportViewer.LocalReport.GetParameters();
            listaDeParametros(model);
            var _byte = ObterBytesPDF(_reportViewer);
            return _byte;
        }
    }
}
