﻿using br.procon.si.Core.Domain.Interfaces;
using br.procon.si.Core.Domain.Mensagens;
using br.procon.si.Protocolo.Domain.Interfaces;
using System.Linq;

namespace br.procon.si.Protocolo.Domain.Specifications.CaixaArquivo
{
    public class CaixaArquivoDeveValidarDuplicidadeCodigoSpec : ISpecification<Entities.CaixaArquivo>
    {
        private readonly ICaixaArquivoRepository _caixaRepository;

        public CaixaArquivoDeveValidarDuplicidadeCodigoSpec(ICaixaArquivoRepository repository)
        {
            _caixaRepository = repository;
        }

        public bool IsSatisfiedBy(Entities.CaixaArquivo entity)
        {
            if (entity.Id == 0 && entity.Codigo != null)
            {
                var list = _caixaRepository.ObterPorCodigoDescricao(entity.Codigo, null, null);
                return list == null || list.Count() == 0;
            }
            return true;
        }

        public string MensagemDeRetorno
        {
            get
            {
                return Dicionario.CriticasChaves.Protocolo_CaixaArquivoCodigoDuplicado;
            }
        }
    }
}