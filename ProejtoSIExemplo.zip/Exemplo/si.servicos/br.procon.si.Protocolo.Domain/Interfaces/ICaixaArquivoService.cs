﻿using br.procon.si.Protocolo.Domain.Entities;
using System.Collections.Generic;

namespace br.procon.si.Protocolo.Domain.Interfaces
{
    public interface ICaixaArquivoService
    {
        IEnumerable<CaixaArquivo> ObterCaixasArquivosPorCodigoDescricao(string codigo, string descricao, bool? ativo);

        CaixaArquivo SalvarCaixaArquivo(CaixaArquivo caixaArquivo);

        CaixaArquivo ExcluirCaixaArquivo(CaixaArquivo caixaArquivo);
    }
}