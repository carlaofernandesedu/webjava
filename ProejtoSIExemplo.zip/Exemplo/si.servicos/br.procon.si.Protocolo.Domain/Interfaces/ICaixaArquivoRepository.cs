﻿using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.ValueObjects;
using System.Collections.Generic;

namespace br.procon.si.Protocolo.Domain.Interfaces
{
    public interface ICaixaArquivoRepository
    {
        int Inserir(CaixaArquivo entity);

        int Atualizar(CaixaArquivo entity);

        void Excluir(CaixaArquivo entity);

        CaixaArquivo Obter(int id);

        IEnumerable<CaixaArquivo> ObterPorCodigoDescricao(string codigo, string descricao, bool? ativo);

        IEnumerable<DocumentoCaixaArquivo> ObterDocumentosDaCaixa(int id_caixa_arquivo);
    }
}