﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class RelatorioDocumentoApensar
    {        
        public int Codigo { get;  set; }

        public string NomeDoTermo { get; set; }

        public string TipoDoTermo { get; set; }
       
        public string NomeSolicitante { get;  set; }

        public string UASolicitante { get; set; }
     
        public string Cargo { get;  set; }             
               
        public string DataAbertura { get; set; }

        public string NrProcesso { get; set; }

        public string NrProcessoApensado { get; set; }

        public string Nome { get; set; }

        public string UA { get; set; }

        public DateTime DataGeracaoPdf { get; set; }

        public string Interessado { get; set; }

        public string Assunto { get; set; }

        public string Volumes { get; set; }

        public string DataExtenso { get; set; }

    }
}
