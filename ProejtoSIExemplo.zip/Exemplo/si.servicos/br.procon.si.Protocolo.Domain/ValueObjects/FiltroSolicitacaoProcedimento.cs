﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class FiltroSolicitacaoProcedimento
    {
        [Display(Name = "Nº do Protocolo")]
        [StringLength(11, MinimumLength = 11, ErrorMessage = "Número de Protocolo inválido!")]
        public string NrProtocoloFormatado { get; set; }

        public int? NrProtocoloNumero { get; set; }

        public int? NrProtocoloAno { get; set; }

        [Display(Name = "Nº do Processo")]
        [StringLength(13, MinimumLength = 13, ErrorMessage = "Número de Processo inválido!")]
        public string NrProcessoFormatado { get; set; }

        public int? NrProcessoNumero { get; set; }

        public int? NrProcessoAno { get; set; }

        [Display(Name = "Competência")]
        public int? IdCompetencia { get; set; }

        [Display(Name = "UA Protocolo")]
        public short? UAProtocolo { get; set; }

        [Display(Name = "UA Solicitante")]
        public short? UASolicitante { get; set; }

        [Display(Name = "Sigilo")]
        public bool? Sigilo { get; set; }

        [Display(Name = "Período")]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd}", ApplyFormatInEditMode = true)]
        public DateTime? DataInicial { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd}", ApplyFormatInEditMode = true)]
        public DateTime? DataFinal { get; set; }

        [Display(Name = "Situação")]
        public byte? IdSituacao { get; set; }
    }
}