﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class UnidadeAdministrativa
    {
        [Column("id_ua")]
        public int IdUA { get; set; }

        [Column("nr_ua")]
        public int NrUA { get; set; }

        [Column("ds_sigla_ua")]
        public string Sigla { get; set; }

        [Column("no_unidade")]
        public string Nome { get; set; }

        [Column("bl_protocolo")]
        public bool Protocolo { get; set; }

        [Column("bl_tramitacao")]
        public bool Tramitacao { get; set; }

        [Column("bl_ativo")]
        public bool Ativo { get; set; }

        [Column("no_unidade_organizacional")]
        public string NomeUAOrganizacional { get; set; }

        public UnidadeAdministrativa()
        {
        }

        public static List<int> RecuperaUaAtendimentoDistancia()
        {
            return new List<int>() { 31, 34, 60 }; // DAOC, DAOC / ATDIST, DAOC / TELEFONE
        }
    }
}