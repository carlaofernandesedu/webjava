﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class RelatorioDocumentoVolume
    {        
        public int Codigo { get;  set; }      
      
        public decimal NrVolumeDocumento { get;  set; }

        public decimal NrUltimaFolha { get; set; }

        public decimal NrUltimaFolhaVolumeAnterior { get; set; }
       
        public string NomeSolicitante { get;  set; }

        public string UASolicitante { get; set; }

        public string Interessado { get; set; }

        public string Assunto { get; set; }

        public string Cargo { get;  set; }             
               
        public DateTime DataAberturaVolume { get; set; }

        public DateTime DataEncerramentoVolume { get; set; }

        public string NrProcesso { get; set; }

        public string Nome { get; set; }

        public string UA { get; set; }

        public DateTime DataGeracaoPdf { get; set; }

        public string CargoFuncionario { get; set; }

        public string DataExtensoAbertura { get; set; }

        public string DataExtensoEncerramento { get; set; }
    }
}
