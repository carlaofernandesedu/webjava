﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using br.procon.si.Protocolo.Domain.ValueObjects.Enums;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class FiltroProcessoPrazo
    {
        public int IdProcesso { get; set; }

        public int IdProcessoPrazo { get; set; }

        public int IdDocumentoMovimentacao { get; set; }

        public int NrProcesso { get; set; }

        public int AnoProcesso { get; set; }

        public int CompetenciaProcesso { get; set; }

        [Display(Name = "Nº do Processo")]
        public string NrProcessoFormatado { get; set; }

        [Display(Name = "Prazo de Cumprimento")]
        public int PrazoCumprimento { get; set; }

        public int TipoVencimento { get; set; }

        public int QtdDias { get; set; }

        public DateTime DataVencimento { get; set; }

        public void DefinirDataVendimento(int tipoVencimento,int qtdDias)
        {
            if (qtdDias != 0)
            {
                this.DataVencimento = DateTime.Now;
                DataVencimento = tipoVencimento == 1 ? DataVencimento.AddDays(-qtdDias) : DataVencimento.AddDays(qtdDias);
            }
        }
    }
}
