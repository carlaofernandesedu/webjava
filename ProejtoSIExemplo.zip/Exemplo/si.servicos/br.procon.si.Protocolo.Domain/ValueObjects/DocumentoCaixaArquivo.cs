﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class DocumentoCaixaArquivo
    {
        [Column("id_caixa_arquivo")]
        public int IdCaixaArquivo { get; set; }

        [Column("id_documento_volume")]
        public int IdDocumentoVolume { get; set; }

        [Column("nr_documento")]
        public int NrDocumento { get; set; }

        [Column("nr_ano_documento")]
        public int AnoDocumento { get; set; }

        [Column("nr_seq_processo")]
        public int NrSequenciaProcesso { get; set; }

        [Column("nr_ano_processo")]
        public int AnoProcesso { get; set; }

        [Column("id_competencia_processo")]
        public int IdCompetenciaProcesso { get; set; }

        [Column("nr_funcao")]
        public int NrFuncao { get; set; }

        [Column("nr_subfuncao")]
        public int NrSubFuncao { get; set; }

        [Column("nr_atividade")]
        public int NrAtividade { get; set; }

        [Column("nr_serie_documental")]
        public int NrSerieDocumental { get; set; }

        [Column("ds_serie_documental")]
        public string DescricaoSerieDocumental { get; set; }

        [Column("nr_volume_documento")]
        public decimal Volume { get; set; }

        [Column("cx_id_ua_produtora")]
        public int CaixaUAProdutora { get; set; }

        [Column("dt_inicio_caixa")]
        public DateTime DtInicioCaixa { get; set; }

        [Column("dt_fim_caixa")]
        public DateTime DtFimCaixa { get; set; }

        [Column("id_ua_produtora")]
        public int DocumentoUAProdutora { get; set; }

        [Column("dt_encerramento")]
        public DateTime DocEncerramento { get; set; }

        public DocumentoCaixaArquivo()
        {
        }

        public string NumeroProtocoloFormatado
        {
            get { return Protocolo.FormatarNumeroProtocolo(NrDocumento, AnoDocumento); }
        }

        public string SerieDocumentalFormatada
        {
            get { return SerieDocumentalHierarquia.Formatar(NrFuncao, NrSubFuncao, NrAtividade, NrSerieDocumental, DescricaoSerieDocumental); }
        }
    }
}