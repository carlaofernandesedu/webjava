﻿namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class Protocolo
    {
        public int NrDocumento { get; set; }
        public int Ano { get; set; }

        public string ProtocoloFormatado
        {
            get { return FormatarNumeroProtocolo(NrDocumento, Ano); }
        }

        public static string FormatarNumeroProtocolo(int nrDocumento, int ano)
        {
            return nrDocumento.ToString("D6") + "/" + ano.ToString("D4");
        }
    }
}