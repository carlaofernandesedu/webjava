﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class RelatorioDocumentoDadosProcesso
    {
        public int IdDocumento { get; set; }

        public string NumeroProcesso { get; set; }

        public string Interessado { get; set; }

        public string Assunto { get; set; }

        public string UA { get; set; } 

        public int CodigoUaUsuarioLogado { get; set; } 

        public string UnidadeDestino { get; set; }

        public string UnidadeAutoridade{ get; set; }

        [Required(ErrorMessage = "Campo obrigatório.")]
        [Display(Name = "Unidade de Encaminhamento")]
        public int IdUaDestino { get; set; }      

        [Required(ErrorMessage = "Campo obrigatório.")]
        [Display(Name = "Nome do Solicitante")]
        public string NomeSolicitante { get; set; }

        [Required(ErrorMessage = "Campo obrigatório.")]
        [Display(Name = "Cargo do Solicitante")]
        public string CargoSolicitante { get; set; }

        [Required(ErrorMessage = "Campo obrigatório.")]
        [Display(Name = "Nome da Autoridade")]
        public string NomeAutoridade { get; set; }

        [Required(ErrorMessage = "Campo obrigatório.")]
        [Display(Name = "Cargo da Autoridade")]
        public string CargoAutoridade { get; set; }

        [Required(ErrorMessage = "Campo obrigatório.")]
        [Display(Name = "Unidade da Autoridade")]
        public int IdUaAutoridade { get; set; }

        [Required(ErrorMessage = "Campo obrigatório.")]
        [Display(Name = "Nome do Funcionário")]
        public string NomeFuncionario { get; set; }

        [Display(Name = "Identificação do Funcionário")]
        [Required(ErrorMessage = "Campo obrigatório.")]
        public string CargoFuncionario { get; set; }

        [Display(Name = "Data do Despacho")]
        [Required(ErrorMessage = "Campo obrigatório.")]
        public string DataDespacho { get; set; }

        public string DataExtenso { get; set; }
    }
}
