﻿using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class TipoMovelArquivo
    {

        [Column("id_tipo_movel_arquivo")]
        public int Id { get; set; }

        [Column("ds_tipo_movel_arquivo")]
        public string Descricao { get; set; }

        public TipoMovelArquivo()
        {

        }
    }
}
