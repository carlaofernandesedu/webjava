﻿
namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public static class ObterNumeroProtocolo
    {
        public static int? ConvertNumberProtocol(this string valor)
        {
            int?[] n1 = new int?[2] { 0, 0 };

            if (valor == null)
                return null;

            var number = valor.Split('/');
            int resultado = 0;

            for (int i = 0; i < number.Length; i++)
            {
                int.TryParse(number[i], out resultado);
                n1[i] = resultado;
            }
            return n1[0];
        }

        public static int? ConvertYearProtocol(this string valor)
        {
            int?[] n1 = new int?[2] { 0, 0 };

            if (valor == null)
                return null;

            var number = valor.Split('/');
            int resultado = 0;

            for (int i = 0; i < number.Length; i++)
            {
                int.TryParse(number[i], out resultado);
                n1[i] = resultado;
            }
            return n1[1];
        }

        public static string EmptyIfZero(this int value)
        {
            if (value == 0)
                return string.Empty;

            return value.ToString();
        }

    }
}
