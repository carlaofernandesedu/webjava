﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class SituacaoVolume
    {

        [Column("id_situacao_volume")]
        public int IdSituacaoVolume { get; set; }

        [Column("ds_situacao_volume")]
        public string Descricao { get; set; }

        public SituacaoVolume()
        {

        }
    }
}