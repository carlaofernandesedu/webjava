﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class TipoDocumentoPessoal
    {
        [Column("id_tipo_documento_pessoal")]
        public int IdTipoDocumentoPessoal { get; set; }

        [Column("ds_tipo_documento_pessoal")]
        public string Descricao { get; set; }

        public TipoDocumentoPessoal()
        {

        }
    }
}