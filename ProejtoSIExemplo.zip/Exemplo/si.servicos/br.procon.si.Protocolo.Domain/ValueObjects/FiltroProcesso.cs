﻿using br.procon.si.Core.Domain.ValueObjects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class FiltroProcesso : FiltroBase
    {
        public FiltroProcesso()
        {

        }

        private string nrProtocoloFormatado;
        [Display(Name = "Nº do Protocolo")]
        [StringLength(11,MinimumLength = 11, ErrorMessage = "Número de Protocolo inválido!")]
        public string NrProtocoloFormatado
        {
            get
            {
                return nrProtocoloFormatado;
            }
            set
            {
                if (value != null)
                {
                    var protocoloDividido = value.Split('/');
                    NrProtocoloNumero = Convert.ToInt32(protocoloDividido[0]);
                    NrProtocoloAno = Convert.ToInt32(protocoloDividido[1]);
                    nrProtocoloFormatado = value;
                }
            }
        }

        private string nrProcessoFormatado;
        [Display(Name = "Nº do Processo")]
        [StringLength(13, MinimumLength = 13, ErrorMessage = "Número de Processo inválido!")]
        public string NrProcessoFormatado
        {
            get
            {
                return nrProcessoFormatado;
            }
            set
            {
                if (value != null)
                {
                    if (value.Contains('/'))
                    {
                        var processoDividido = value.Split('/');
                        NrProcessoNumero = Convert.ToInt32(processoDividido[0]);
                        NrProcessoAno = Convert.ToInt32(processoDividido[1].Split('/')[0]);
                    }
                    else if (value.Contains('.'))
                    {
                        var processoDividido = value.Split('.');
                        NrProcessoNumero = Convert.ToInt32(processoDividido[0]);
                        NrProcessoAno = Convert.ToInt32(processoDividido[1].Split('.')[0]);
                    }
                    nrProcessoFormatado = value;
                }
            }
        }

        public int? Codigo { get; set; }

        public int? IdDocumento { get; set; }

        public int IdApensamento { get; set; }

        public int? NrProtocoloNumero { get; set; }

        public int? NrProtocoloAno { get; set; }

        public int? NrProcessoNumero { get; set; }

        public int? NrProcessoAno { get; set; }

        [Display(Name = "Competência")]
        public int? IdCompetencia { get; set; }

        public string Interessado { get; set; }

        public string PeriodoAutuacaoInicial { get; set; }

        public string PeriodoAutuacaoFinal { get; set; }

        public DateTime? DataInicial { get; set; }

        public DateTime? DataFinal { get; set; }

        public int? Situacao { get; set; }

        public int? IdUaPosse { get; set; }
    }
}
