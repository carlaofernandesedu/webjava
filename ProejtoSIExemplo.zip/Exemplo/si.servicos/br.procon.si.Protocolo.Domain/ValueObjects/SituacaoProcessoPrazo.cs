﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class SituacaoProcessoPrazo
    {
        [Column("id_situacao_processo_prazo")]
        public int Codigo { get; set; }

        [Column("ds_situacao_processo_prazo")]
        public string Descricao { get; set; }

        [Column("bl_ativo_situacao_processo_prazo")]
        public bool Ativo { get; set; }
    }
}
