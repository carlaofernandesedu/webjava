﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class ProcessoListaVO
    {
        [Column("id_processo")]
        public int IdProcesso { get; set; }

        [Column("id_documento")]
        public int IdDocumento { get; set; }

        [Column("nr_seq_processo")]
        public int NrSequencial { get; private set; }

        [Column("nr_ano_processo")]
        public int Ano { get; private set; }

        [Column("id_competencia_processo")]
        public int CodigoCompetencia { get; private set; }

        [Column("nr_documento")]
        public int ProtocoloNumero { get; set; }

        [Column("nr_ano")]
        public int ProtocoloAno { get; set; }

        [Column("ds_serie_documental")]
        public string SerieDocumentalDescricao { get; set; }

        [Column("no_parte")]
        public string InteressadoNome { get; private set; }

        [Column("dt_autuacao_processo")]
        public DateTime DataAutuacao { get; private set; }

        [Column("id_situacao_processo")]
        public int Situacao { get; private set; }

        [Column("ds_situacao_processo")]
        public string DescricaoSituacao { get; private set; }

        public string ProcessoNumeroFormatado
        {
            get { return String.Format("{0:d6}.{1}.{2}", NrSequencial, Ano, CodigoCompetencia); }
        }

        public string DataAutuacaoFormatada
        {
            get { return DataAutuacao.ToString("dd/MM/yyyy"); }
        }

        public string ProtocoloNumeroFormatado
        {
            get { return string.Format("{0:d6}/{1}", ProtocoloNumero, ProtocoloAno); }
        }
    }
}
