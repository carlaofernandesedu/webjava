﻿using System;
using System.Collections.Generic;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class RelatorioSolicitacaoAutuacao
    {
        public int IdSolicitacaoAutuacao { get; set; }
        public string NomeDoTermo { get; set; }
        public string SerieDocumental { get; set; }
        public string Interessado { get; set; }
        public string Assunto { get; set; }
        public string UADestino { get; set; }
        public string NomeAutoridade { get; set; }
        public string CargoAutoridade { get; set; }
        public string UAAutoridade { get; set; }

        public string Usuario { get; set; }
        public string UAUsuario { get; set; }
        public DateTime DataGeracaoPDF { get; set; }
        public DateTime DataSolicitacao { get; set; }

        public string DataExtenso { get; set; }
    }
}
