﻿using br.procon.si.Core.Domain.ValueObjects;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class DocumentoRegrasGerais : Aggregate
    {
        public DocumentoRegrasGerais()
        {
        }

        public int IdDocumentoPai { get; set; }

        public int IdDocumentoFilho { get; set; }

        public override bool IsValid
        {
            get { throw new NotImplementedException(); }
        }

    }
}