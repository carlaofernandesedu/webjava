﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class OrigemDocumento
    {
        [Column("id_origem_documento")]
        public int IdOrigemDocumento { get; set; }

        [Column("ds_origem_documento")]
        public string Descricao { get; set; }

        public OrigemDocumento()
        {

        }

        public OrigemDocumento(byte idOrigemDocumento, string descricao)
        {
            this.IdOrigemDocumento = idOrigemDocumento;

            this.Descricao = descricao;
        }
    }
}
