﻿using br.procon.si.Protocolo.Domain.ValueObjects.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class Movimento
    {

        [Column("id_movimento")]
        public int Codigo { get; set; }

        [Column("no_movimento")]
        public string NomeMovimento { get; set; }

        [Column("ds_movimento")]
        public string DescricaoMovimento { get; set; }

        [Column("bl_manual_movimento")]
        public bool ManualMovimento { get; set; }

        [Column("bl_ativo_movimento")]
        public bool AtivoMovimento { get; set; }

        [Column("id_tipo_movimento")]
        public int IdTipoMovimento { get; set; }

        [Column("id_usuario_criacao")]
        public int IdUsuarioCriacao { get; set; }

        [Column("dt_criacao")]
        public DateTime DataCriacao { get; set; }

        [Column("id_usuario_alteracao")]
        public int IdUsuarioAlteracao { get; set; }

        [Column("dt_alteracao")]
        public DateTime DataAlteracao { get; set; }

        [Column("id_tipo_movimento")]
        public EnumTipoMovimento TipoMovimento { get; set; }

    }
}
