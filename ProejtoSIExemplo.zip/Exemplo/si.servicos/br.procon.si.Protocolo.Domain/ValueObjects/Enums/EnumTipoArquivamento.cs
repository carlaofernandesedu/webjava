﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Protocolo.Domain.ValueObjects.Enums
{
    public enum EnumTipoArquivamento
    {
        ARQUIVAMENTO = 1,
        DESARQUIVAMENTO_PARA_ANDAMENTO = 2,
        DESARQUIVAMENTO_SEM_REABERTURA = 3,
        REARQUIVAMENTO = 4

    }
}
