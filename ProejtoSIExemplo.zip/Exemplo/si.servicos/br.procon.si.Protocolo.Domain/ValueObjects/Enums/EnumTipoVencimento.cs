﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Protocolo.Domain.ValueObjects.Enums
{
    public enum EnumTipoVencimento
    {
        Vencido = 1,
        AVencer = 2

    }
}
