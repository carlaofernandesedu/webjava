﻿using System;
using System.ComponentModel.DataAnnotations;

namespace br.procon.si.Protocolo.Domain.ValueObjects.Enums
{
    public enum EnumSituacaoPropostaEliminacaoItem
    {
        [Display(Name = "Proposto")]
        Proposto = 1,

        [Display(Name = "Aprovado")]
        Aprovado = 2,

        [Display(Name = "Recusado")]
        Recusado = 3
    }
}
