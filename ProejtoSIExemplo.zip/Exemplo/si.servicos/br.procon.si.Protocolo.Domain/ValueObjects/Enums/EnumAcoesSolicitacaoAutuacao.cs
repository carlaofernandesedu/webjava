﻿namespace br.procon.si.Protocolo.Domain.ValueObjects.Enums
{
    public enum EnumAcoesSolicitacaoAutuacao
    {
        Visualizacao = 1,
        Edicao = 2,
        Aceite = 3,
        Cancelamento = 4,
        Impressao = 5
    }
}