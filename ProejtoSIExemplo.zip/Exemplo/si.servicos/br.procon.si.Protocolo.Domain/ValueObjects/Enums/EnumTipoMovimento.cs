﻿namespace br.procon.si.Protocolo.Domain.ValueObjects.Enums
{
    public enum EnumTipoMovimento
    {
        Protocolo = 1,
        Remessa = 11,
        Recebimento = 12,
        RecebimentoRessalva = 13,
        RecebimentoRecusado = 14,
        RecebimentoDevolvido = 15,
        Autuacao = 20,
        Juntada = 21,
        Incorporacao = 22,
        Apensamento = 23,
        Desapensamento = 24,
        JuntadaCancelamento = 25,
        IncorporacaoCancelamento = 26,
        ApensamentoCancelamento = 27,
        Encerramento = 32,
        Reativacao = 33,
        Volume = 35,
        DesarquivarAndamento = 36,
        DesarquivarReabertura = 37,
        Arquivamento = 38,
        Rearquivar = 39
    }
}