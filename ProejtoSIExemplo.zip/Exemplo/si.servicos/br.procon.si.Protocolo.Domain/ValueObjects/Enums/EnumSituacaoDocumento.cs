﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Protocolo.Domain.ValueObjects.Enums
{
    public enum EnumSituacaoDocumento
    {
        Protocolado = 1,
        Cadastrado = 2,
        Cancelado = 3
    }
}
