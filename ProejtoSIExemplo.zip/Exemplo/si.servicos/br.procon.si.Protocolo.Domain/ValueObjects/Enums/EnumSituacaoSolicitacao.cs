﻿using System;
using System.Collections.Generic;

namespace br.procon.si.Protocolo.Domain.ValueObjects.Enums
{
    public enum EnumSituacaoSolicitacao
    {
        Aberta = 1,
        Atendida = 2,
        Cancelada = 3
    }
}
