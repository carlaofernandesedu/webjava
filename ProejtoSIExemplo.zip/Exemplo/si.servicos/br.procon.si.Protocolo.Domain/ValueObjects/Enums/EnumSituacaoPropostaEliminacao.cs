﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Protocolo.Domain.ValueObjects.Enums
{
    public enum SituacaoPropostaEliminacao : byte
    {       
        [Display(Name = "Proposta para eliminar")]
        Proposta = 1,

        [Display(Name = "Aprovada para eliminação")]
        Aprovada = 2,

        [Display(Name = "Fragmentado")]
        Fragmentada = 3
    }
}
