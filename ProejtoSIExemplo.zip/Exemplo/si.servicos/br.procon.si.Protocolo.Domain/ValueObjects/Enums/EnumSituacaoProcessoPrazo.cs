﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace br.procon.si.Protocolo.Domain.ValueObjects.Enums
{
    public enum EnumSituacaoProcessoPrazo : int
    {
        [Display(Name = "Em andamento")]
        EmAndamento = 1,

        [Display(Name = "Cancelado por outro evento")]
        CanceladoPorOutroEvento = 2
    }
}
