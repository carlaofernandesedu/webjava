﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace br.procon.si.Protocolo.Domain.ValueObjects.Enums
{
    public enum EnumCompetenciaProcesso
    {
        [Display(Name = "Sancionatório")]
        Sancionatorio = 1,

        [Display(Name = "Administrativo interno")]
        AdministrativoInterno = 2
    }
}
