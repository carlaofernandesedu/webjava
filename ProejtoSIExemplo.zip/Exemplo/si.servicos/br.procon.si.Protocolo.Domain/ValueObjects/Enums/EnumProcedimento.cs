﻿using System;
using System.ComponentModel.DataAnnotations;

namespace br.procon.si.Protocolo.Domain.ValueObjects.Enums
{
    public enum EnumProcedimento
    {
        [Display(Name = "Abertura de volume")]
        AberturaDeVolume = 1,

        [Display(Name = "Apensamento de documento")]
        ApensamentoDeDocumento = 2,

        [Display(Name = "Desapensamento de documento")]
        DesapensamentoDeDocumento = 3,

        [Display(Name = "Incorporação de documento")]
        IncorporacaoDeDocumento = 4
    }
}
