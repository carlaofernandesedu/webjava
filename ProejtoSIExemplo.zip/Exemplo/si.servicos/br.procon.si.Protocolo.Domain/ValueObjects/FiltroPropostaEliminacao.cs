﻿using br.procon.si.Protocolo.Domain.ValueObjects.Enums;
using System;
using System.ComponentModel.DataAnnotations;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class FiltroPropostaEliminacao
    {
        public int Id { get; set; }

        public DateTime? DtInicio { get; set; }
       
        public DateTime? DtFim { get; set; }
        
        public bool? IncluidoNaProposta { get; set; }
      
        public Int16? IdUA { get; set; }

        public SituacaoPropostaEliminacao? Situacao { get; set; }

        public int? IdItem { get; set; }

        #region Metodos
        public void DefinirSituacao(SituacaoPropostaEliminacao situacao)
        {
            this.Situacao = situacao;
        }

        #endregion
    }
}
