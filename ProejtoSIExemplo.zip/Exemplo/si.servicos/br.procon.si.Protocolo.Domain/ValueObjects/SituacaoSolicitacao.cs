﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class SituacaoSolicitacao
    {
        [Column("id_situacao_solicitacao")]
        public int Codigo { get; set; }

        [Column("ds_situacao_solicitacao")]
        public string Descricao { get; set; }

        [Column("bl_ativo_situacao_solicitacao")]
        public bool Ativo { get; set; }
    }
}
