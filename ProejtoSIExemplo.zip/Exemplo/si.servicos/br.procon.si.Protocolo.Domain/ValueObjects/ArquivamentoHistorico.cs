﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class ArquivamentoHistorico
    {

        [Column("id_arquivamento")]
        public int IdArquivamento { get; set; }

        [Column("id_caixa_arquivo")]
        public int IdCaixaArquivo { get; set; }
        
        [Column("id_documento_volume")]
        public int IdDocumentoVolume { get; set; }

        [Column("id_tipo_arquivamento")]
        public int IdTipoArquivamento { get; set; }

        [Column("dt_arquivamento")]
        public DateTime DtArquivamento { get; set; }

        [Column("cd_caixa_arquivo")]
        public string CodigoCaixaArquivo { get; set; }

        [Column("nr_volume_documento")]
        public decimal NumeroVolume { get; set; }

        [Column("ds_tipo_arquivamento")]
        public string DescricaoTipoArquivamento { get; set; }       


        public ArquivamentoHistorico()
        {

        }


        public ArquivamentoHistorico(
            int idArquivamento,
            int idCaixaArquivo,
            int idDocumentoVolume,
            int idTipoArquivamento,
            DateTime dataArquivamento,
            string codigoCaixaArquivo,
            decimal numeroVolume,
            string descricaoTipoArquivamento
            )
        {
            IdArquivamento = idArquivamento;
            IdCaixaArquivo = idCaixaArquivo;
            IdDocumentoVolume = idDocumentoVolume;
            IdTipoArquivamento = idTipoArquivamento;
            DtArquivamento = dataArquivamento;
            CodigoCaixaArquivo = codigoCaixaArquivo;
            NumeroVolume = numeroVolume;
            DescricaoTipoArquivamento = descricaoTipoArquivamento;

        }

    }
}