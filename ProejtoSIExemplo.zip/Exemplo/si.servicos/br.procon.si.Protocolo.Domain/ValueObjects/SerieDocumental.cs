﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class SerieDocumental
    {
        [Column("id_serie_documental")]
        public int IdSerieDocumental { get; set; }
        
        [Column("nr_serie_documental")]
        public int NrSerie { get; set; }
        
        [Column("ds_serie_documental")]
        public string Descricao { get; set; }
        
        [Column("nr_dias_prazo_guarda_unidade_produtora")]
        public int? PrazoGuarda { get; set; }

        [Column("id_tipo_prazo_guarda_produtora")]
        public int IdTipoPrazoGuardaProdutora { get; set; }
        
        [Column("dt_inicio_vigencia")]
        public DateTime InicioVigencia { get; set; }
        
        [Column("dt_fim_vigencia")]
        public DateTime? FimVigencia { get; set; }
        
        [Column("bl_ativo")]
        public bool Ativo { get; set; }

        [Column("ds_atividade")]
        public string Atividade { get; set; }

        [Column("ds_subfuncao")]
        public string SubFuncao { get; set; }

        [Column("ds_funcao")]
        public string Funcao { get; set; }
        
        [Column("id_serie_documental_classificacao")]
        public int IdSerieDocumentalClassificacao { get; set; }

        [Column("descricao")]
        public string TituloSerie { get; set; }

        [Column("id_grupo_documento")]
        public byte? IdGrupoDocumento { get; set; }

        public SerieDocumental()
        {

        }
    }
}
