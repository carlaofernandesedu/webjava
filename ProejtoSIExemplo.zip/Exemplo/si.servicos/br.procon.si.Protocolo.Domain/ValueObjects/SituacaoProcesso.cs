﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class SituacaoProcesso
    {
        [Column("id_situacao_processo")]
        public int IdSituacaoProcesso { get; set; }

        [Column("ds_situacao_processo")]
        public string Descricao { get; set; }

        [Column("bl_ativo_situacao_processo")]
        public bool Ativo { get; set; }

        public SituacaoProcesso()
        {
        }
    }
}