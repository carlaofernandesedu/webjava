﻿using br.procon.si.Protocolo.Domain.ValueObjects.Enums;
using System;
using System.ComponentModel.DataAnnotations;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class FiltroPropostaEliminacaoItem
    {
        public int IdUa { get; set; }

        public int IdPropostaItem { get; set; }

        [Display(Name = "Situação")]
        public EnumSituacaoPropostaEliminacaoItem? Situacao { get; set; }
    }
}
