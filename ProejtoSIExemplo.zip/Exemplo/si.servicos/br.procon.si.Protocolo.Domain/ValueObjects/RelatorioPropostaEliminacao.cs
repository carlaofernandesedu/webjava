﻿using System;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class RelatorioPropostaEliminacao
    {
        public string Protocolo { get; set; }

        public string Processo { get; set; }

        public string SerieDocumental { get; set; }

        public DateTime Encerramento { get; set; }

        public int PrazoGuardaProdutora { get; set; }

        public int PrazoGuardaArquivo { get; set; }

        public int NrCaixa { get; set; }

        public int NrVolume { get; set; }
    }
}
