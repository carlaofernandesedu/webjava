﻿using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class TipoArquivamento
    {

        [Column("id_tipo_arquivamento")]
        public int Id { get; set; }

        [Column("ds_tipo_arquivamento")]
        public string Descricao { get; set; }

        public TipoArquivamento()
        {

        }
    }
}
