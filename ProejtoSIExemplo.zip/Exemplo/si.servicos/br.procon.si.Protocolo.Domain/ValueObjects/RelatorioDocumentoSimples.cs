﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class RelatorioDocumentoSimples
    {
        public int IdDocumentoSimples { get; set; }

        public int Opcao { get; set; }

        public string ContentHeader { get; set; }

        public string ContentBody { get; set; }

        public string ContentFooter { get; set; }
    }
}
