﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class GrupoDocumento
    {
        [Column("id_grupo_documento")]
        public int IdGrupoDocumento { get; set; }

        [Column("ds_sigla_grupo_documento")]
        public string Sigla { get; set; }

        [Column("ds_grupo_documento")]
        public string Descricao { get; set; }
    }
}
