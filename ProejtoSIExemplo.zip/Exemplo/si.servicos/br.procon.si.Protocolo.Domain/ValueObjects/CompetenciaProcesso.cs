﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class CompetenciaProcesso
    {
        public CompetenciaProcesso() { }

        [Column("id_competencia_processo")]
        public int IdCompetenciaProcesso { get; set; }

        [Column("ds_competencia_processo")]
        public string Descricao { get; set; }

        [Column("bl_ativo_competencia_processo")]
        public bool Ativo { get; set; }
    }
}
