﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class FiltroAutuacaoProcesso
    {
        [Display(Name = "Nº do Protocolo")]
        [StringLength(11, MinimumLength = 11, ErrorMessage = "Número de Protocolo inválido!")]
        public string NrProtocoloFormatado { get; set; }

        public int? NrProtocoloNumero { get; set; }

        public int? NrProtocoloAno { get; set; }

        [Display(Name = "UA Solicitante")]
        public int? UaSolicitante { get; set; }

        public int? UaProtocolo { get; set; }

        [Display(Name = "Sigilo")]
        public bool? Sigilo { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd}", ApplyFormatInEditMode = true)]
        public DateTime? DataInicial { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd}", ApplyFormatInEditMode = true)]
        public DateTime? DataFinal { get; set; }

        [Display(Name = "Situação")]
        public byte? IdSituacao { get; set; }
    }
}