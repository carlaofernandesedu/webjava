﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class SerieDocumentalClassificacao
    {

        [Column("id_serie_documental_classificacao")]
        public int IdSerieDocumentalClassificacao { get; set; }

        [Column("ds_serie_documental_classificacao")]
        public string Descricao { get; set; }

        public SerieDocumentalClassificacao()
        {

        }
    }
}
