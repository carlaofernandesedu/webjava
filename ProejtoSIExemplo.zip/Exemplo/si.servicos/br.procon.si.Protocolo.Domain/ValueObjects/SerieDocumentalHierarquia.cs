﻿namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class SerieDocumentalHierarquia
    {
        public int IdFuncao { get; set; }
        public int IdSubFuncao { get; set; }
        public int IdAtividade { get; set; }
        public int NrSerieDocumental { get; set; }
        public string Descricao { get; set; }

        public string SerieDocumentalFormatada
        {
            get { return Formatar(IdFuncao, IdSubFuncao, IdAtividade, NrSerieDocumental, Descricao); }
        }

        public static string Formatar(int idFuncao, int idSubFuncao, int idAtividade, int nrSerieDocumental, string descricao)
        {
            return idFuncao.ToString("D2") + "." + idSubFuncao.ToString("D2") + "." + idAtividade.ToString("D2") + "." + nrSerieDocumental.ToString("D2") + " " + descricao;
        }
    }
}