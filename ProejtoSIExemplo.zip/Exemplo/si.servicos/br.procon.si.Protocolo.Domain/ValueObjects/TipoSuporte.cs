﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class TipoSuporte
    {
        [Column("id_tipo_suporte")]
        public int IdTipoSuporte { get; set; }

        [Column("ds_tipo_suporte")]
        public string Descricao { get; set; }
    }
}
