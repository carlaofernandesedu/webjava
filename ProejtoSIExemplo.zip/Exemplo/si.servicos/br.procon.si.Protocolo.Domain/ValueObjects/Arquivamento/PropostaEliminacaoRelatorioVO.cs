﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace br.procon.si.Protocolo.Domain.ValueObjects.Arquivamento
{
    public class PropostaEliminacaoRelatorioVO
    {
        #region Propriedades

        public string Artigo { get; set; }

        public int TipoProposta { get; set; }

        public string NomeRelatorio { get; set; }

        public string NomeFundacao { get; set; }

        public string NomeUA { get; set; }

        public string NomeComissao { get; set; }

        public string NumeroProposta { get; set; }

        public DateTime Data { get; set; }

        public string SubTitulo { get; set; }

        public string CorpoTexto { get; set; }

        public string Dia
        {
            get
            {
                return Data.Day.ToString();
            }
        }

        public string Mes
        {
            get
            {
                return Data.ToString("MMMM", CultureInfo.CreateSpecificCulture("pt-br"));
            }
        }

        public string Ano
        {
            get
            {
                return Data.Year.ToString();
            }
        }

        public int TotalCaixas { get; set; }

        public decimal TotalMetrosLineares { get; set; }

        public string Cidade { get; set; }

        public List<PropostaEliminacaoItemRelatorioVO> Itens { get; set; }

        #endregion Propriedades

        public PropostaEliminacaoRelatorioVO()
        {
            this.Itens = new List<PropostaEliminacaoItemRelatorioVO>();
        }
    }

    public class PropostaEliminacaoItemRelatorioVO
    {
        #region Propriedades

        public string Item { get; set; }

        public string Funcao { get; set; }

        public string SubFuncao { get; set; }

        public string Atividade { get; set; }

        public string SerieDocumental { get; set; }

        public string DatasLimite { get; set; }

        public string Caixas { get; set; }

        public string MetrosLineares { get; set; }

        public string Observacoes { get; set; }

        #endregion Propriedades
    }
}