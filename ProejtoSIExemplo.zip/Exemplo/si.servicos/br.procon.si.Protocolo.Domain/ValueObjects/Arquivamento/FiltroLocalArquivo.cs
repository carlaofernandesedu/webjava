﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Protocolo.Domain.ValueObjects.Arquivamento
{
    public class FiltroLocalArquivo
    {
        public int? IdLocalArquivo { get; set; }
        public int? IdUA { get; set; }
        public string NomeUA { get; set; }
    }
}
