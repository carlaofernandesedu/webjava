﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Protocolo.Domain.ValueObjects
{
    public class FolhaLiderDocumentoVolume
    {        
        public int nr_seq_processo { get; set; }

        public int nr_ano_processo { get; set; }

        public int cd_competencia_processo { get; set; }
        
        public int id_usuario { get; set; }

        public int id_ua { get; set; }

        [Column("NumeroProcesso")]
        public string NumeroProcesso { get; set; }

        [Column("Interessado")]
        public string Interessado { get; set; }
        
        [Column("ds_serie_documental")]
        public string Serie { get; set; }

        [Column("ds_assunto")]
        public string Assunto { get; set; }

        [Column("dt_autuacao_processo")]
        public DateTime dt_autuacao { get; set; }

        [Column("AutuadoPor")]
        public string AutuadoPor { get; set; }

        [Column("Unidade")]
        public string Unidade { get; set; }

        [Column("NumeroProtocolo")]
        public string NumeroProtocolo { get; set; }

        public decimal NumeroVolume { get; set; }
    }
}
