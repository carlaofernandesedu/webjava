﻿using br.procon.si.Core.Domain.ValueObjects;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Protocolo.Domain.Entities
{
    public class CaixaArquivo : Aggregate
    {
        #region Propriedade

        [Column("id_caixa_arquivo")]
        public int Id { get; private set; }

        [Column("cd_caixa_arquivo")]
        public string Codigo { get; private set; }

        [Column("ds_caixa_arquivo")]
        public string Descricao { get; private set; }

        [Column("bl_ativo_caixa_arquivo")]
        public bool Ativo { get; private set; }

        [Column("id_movel_divisao")]
        public int IdMovelDivisao { get; private set; }

        [Column("id_ua")]
        public int IdUa { get; private set; }

        [Column("id_serie_documental")]
        public short? IdSerieDocumental { get; private set; }

        [Column("dt_criacao")]
        public DateTime DataCriacao { get; private set; }

        [Column("id_usuario_criacao")]
        public int IdUsuarioCriacao { get; private set; }

        [Column("dt_alteracao")]
        public DateTime? DataAlteracao { get; private set; }

        [Column("id_usuario_alteracao")]
        public int? IdUsuarioAlteracao { get; private set; }

        [Column("dt_inicio_caixa")]
        public DateTime? DtInicio { get; private set; }

        [Column("dt_fim_caixa")]
        public DateTime? DtFim { get; private set; }

        [Column("id_ua_produtora")]
        public Int16? IdUAProdutora { get; private set; }

        public string SerieDocumental { get; private set; }

        #endregion Propriedade

        #region Construtor

        public CaixaArquivo()
        {
        }

        public static class CaixaArquivoFactory
        {
            public static CaixaArquivo CaixaArquivo(int id, string codigo, string descricao, bool ativo, int idMovelDivisao, int idUa, short? idSerieDocumental)
            {
                return new CaixaArquivo
                {
                    Id = id,
                    Codigo = codigo,
                    Descricao = descricao,
                    Ativo = ativo,
                    IdMovelDivisao = idMovelDivisao,
                    IdUa = idUa,
                    IdSerieDocumental = idSerieDocumental
                };
            }

            public static CaixaArquivo CaixaArquivoEliminacao(int id, string codigo, string descricao, bool ativo, int idMovelDivisao, int idUa, short? idSerieDocumental, DateTime? dtInicio, DateTime? dtFim, Int16 idUAProdutora)
            {
                return new CaixaArquivo
                {
                    Id = id,
                    Codigo = codigo,
                    Descricao = descricao,
                    Ativo = ativo,
                    IdMovelDivisao = idMovelDivisao,
                    IdUa = idUa,
                    IdSerieDocumental = idSerieDocumental,
                    DtInicio = dtInicio,
                    DtFim = dtFim,
                    IdUAProdutora = idUAProdutora
                };
            }
        }

        #endregion Construtor

        #region Metodo

        public void DefinirId(int id)
        {
            Id = id;
        }

        public void DefinirIdUAProdutora(Int16? idUAProdutora)
        {
            this.IdUAProdutora = idUAProdutora;
        }

        public void DefinirIdMovelDivisao(int idMovelDivisao)
        {
            IdMovelDivisao = idMovelDivisao;
        }

        public void DefinirSerieDocumental(string serieDocumental)
        {
            SerieDocumental = serieDocumental;
        }

        public void DefinirDataInicio(DateTime? dt)
        {
            this.DtInicio = dt;
        }

        public void DefinirDataFim(DateTime? dt)
        {
            this.DtFim = dt;
        }

        #endregion Metodo

        #region Validacao

        public bool? Status { get; set; }

        public override bool IsValid
        {
            get
            {
                return true;
            }
        }

        #endregion Validacao
    }
}