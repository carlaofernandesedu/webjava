﻿using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.Validations;
using br.procon.si.Protocolo.Domain.ValueObjects;
using br.procon.si.Protocolo.Domain.ValueObjects.Enums;
using System;
using System.Collections.Generic;

namespace br.procon.si.Protocolo.Domain.Services
{
    public class DocumentoIncorporacaoService : IDocumentoIncorporacaoService
    {
        private readonly IDocumentoIncorporacaoRepository _documentoIncorporacaoRepository;
        private readonly IDocumentoMovimentacaoRepository _documentoMovimentacaoRepository;
        private readonly IDocumentoRepository _documentoRepository;
        private readonly IUnidadeAdministrativaRepository _unidadeAdministrativaRepository;
        private readonly IProcessoRepository _processoRepository;
        private readonly IDocumentoVolumeRepository _documentoVolumeRepository;
        private readonly ISerieDocumentalRepository _serieDocumentalRepository;
        private readonly IDocumentoMovimentacaoService _documentoMovimentacaoService;
        private readonly IIdentificarParteInteressadaRepository _interessadoRepository;
        private readonly IDocumentoDestinoRepository _documentoDestinoRepository;
        private readonly IRemessaRepository _remessaRepository;
        private readonly IRemessaItemRepository _remessaItemRepository;
        private readonly IDocumentoApensarRepository _documentoApensarRepository;

        private DocumentoMovimentacao _movimentacao;

        public DocumentoIncorporacaoService(IDocumentoIncorporacaoRepository documentoIncorporacaoRepository, IDocumentoMovimentacaoRepository documentoMovimentacaoRepository,
            IUnidadeAdministrativaRepository unidadeAdministrativaRepository,
            IDocumentoRepository documentoRepository,
            IProcessoRepository processoRepository,
            IDocumentoVolumeRepository documentoVolumeRepository,
            ISerieDocumentalRepository serieDocumentalRepository,
            IDocumentoMovimentacaoService documentoMovimentacaoService,
            IIdentificarParteInteressadaRepository interessadoRepository,
            IDocumentoDestinoRepository documentoDestinoRepository,
            IRemessaRepository remessaRepository,
            IRemessaItemRepository remessaItemRepository,
            IDocumentoApensarRepository documentoApensarRepository)
        {
            _documentoIncorporacaoRepository = documentoIncorporacaoRepository;
            _documentoMovimentacaoRepository = documentoMovimentacaoRepository;
            _unidadeAdministrativaRepository = unidadeAdministrativaRepository;
            _documentoRepository = documentoRepository;
            _processoRepository = processoRepository;
            _movimentacao = null;
            _documentoVolumeRepository = documentoVolumeRepository;
            _serieDocumentalRepository = serieDocumentalRepository;
            _documentoMovimentacaoService = documentoMovimentacaoService;
            _interessadoRepository = interessadoRepository;
            _documentoDestinoRepository = documentoDestinoRepository;
            _remessaRepository = remessaRepository;
            _remessaItemRepository = remessaItemRepository;
            _documentoApensarRepository = documentoApensarRepository;
        }

        public DocumentoIncorporacao ObterPorId(int idDocumentoIncorporacao)
        {
            var documentoIncorporacao = _documentoIncorporacaoRepository.ObterPorId(idDocumentoIncorporacao);
            var serieDocumental = _serieDocumentalRepository.Obter(documentoIncorporacao.IdSerieDocumental);
            var interessado = _interessadoRepository.IdentificarInteressantePrincipal(documentoIncorporacao.IdDocumento);
            var doc = _documentoRepository.RecuperarDocumentoPorId(documentoIncorporacao.IdDocumento);

            if (serieDocumental != null)
            {
                documentoIncorporacao.DefinirSerieDocumental(serieDocumental.Descricao);
            }

            if (interessado != null)
            {
                documentoIncorporacao.NomeInteressado = interessado.NomeRazaoSocial;
            }

            if (doc != null)
            {
                documentoIncorporacao.Assunto = doc.DescricaoAssunto;
            }

            return documentoIncorporacao;
        }

        public IEnumerable<DocumentoVolume> ObterVolume(int idDocumento)
        {
            return _documentoVolumeRepository.ObterPorDocumento(idDocumento);
        }

        public IEnumerable<DocumentoIncorporacao> Obter(int idDocumento)
        {
            return _documentoIncorporacaoRepository.Obter(idDocumento);
        }

        public DocumentoIncorporacao Obter(FiltroProcesso filtro)
        {
            return _documentoIncorporacaoRepository.Obter(filtro);
        }

        public DocumentoIncorporacao ObterPorIdDocumentoIncorporado(int idDocumentoIncorporado)
        {
            return _documentoIncorporacaoRepository.ObterPorIdDocumentoIncorporado(idDocumentoIncorporado);
        }

        public DocumentoIncorporacao Incluir(DocumentoIncorporacao entidade, int idUsuarioLogado)
        {
            var idDocumentoPai = entidade.IdDocumento;
            var idDocumentoFilho = entidade.IdDocumentoIncorporado;

            var validarUsuarioPosse = ValidarDocumentoIncorporacao(idUsuarioLogado, ref entidade);
            var validarDocumentoProtocolado = ValidarSeDocumentoEstaProtocolado(ref entidade);
            var validarRegrasRestricaoMovimentacao = ValidarRegraIncorporacao(idDocumentoPai, idDocumentoFilho, idUsuarioLogado, ref entidade);

            if (validarRegrasRestricaoMovimentacao && validarUsuarioPosse && validarDocumentoProtocolado)
            {
                _documentoIncorporacaoRepository.Incluir(entidade);
                _documentoMovimentacaoService.RegistrarMovimentacaoAutomatica(RetornaDocumentosIncorporacao(entidade), EnumTipoMovimento.Incorporacao, entidade.IdDocumento, idUsuarioLogado);
                _documentoMovimentacaoService.RegistrarMovimentacaoAutomatica(RetornaDocumentosIncorporacao(entidade), EnumTipoMovimento.Incorporacao, entidade.IdDocumentoIncorporado, idUsuarioLogado);
            }

            return entidade;
        }

        public DocumentoIncorporacao Alterar(DocumentoIncorporacao entidade, int idUsuarioLogado)
        {
            var idDocumentoPai = entidade.IdDocumento;
            var idDocumentoFilho = entidade.IdDocumentoIncorporado;
            var validarUsuarioPosse = ValidarDocumentoIncorporacao(idUsuarioLogado, ref entidade);
            var validarDocumentoProtocolado = ValidarSeDocumentoEstaProtocolado(ref entidade);
            var validarRegrasRestricaoMovimentacao = ValidarRegraIncorporacao(idDocumentoPai, idDocumentoFilho, idUsuarioLogado, ref entidade);

            if (validarRegrasRestricaoMovimentacao && validarUsuarioPosse && validarDocumentoProtocolado)
            {
                _documentoIncorporacaoRepository.Alterar(entidade);
            }

            return entidade;
        }

        public bool Excluir(DocumentoIncorporacao entidade, int idUsuarioLogado)
        {
            bool retorno = false;
            var idDocumentoPai = entidade.IdDocumento;
            var idDocumentoFilho = entidade.IdDocumentoIncorporado;

            var validarUsuarioPosse = ValidarDocumentoIncorporacao(idUsuarioLogado, ref entidade);
            var validarDocumentoProtocolado = ValidarSeDocumentoEstaProtocolado(ref entidade);
            var validarRegrasRestricaoMovimentacao = ValidarRegraIncorporacao(idDocumentoPai, idDocumentoFilho, idUsuarioLogado, ref entidade);

            if (validarRegrasRestricaoMovimentacao && validarUsuarioPosse && validarDocumentoProtocolado)
            {
                retorno = Convert.ToBoolean(_documentoIncorporacaoRepository.Excluir(entidade.IdDocumentoIncorporacao));
                _documentoMovimentacaoService.RegistrarMovimentacaoAutomatica(RetornaDocumentosIncorporacao(entidade), EnumTipoMovimento.IncorporacaoCancelamento, entidade.IdDocumento, idUsuarioLogado);
            }

            return retorno;
        }

        private bool ValidarRegraIncorporacao(int idDocumentoPai, int idDocumentoFilho, int idUsuarioLogado, ref DocumentoIncorporacao entidade)
        {
            var validationResult = ValidarRegrasRestricaoMovimentacao(idDocumentoPai, idDocumentoFilho, idUsuarioLogado);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public Core.Domain.ValueObjects.ValidationResult ValidarRegrasRestricaoMovimentacao(int idDocumentoPai, int idDocumentoFilho, int idUsuarioLogado)
        {
            var regrasGerais = new DocumentoRegrasGerais();
            var idUaLogado = _unidadeAdministrativaRepository.ObterUADoUsuarioLogado(idUsuarioLogado).IdUA;
            regrasGerais.IdDocumentoPai = idDocumentoPai;
            regrasGerais.IdDocumentoFilho = idDocumentoFilho;

            var validationResult = new DocumentoRegrasGeraisValidation(_processoRepository, _documentoDestinoRepository, _remessaRepository, _remessaItemRepository, _documentoVolumeRepository, _documentoApensarRepository, _documentoIncorporacaoRepository, _documentoRepository, idUaLogado).Valid(regrasGerais);

            foreach (var validationResultError in validationResult.Errors)
            {
                regrasGerais.AdicionarResultadoDeValidacao(validationResultError);
            }

            return regrasGerais.ValidationResult;
        }

        public bool ValidarDocumentoIncorporacao(int idUsuarioLogado, ref DocumentoIncorporacao entidade)
        {
            var validationResult = new DocumentoIncorporacaoValidation(_documentoRepository, _unidadeAdministrativaRepository, idUsuarioLogado).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public bool ValidarSeDocumentoEstaProtocolado(ref DocumentoIncorporacao entidade)
        {
            var validationResult = new DocumentoIncorporacaoValidation(_documentoRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public bool ValidarRegrasRestricaoMovimentacao(int idDocumento, int idUsuarioLogado, ref DocumentoIncorporacao entidade)
        {
            var validationResult = _documentoMovimentacaoService.ValidarRegrasRestricaoMovimentacao(idDocumento, 0, idUsuarioLogado);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private string[] RetornaDocumentosIncorporacao(DocumentoIncorporacao obj)
        {
            string documento = _documentoRepository.Obter(obj.IdDocumentoIncorporado).DocumentoFormatado;
            string processo = _processoRepository.ObterIdDocumento(obj.IdDocumento).NumeroProcessoFormatado;

            string[] parametros = { documento, processo };

            return parametros;
        }
    }
}