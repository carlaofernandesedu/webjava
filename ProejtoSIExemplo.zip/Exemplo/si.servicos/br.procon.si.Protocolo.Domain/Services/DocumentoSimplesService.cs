﻿using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.Validations;
using br.procon.si.Protocolo.Domain.ValueObjects;
using br.procon.si.Protocolo.Domain.ValueObjects.Enums;
using System;
using System.Linq;

namespace br.procon.si.Protocolo.Domain.Services
{
    public class DocumentoSimplesService : IDocumentoSimplesService
    {
        private readonly IDocumentoSimplesRepository _documentoSimplesRepository;
        private readonly IModeloDocumentoRepository _modeloDocumentoRepository;
        private readonly ISerieDocumentalRepository _serieDocumentalRepository;
        private readonly IUnidadeAdministrativaRepository _unidadeAdministrativaRepository;
        private readonly IDocumentoRepository _documentoRepository;
        private readonly IOrigemDocumentoRepository _origemDocumentoRepository;
        private readonly ITipoSuporteRepository _tipoSuporteRepository;
        private readonly IDocumentoParteRepository _documentoParteRepository;
        private readonly IDocumentoSolicitanteRepository _documentoSolicitanteRepository;
        private readonly IGrupoDocumentoRepository _grupoDocumentoRepository;

        private readonly IDocumentoMovimentacaoService _documentoMovimentacaoService;

        public DocumentoSimplesService(IDocumentoSimplesRepository documentoSimplesRepository, IModeloDocumentoRepository modeloDocumentoRepository, ISerieDocumentalRepository serieDocumentalRepository
            , IUnidadeAdministrativaRepository unidadeAdministrativaRepository, IDocumentoRepository documentoRepository, IOrigemDocumentoRepository origemDocumentoRepository, ITipoSuporteRepository tipoSuporteRepository
            , IDocumentoParteRepository documentoParteRepository, IDocumentoSolicitanteRepository documentoSolicitanteRepository, IDocumentoMovimentacaoService documentoMovimentacaoService, IGrupoDocumentoRepository grupoDocumentoRepository)
        {
            _documentoSimplesRepository = documentoSimplesRepository;
            _modeloDocumentoRepository = modeloDocumentoRepository;
            _serieDocumentalRepository = serieDocumentalRepository;
            _unidadeAdministrativaRepository = unidadeAdministrativaRepository;
            _documentoRepository = documentoRepository;
            _origemDocumentoRepository = origemDocumentoRepository;
            _tipoSuporteRepository = tipoSuporteRepository;
            _documentoParteRepository = documentoParteRepository;
            _documentoSolicitanteRepository = documentoSolicitanteRepository;
            _grupoDocumentoRepository = grupoDocumentoRepository;

            _documentoMovimentacaoService = documentoMovimentacaoService;
        }

        public DocumentoSimples Incluir(DocumentoSimples entidade, byte idModeloDocumento, string assuntoDocumento, string nomeInteressado, string nomeSolicitante)
        {
            UnidadeAdministrativa unidadeAdministrativa = _unidadeAdministrativaRepository.ObterUADoUsuarioLogado(entidade.IdUsuarioOperacao);
            ModeloDocumento modeloDocumento = _modeloDocumentoRepository.Obter(idModeloDocumento);
            SerieDocumental serieDocumental = _serieDocumentalRepository.Obter(modeloDocumento.IdSerieDocumental);
            OrigemDocumento origemDocumento = _origemDocumentoRepository.Obter().Where(x => x.Descricao.Equals("Interno", StringComparison.OrdinalIgnoreCase)).First();
            TipoSuporte tipoSuporte = _tipoSuporteRepository.Obter().Where(x => x.Descricao.Equals("Físico")).First();

            if (ValidarInclusaoDocumento(_unidadeAdministrativaRepository, _modeloDocumentoRepository, idModeloDocumento, entidade.IdUsuarioOperacao, ref entidade))
            {
                Documento documento = new Documento(0, DateTime.Now.Year, unidadeAdministrativa.IdUA, DateTime.Now, unidadeAdministrativa.Sigla, origemDocumento.IdOrigemDocumento, DateTime.Now, 1, tipoSuporte.IdTipoSuporte, (int)EnumSituacaoDocumento.Cadastrado, unidadeAdministrativa.IdUA);
                documento.IdSerieDocumental = serieDocumental.IdSerieDocumental;
                documento.IdUsuarioOperacao = entidade.IdUsuarioOperacao;
                documento.Descricao = assuntoDocumento;
                documento.NomeDocumento = serieDocumental.TituloSerie;
                documento.IdUsuarioPosse = entidade.IdUsuarioOperacao;
                documento.DataDocumento = DateTime.Now;
                documento = _documentoRepository.GerarDocumentoRemessa(documento);
                _documentoMovimentacaoService.RegistrarMovimentacaoAutomatica(null, EnumTipoMovimento.Protocolo, documento.IdDocumento, entidade.IdUsuarioOperacao);

                if (!string.IsNullOrEmpty(nomeInteressado))
                    IncluirDocumentoParte(documento.IdDocumento, nomeInteressado);

                if (!string.IsNullOrEmpty(nomeSolicitante))
                    IncluirDocumentoSolicitante(documento.IdDocumento, nomeSolicitante);

                entidade.DefinirIdUA((short)unidadeAdministrativa.IdUA);
                entidade.DefinirIdGrupoDocumento((byte)serieDocumental.IdGrupoDocumento);
                entidade.DefinirIdDocumento(documento.IdDocumento);

                entidade = _documentoSimplesRepository.Incluir(entidade);
            }
            return entidade;
        }

        public DocumentoSimples Alterar(DocumentoSimples entidade)
        {
            return _documentoSimplesRepository.Alterar(entidade);
        }

        public DocumentoSimples Obter(int idDocumentoSimples, int idUsuarioLogado)
        {
            DocumentoSimples entidade = _documentoSimplesRepository.Obter(idDocumentoSimples);
            DocumentoSimples documentoSimples = new DocumentoSimples();

            if (ValidarVisualizacaoDocumento(_unidadeAdministrativaRepository, idUsuarioLogado, ref entidade))
                documentoSimples = entidade;

            return documentoSimples;
        }

        public GrupoDocumento ObterGrupoDocumento(int id)
        {
            var grupo = _grupoDocumentoRepository.Obter().Where(x => x.IdGrupoDocumento.Equals(id)).FirstOrDefault();
            return grupo;
        }

        public byte[] ObterPDF(int idDocumentoSimples, string localizacaoRDL, string nomeUsuarioLogado, int? IdUaUsuarioLogado)
        {
            DocumentoSimples entidade = _documentoSimplesRepository.Obter(idDocumentoSimples);
            RelatorioDocumentoSimples relatorio = new RelatorioDocumentoSimples();

            relatorio.IdDocumentoSimples = entidade.IdDocumentoSimples;

            throw new NotImplementedException();

        }

        private bool ValidarInclusaoDocumento(IUnidadeAdministrativaRepository unidadeAdministrativaRepository, IModeloDocumentoRepository modeloDocumentoRepository, int idModeloDocumento, int idUsuarioLogado, ref DocumentoSimples entidade)
        {
            var validationResult = new DocumentoSimplesValidation(unidadeAdministrativaRepository, modeloDocumentoRepository, idModeloDocumento, idUsuarioLogado).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private bool ValidarVisualizacaoDocumento(IUnidadeAdministrativaRepository unidadeAdministrativaRepository, int idUsuarioLogado, ref DocumentoSimples entidade)
        {
            var validationResult = new DocumentoSimplesValidation(unidadeAdministrativaRepository, idUsuarioLogado).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;

        }

        private void IncluirDocumentoParte(int idDocumento, string nome)
        {
            DocumentoParte documentoParte = new DocumentoParte(idDocumento, 0, true, false, false, true);
            documentoParte.DefinirNome(nome);
            _documentoParteRepository.Incluir(documentoParte);
        }

        private void IncluirDocumentoSolicitante(int idDocumento, string nome)
        {
            DocumentoSolicitante documentoSolicitante = new DocumentoSolicitante(idDocumento, 0, true, false, true);
            documentoSolicitante.DefinirNome(nome);
            _documentoSolicitanteRepository.Incluir(documentoSolicitante);
        }
    }
}