﻿using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.Validations;
using System.Collections.Generic;
using System.Linq;

namespace br.procon.si.Protocolo.Domain.Services
{
    public class DocumentoParteService : IDocumentoParteService
    {
        private readonly IDocumentoRepository _documentoRepository;
        private readonly IDocumentoParteRepository _documentoParteRepository;
        private readonly IDocumentoSolicitanteRepository _documentoSolicitanteRepository;
        private readonly IUnidadeAdministrativaRepository _unidadeAdministrativaRepository;
        private readonly ISerieDocumentalRepository _serieDocumentalRepository;

        public DocumentoParteService(IDocumentoParteRepository documentoParteRepository, 
            IDocumentoSolicitanteRepository documentoSolicitanteRepository, 
            IDocumentoRepository documentoRepository, 
            IUnidadeAdministrativaRepository unidadeAdministrativaRepository,
            ISerieDocumentalRepository serieDocumentalRepository)
        {
            _documentoParteRepository = documentoParteRepository;
            _documentoSolicitanteRepository = documentoSolicitanteRepository;
            _documentoRepository = documentoRepository;
            _unidadeAdministrativaRepository = unidadeAdministrativaRepository;
            _serieDocumentalRepository = serieDocumentalRepository;
        }

        public IEnumerable<DocumentoParte> Obter(int idDocumento, int? idUaUsuarioLogado)
        {
            var retorno = _documentoParteRepository.Obter(idDocumento);
            return retorno.ToList().OrderByDescending(x => x.Principal).ThenBy(x => x.Nome);
        }

        public DocumentoParte ObterPorId(int idDocumentoParte, int? idUaUsuarioLogado)
        {
            return _documentoParteRepository.ObterPorId(idDocumentoParte);
        }

        public DocumentoParte Alterar(DocumentoParte obj, int? idUaUsuarioLogado, int idUsuarioLogado)
        {
            var listaInteressado = _documentoParteRepository.Obter(obj.IdDocumento).ToList();
            var qtdInteressadoPrincipal = _documentoParteRepository.Obter(obj.IdDocumento).Count(x => x.Principal);

            var doc = _documentoRepository.Obter(obj.IdDocumento);

            var uaProdutoraUsuarioLogado = ValidarUaProdutoraUsuario(ref doc, _documentoRepository, _unidadeAdministrativaRepository, idUsuarioLogado);

            if (uaProdutoraUsuarioLogado)
            {
                if (qtdInteressadoPrincipal > 0)
                {
                    var interessadoPricipal = listaInteressado.FirstOrDefault(x => x.Principal);
                    if (interessadoPricipal != null && interessadoPricipal.IdDocumentoParte != obj.IdDocumentoParte && obj.Principal)
                    {
                        interessadoPricipal.DefinirPrincipal(false);
                        _documentoParteRepository.Alterar(interessadoPricipal);
                    }
                    else if (interessadoPricipal != null && interessadoPricipal.IdDocumentoParte == obj.IdDocumentoParte && obj.Principal == false)
                        obj.DefinirPrincipal(true);
                }
                else
                {
                    obj.DefinirPrincipal(true);
                }

                obj = _documentoParteRepository.Alterar(obj);

                if (obj.Solicitante)
                {
                    IncluirParteSolicitante(obj);
                }
            }
            obj.ValidationResult.Add(doc.ValidationResult);
            return obj;
        }

        public int Excluir(int idDocumentoParte, int? idUaUsuarioLogado)
        {
            return _documentoParteRepository.Excluir(idDocumentoParte);
        }

        public DocumentoParte Incluir(DocumentoParte obj, int? idUaUsuarioLogado, int idUsuarioLogado)
        {
            var listaInteressado = _documentoParteRepository.Obter(obj.IdDocumento).ToList();
            var qtdInteressadoPrincipal = _documentoParteRepository.Obter(obj.IdDocumento).Count(x => x.Principal);

            var doc = _documentoRepository.Obter(obj.IdDocumento);

            var uaProdutoraUsuarioLogado = ValidarUaProdutoraUsuario(ref doc, _documentoRepository, _unidadeAdministrativaRepository, idUsuarioLogado);

            if (uaProdutoraUsuarioLogado)
            {
                if (qtdInteressadoPrincipal > 0)
                {
                    var interessadoPricipal = listaInteressado.FirstOrDefault(x => x.Principal);
                    if (interessadoPricipal != null && interessadoPricipal.IdDocumentoParte != obj.IdDocumentoParte && obj.Principal)
                    {
                        interessadoPricipal.DefinirPrincipal(false);
                        _documentoParteRepository.Alterar(interessadoPricipal);
                    }
                    else if (interessadoPricipal != null && interessadoPricipal.IdDocumentoParte == obj.IdDocumentoParte && obj.Principal == false)
                        obj.DefinirPrincipal(true);
                }
                else
                {
                    obj.DefinirPrincipal(true);
                }

                obj = _documentoParteRepository.Incluir(obj);

                if (obj.Solicitante)
                {
                    IncluirParteSolicitante(obj);
                }
            }
            obj.ValidationResult.Add(doc.ValidationResult);
            return obj;
        }

        private void IncluirParteSolicitante(DocumentoParte obj)
        {
            DocumentoSolicitante docSolicitante = new DocumentoSolicitante(obj.IdDocumento, obj.NrSeqDocumentoParte, false, obj.Exterior, true);

            docSolicitante.DefinirNome(obj.Nome);
            docSolicitante.DefinirDocumentoPessoal(obj.DocumentoPessoal);
            docSolicitante.DefinirOrgaoRG(obj.OrgaoRG);
            docSolicitante.DefinirOrgaoUfRG(obj.OrgaoUfRG);
            docSolicitante.DefinirPais(obj.Pais);

            _documentoSolicitanteRepository.Incluir(docSolicitante);
        }

        private bool ValidarEntidadeDocumento(Documento entity, int? idUAUsuario)
        {
            var validationResult = new DocumentoValidation(idUAUsuario, _serieDocumentalRepository).Valid(entity);

            foreach (var validationResultError in validationResult.Errors)
            {
                entity.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private bool ValidarUaProdutoraUsuario(ref Documento entity, IDocumentoRepository documentoRepository, IUnidadeAdministrativaRepository unidadeAdministrativaRepository, int idUsuarioLogado)
        {
            var validationResult = new DocumentoEditarDadosValidation(documentoRepository, unidadeAdministrativaRepository, idUsuarioLogado).Valid(entity);

            foreach (var validationResultError in validationResult.Errors)
            {
                entity.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }
    }
}