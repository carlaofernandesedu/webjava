﻿using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.ValueObjects;
using br.procon.si.Protocolo.Domain.ValueObjects.Arquivamento;
using br.procon.si.Protocolo.Domain.ValueObjects.Enums;
using System;
using System.Collections.Generic;
using System.Linq;

namespace br.procon.si.Protocolo.Domain.Services
{
    public class PropostaEliminacaoService : IPropostaEliminacaoService
    {
        private readonly IPropostaEliminacaoRepository _propostaEliminacaoRepository;
        private readonly IPropostaItemRepository _propostaItemRepository;
        private readonly IPropostaEliminacaoRelatorio _propostaEliminacaoRelatorio;
        private readonly ISerieDocumentalRepository _repSerieDoc;
        private readonly IUnidadeAdministrativaRepository _repUnidadeAdministrativaRepository;

        public PropostaEliminacaoService(IPropostaEliminacaoRepository propostaEliminacaoRepository, IPropostaItemRepository propostaItemRepository, ISerieDocumentalRepository repSerieDoc, IUnidadeAdministrativaRepository repUnidadeAdministrativaRepository, IPropostaEliminacaoRelatorio propostaEliminacaoRelatorio)
        {
            _propostaEliminacaoRepository = propostaEliminacaoRepository;
            _propostaItemRepository = propostaItemRepository;
            _propostaEliminacaoRelatorio = propostaEliminacaoRelatorio;
            _repSerieDoc = repSerieDoc;
            _repUnidadeAdministrativaRepository = repUnidadeAdministrativaRepository;
        }

        public PropostaEliminacao Obter(int idPropostaEliminacao)
        {
            return _propostaEliminacaoRepository.Obter(idPropostaEliminacao);
        }

        public IEnumerable<PropostaEliminacao> Obter()
        {
            return _propostaEliminacaoRepository.Obter();
        }

        public IEnumerable<PropostaEliminacao> Obter(FiltroPropostaEliminacao entidade)
        {
            return _propostaEliminacaoRepository.Obter(entidade);
        }

        public PropostaEliminacao Incluir(PropostaEliminacao entidade)
        {
            return _propostaEliminacaoRepository.Incluir(entidade);
        }

        public PropostaEliminacao Alterar(PropostaEliminacao entidade)
        {
            return _propostaEliminacaoRepository.Alterar(entidade);
        }

        public byte[] GerarAnexo(int id, string localizacaoRDL, int? tipoAnexo)
        {
            var propostaEntidade = _propostaEliminacaoRepository.Obter(id);
            var unidadeAdm = _repUnidadeAdministrativaRepository.RecuperarPorId(propostaEntidade.IdUA);
            var itens = _propostaItemRepository.Obter(id);

            var vo = new PropostaEliminacaoRelatorioVO();

            vo.NomeRelatorio = !tipoAnexo.HasValue ? DefinirTituloRelatorio(propostaEntidade) : (tipoAnexo == 2 ? "ANEXO II" : "ANEXO III");
            vo.NomeFundacao = "Fundação de Proteção e Defesa do Consumidor";
            vo.NomeComissao = "COMISSÃO DE AVALIAÇÃO DE DOCUMENTOS DE ARQUIVO";
            vo.NomeUA = unidadeAdm.Nome;
            vo.NumeroProposta = String.Format("{0:D3}", propostaEntidade.NrProposta) + "/" + propostaEntidade.DataOperacao.Year.ToString();
            vo.TipoProposta = propostaEntidade.TipoPropostaEliminacao;

            switch (vo.NomeRelatorio.ToUpper())
            {
                case "ANEXO I":
                    vo.Artigo = "A que se refere o artigo 26 do Decreto nº 48.897, de 27 de agosto de 2004.";
                    vo.SubTitulo = string.Format(
                    @"RELAÇÃO DE ELIMINAÇÃO DE DOCUMENTOS nº {0}/{1}"
                    , propostaEntidade.NrProposta.ToString()
                    , propostaEntidade.AnoProposta.ToString());

                    break;

                case "ANEXO II":

                    vo.Artigo = "A que se refere o artigo 27 do Decreto nº 48.897, de 27 de agosto de 2004.";
                    vo.SubTitulo = string.Format(
                    @"EDITAL DE CIÊNCIA DE ELIMINAÇÃO DE DOCUMENTOS nº {0}/{1}"
                    , propostaEntidade.NrProposta.ToString()
                    , propostaEntidade.AnoProposta.ToString());

                    vo.CorpoTexto = string.Format(
                        @"O (A) Coordenador(a) da Comissão de Avaliação de Documentos de Arquivo, instituída pela Resolução/Portaria/Ato nº 21, publicada(o) no Diário Oficial do Estado de São Paulo de 21/02/2017, em conformidade com os prazos definidos na Tabela de Temporalidade de Documentos da Administração Pública do Estado de São Paulo: Atividades-Meio e Atividades-Fim, faz saber a quem possa interessar que, a partir do 30º dia subseqüente à data de publicação deste Edital, o {0} eliminará os documentos abaixo relacionados. Os interessados poderão requerer às suas expensas, no prazo citado, o desentranhamento de documentos ou cópias de peças do processo, mediante petição, desde que tenha respectiva qualificação e demonstração de legitimidade do pedido, dirigida à Comissão de Avaliação de Documentos de Arquivo."
                        , vo.NomeUA);

                    break;

                case "ANEXO III":

                    vo.Artigo = "A que se refere o artigo 28 do Decreto nº 48.897, de 27 de agosto de 2004.";
                    vo.SubTitulo = string.Format(
                   @"TERMO DE ELIMINAÇÃO DE DOCUMENTOS nº {0}/{1}"
                   , propostaEntidade.NrProposta.ToString()
                   , propostaEntidade.AnoProposta.ToString());

                    vo.CorpoTexto = string.Format(
                        @"Aos {0} dias do mês de {1} do ano de {2}, o {3}, em conformidade com os prazos definidos na Tabela de Temporalidade de Documentos da Administração Pública do Estado de São Paulo: Atividades-Meio e Atividades-Fim, procedeu à eliminação dos documentos abaixo relacionados:"
                        , propostaEntidade.DtFragmentacao.Value.Day
                        , propostaEntidade.DtFragmentacao.Value.ToString("MMMM")
                        , propostaEntidade.DtFragmentacao.Value.Year
                        , vo.NomeUA);

                    break;
            }

            var count = 1;
            var ttlCaixas = 0;
            decimal ttlMetrosLineares = 0;

            foreach (var item in itens)
            {
                ValueObjects.SerieDocumental serie = _repSerieDoc.Obter(item.IdSerieDocumental);

                var newItem = new PropostaEliminacaoItemRelatorioVO();
                newItem.Item = count.ToString();
                newItem.Funcao = serie.Funcao;
                newItem.SubFuncao = serie.SubFuncao;
                newItem.Atividade = serie.Atividade;
                newItem.SerieDocumental = serie.Descricao;

                if (serie.FimVigencia.HasValue)
                {
                    newItem.DatasLimite = serie.FimVigencia.Value.ToShortDateString();
                }
                else
                {
                    newItem.DatasLimite = string.Empty;
                }
                newItem.Caixas = item.QtdCaixas.ToString();
                newItem.MetrosLineares = item.QtdMetroLinear.ToString();
                newItem.Observacoes = item.Observacao;

                count++;
                ttlCaixas += item.QtdCaixas;
                ttlMetrosLineares += item.QtdMetroLinear;

                vo.Itens.Add(newItem);
            }

            vo.TotalCaixas = ttlCaixas;
            vo.TotalMetrosLineares = ttlMetrosLineares;
            vo.Cidade = "São Paulo";
            vo.Data = propostaEntidade.DataOperacao;

            return _propostaEliminacaoRelatorio.ObterPropostaEliminacaoPDF(vo, localizacaoRDL);
        }

        private static string DefinirTituloRelatorio(PropostaEliminacao propostaEntidade)
        {
            switch ((TipoPropostaEliminacao)propostaEntidade.TipoPropostaEliminacao)
            {
                case TipoPropostaEliminacao.Inicial:
                    return "ANEXO I";

                case TipoPropostaEliminacao.Consolidada:
                    return "ANEXO II";

                case TipoPropostaEliminacao.CADA:
                    return "ANEXO III";

                default:
                    return "ANEXO";
            }
        }

        public IEnumerable<PropostaEliminacao> ObterPropostaEliminacaoPorTipoPropostaEliminacao(int idTipoPropostaEliminacao)
        {
            var propostaEliminacao = _propostaEliminacaoRepository.Obter();
            return propostaEliminacao.ToList().Where(x => x.TipoPropostaEliminacao == idTipoPropostaEliminacao);
        }
    }
}