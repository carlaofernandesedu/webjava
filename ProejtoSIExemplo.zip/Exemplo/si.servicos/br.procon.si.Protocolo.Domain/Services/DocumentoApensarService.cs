﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.Validations;
using br.procon.si.Protocolo.Domain.ValueObjects;
using br.procon.si.Protocolo.Domain.Infra;
using br.procon.si.Protocolo.Domain.ValueObjects.Enums;
using br.procon.si.Core.Domain.ValueObjects;
using System.Text.RegularExpressions;

namespace br.procon.si.Protocolo.Domain.Services
{
    public class DocumentoApensarService : IDocumentoApensarService
    {
        private readonly IDocumentoApensarRepository _documentoApensarRepository;
        private readonly IDocumentoMovimentacaoRepository _documentoMovimentacaoRepository;
        private readonly IDocumentoRepository _documentoRepository;
        private readonly IUnidadeAdministrativaRepository _unidadeAdministrativaRepository;
        private readonly IProcessoRepository _processoRepository;
        private readonly IIdentificarParteInteressadaRepository _obterInteressado;
        private readonly IDocumentoVolumeRepository _documentoVolume;
        private readonly IRelatorioProtocolo _obterPdf;

        private readonly IDocumentoMovimentacaoService _documentoMovimentacaoService;

        public DocumentoApensarService(
            IDocumentoMovimentacaoRepository documentoMovimentacaoRepository,
            IDocumentoRepository documentoRepository,
            IUnidadeAdministrativaRepository unidadeAdministrativaRepository,
            IDocumentoApensarRepository documentoApensarRepository,
            IProcessoRepository processoRepository,
            IRelatorioProtocolo obterPdf,
            IDocumentoMovimentacaoService documentoMovimentacaoService,
            IIdentificarParteInteressadaRepository obterInteressado,
            IDocumentoVolumeRepository documentoVolume)
        {
            _documentoApensarRepository = documentoApensarRepository;
            _documentoMovimentacaoRepository = documentoMovimentacaoRepository;
            _documentoRepository = documentoRepository;
            _unidadeAdministrativaRepository = unidadeAdministrativaRepository;
            _processoRepository = processoRepository;
            _obterPdf = obterPdf;
            _documentoMovimentacaoService = documentoMovimentacaoService;
            _obterInteressado = obterInteressado;
            _documentoVolume = documentoVolume;
        }

        public DocumentoApensar ObterPorId(int idApensar)
        {
            return _documentoApensarRepository.ObterPorId(idApensar);
        }

        public IEnumerable<DocumentoApensar> Obter()
        {
            return _documentoApensarRepository.Obter();
        }

        public IEnumerable<DocumentoApensar> Obter(int idDocumento)
        {
            var idProcesso = _processoRepository.ObterIdDocumento(idDocumento).Codigo;
            return _documentoApensarRepository.Obter(idProcesso);
        }

        public DocumentoApensar ObterPorProcessoApensado(int idProcessoApensar)
        {
            return _documentoApensarRepository.ObterPorProcessoApensado(idProcessoApensar);
        }

        public DocumentoApensar Incluir(DocumentoApensar entidade, int idUsuarioLogado, int idUaUsuarioLogado)
        {
            var idDocumentoPai = _processoRepository.ObterPorId(entidade.CodigoProcesso).IdDocumento;
            var idDocumentoFilho = _processoRepository.ObterPorId(entidade.CodigoProcessoApensar).IdDocumento;

            var validarRegrasRestricaoMovimentacao = ValidarRegrasRestricaoMovimentacao(idDocumentoPai, idDocumentoFilho, idUsuarioLogado, ref entidade);
            var validar = ValidarInserirApensamento(entidade, idUsuarioLogado, idUaUsuarioLogado);

            if (validarRegrasRestricaoMovimentacao && validar)
            {
                entidade.IdUsuarioOperacao = idUsuarioLogado;
                entidade = _documentoApensarRepository.Incluir(entidade);

                _documentoMovimentacaoService.RegistrarMovimentacaoAutomatica(RetornaDocumentosApensado(entidade), EnumTipoMovimento.Apensamento, ObterProcesso(entidade.CodigoProcesso).IdDocumento, idUsuarioLogado);
                _documentoMovimentacaoService.RegistrarMovimentacaoAutomatica(RetornaDocumentosApensado(entidade), EnumTipoMovimento.Apensamento, ObterProcesso(entidade.CodigoProcessoApensar).IdDocumento, idUsuarioLogado);
            }

            return entidade;
        }

        public DocumentoApensar Alterar(DocumentoApensar entidade, int idUsuarioLogado, int idUaUsuarioLogado)
        {
            var validar = ValidarAlterarApensamento(entidade, idUsuarioLogado, idUaUsuarioLogado);

            if (validar)
            {
                entidade.IdUsuarioOperacao = idUsuarioLogado;
                entidade = _documentoApensarRepository.Alterar(entidade);
                // Todo: Foi identificado pelo Sérgio que o modelo atual da movimentação não permite a alteração pois não tem vinculo com a tabela de DocumentoApensar. Possível melhoria        
            }

            return entidade;
        }

        public DocumentoApensar Excluir(DocumentoApensar entidade, int idUsuarioLogado, int idUaUsuarioLogado)
        {
            var validar = ValidarExcluirApensamento(entidade, idUsuarioLogado, idUaUsuarioLogado);

            if (validar)
            {
                entidade.IdUsuarioOperacao = idUsuarioLogado;
                _documentoApensarRepository.Excluir(entidade.Codigo);

                _documentoMovimentacaoService.RegistrarMovimentacaoAutomatica(RetornaDocumentosApensado(entidade), EnumTipoMovimento.ApensamentoCancelamento, ObterProcesso(entidade.CodigoProcesso).IdDocumento, idUsuarioLogado);
                _documentoMovimentacaoService.RegistrarMovimentacaoAutomatica(RetornaDocumentosApensado(entidade), EnumTipoMovimento.ApensamentoCancelamento, ObterProcesso(entidade.CodigoProcessoApensar).IdDocumento, idUsuarioLogado);
            }

            return entidade;
        }

        public DocumentoApensar Desapensamento(DocumentoApensar entidade, int idUsuarioLogado, int idUaUsuarioLogado)
        {
            var validar = ValidarDesapensamnto(entidade, idUsuarioLogado, idUaUsuarioLogado);

            if (validar)
            {
                entidade.IdUsuarioOperacao = idUsuarioLogado;
                _documentoApensarRepository.Desapensamento(entidade);

                _documentoMovimentacaoService.RegistrarMovimentacaoAutomatica(RetornaDocumentosApensado(entidade), EnumTipoMovimento.Desapensamento, ObterProcesso(entidade.CodigoProcesso).IdDocumento, idUsuarioLogado);
                _documentoMovimentacaoService.RegistrarMovimentacaoAutomatica(RetornaDocumentosApensado(entidade), EnumTipoMovimento.Desapensamento, ObterProcesso(entidade.CodigoProcessoApensar).IdDocumento, idUsuarioLogado);
            }
            return entidade;
        }

        #region Validadores

        public bool ValidarInserirApensamento(DocumentoApensar entidade, int idUsuarioLogado, int idUaUsuarioLogado)
        {
            var validationResult = new DocumentoApensarInserirValidation(_documentoApensarRepository, _documentoRepository, _processoRepository, _unidadeAdministrativaRepository, _documentoMovimentacaoRepository, idUsuarioLogado, idUaUsuarioLogado).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public bool ValidarAlterarApensamento(DocumentoApensar entidade, int idUsuarioLogado, int idUaUsuarioLogado)
        {
            var validationResult = new DocumentoApensarAlterarValidation(_documentoApensarRepository, _documentoRepository, _processoRepository,
                                                                         _unidadeAdministrativaRepository, _documentoMovimentacaoRepository, idUsuarioLogado, idUaUsuarioLogado).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public bool ValidarExcluirApensamento(DocumentoApensar entidade, int idUsuarioLogado, int idUaUsuarioLogado)
        {
            var validationResult = new DocumentoApensarExcluirValidation(
                _documentoApensarRepository,
                _documentoRepository,
                _processoRepository,
                _unidadeAdministrativaRepository,
                _documentoMovimentacaoRepository,
                idUsuarioLogado,
                idUaUsuarioLogado).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public bool ValidarDesapensamnto(DocumentoApensar entidade, int idUsuarioLogado, int idUaUsuarioLogado)
        {
            var validationResult = new DocumentoDesapensarValidation(
                _documentoApensarRepository,
                _documentoRepository,
                _processoRepository,
                _unidadeAdministrativaRepository,
                _documentoMovimentacaoRepository,
                idUsuarioLogado,
                idUaUsuarioLogado).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }
            return validationResult.IsValid;
        }

        public bool ValidarRegrasRestricaoMovimentacao(int idDocumentoPai, int idDocumentoFilho, int idUsuarioLogado, ref DocumentoApensar entidade)
        {
            var validationResult = _documentoMovimentacaoService.ValidarRegrasRestricaoMovimentacao(idDocumentoPai, idDocumentoFilho, idUsuarioLogado);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        #endregion

        public byte[] TermoApensamento(int id, string localizacaoRDL, string nomeUsuarioLogado, int? IdUaUsuarioLogado)
        {

            var entidade = _documentoApensarRepository.ObterPorId(id);
            var unidade = _unidadeAdministrativaRepository.Obter((int)IdUaUsuarioLogado);
            var processo = ObterProcesso(entidade.CodigoProcesso);
            var processoApensar = ObterProcesso(entidade.CodigoProcessoApensar);
            var documento = _documentoRepository.Obter(processo.IdDocumento);
            var volumes = _documentoVolume.ObterPorDocumento(processoApensar.IdDocumento).ToList();
            var interessado = _obterInteressado.IdentificarInteressantePrincipal(processo.IdDocumento).NomeRazaoSocial;
            var assunto = documento.Descricao;
            var _apensamento = new RelatorioDocumentoApensar();

            _apensamento.NomeDoTermo = "Termo de Apensamento";
            _apensamento.Interessado = interessado;
            _apensamento.Assunto = assunto;
            _apensamento.Volumes = ObterVolumes(volumes);
            _apensamento.TipoDoTermo = "apensado";
            _apensamento.Codigo = entidade.Codigo;
            _apensamento.Cargo = entidade.CargoAutoridade;
            _apensamento.DataAbertura = entidade.DataApensamento.ToString("d");
            _apensamento.NrProcesso = processo.NumeroProcessoFormatado;
            _apensamento.NrProcessoApensado = ObterProcessoFormatado(entidade.CodigoProcessoApensar);
            _apensamento.UASolicitante = _unidadeAdministrativaRepository.RecuperarPorId(entidade.UaSolicitante).Nome;
            _apensamento.NomeSolicitante = entidade.NomeAutoridade;
            _apensamento.Nome = nomeUsuarioLogado;
            _apensamento.UA = unidade.Nome;
            _apensamento.DataGeracaoPdf = DateTime.Now;
            _apensamento.DataExtenso = DateFormatExtensions.FormataDataPorExtenso(entidade.DataApensamento);

            return _obterPdf.ObterTermoApensamentoBytePDF(_apensamento, localizacaoRDL);

        }

        public byte[] TermoDesapensamento(int id, string localizacaoRDL, string nomeUsuarioLogado, int? IdUaUsuarioLogado)
        {

            var entidade = _documentoApensarRepository.ObterPorId(id);
            var unidade = _unidadeAdministrativaRepository.Obter((int)IdUaUsuarioLogado);
            var processo = ObterProcesso(entidade.CodigoProcesso);
            var processoApensar = ObterProcesso(entidade.CodigoProcessoApensar);
            var documento = _documentoRepository.Obter(processo.IdDocumento);
            var volumes = _documentoVolume.ObterPorDocumento(processoApensar.IdDocumento).ToList();
            var interessado = _obterInteressado.IdentificarInteressantePrincipal(processo.IdDocumento).NomeRazaoSocial;
            var assunto = documento.Descricao;
            var _desapensar = new RelatorioDocumentoApensar();

            _desapensar.NomeDoTermo = "Termo de Desapensamento";
            _desapensar.Interessado = interessado;
            _desapensar.Assunto = assunto;
            _desapensar.Volumes = ObterVolumes(volumes);
            _desapensar.TipoDoTermo = "desapensado";
            _desapensar.Codigo = entidade.Codigo;
            _desapensar.Cargo = entidade.CargoAutoridade;
            _desapensar.DataAbertura = entidade.DataDesapensamento.ToString("d");
            _desapensar.NrProcesso = processo.NumeroProcessoFormatado;
            _desapensar.NrProcessoApensado = ObterProcessoFormatado(entidade.CodigoProcessoApensar);
            _desapensar.UASolicitante = _unidadeAdministrativaRepository.RecuperarPorId(entidade.UaSolicitante).Nome;
            _desapensar.NomeSolicitante = entidade.NomeAutoridade;
            _desapensar.Nome = nomeUsuarioLogado;
            _desapensar.UA = unidade.Nome;
            _desapensar.DataGeracaoPdf = DateTime.Now;            
            _desapensar.DataExtenso = DateFormatExtensions.FormataDataPorExtenso(entidade.DataDesapensamento);

            return _obterPdf.ObterTermoApensamentoBytePDF(_desapensar, localizacaoRDL);
        }

        public string ObterProcessoFormatado(int idProcesso)
        {
            var filtro = new FiltroProcesso();
            filtro.Codigo = idProcesso;
            var processo = _processoRepository.Obter(filtro).FirstOrDefault();
            return processo.NumeroProcessoFormatado;
        }

        public Processo ObterProcesso(int idProcesso)
        {
            var filtro = new FiltroProcesso();
            filtro.Codigo = idProcesso;
            return _processoRepository.Obter(filtro).FirstOrDefault();
        }

        public string ObterVolumes(List<DocumentoVolume> _volumes)
        {
            var resultado = string.Empty;

            _volumes.ForEach(x =>
            {
                resultado += x.NrVolumeDocumento + ", ";               
            });

            return resultado.Remove(resultado.Length - 2);
        }

        private string[] RetornaDocumentosApensado(DocumentoApensar entidade)
        {
            string processoApensado = ObterProcessoFormatado(entidade.CodigoProcessoApensar);
            string processoPrincipal = ObterProcessoFormatado(entidade.CodigoProcesso);

            string[] parametros = { processoApensado, processoPrincipal };

            return parametros;
        }
    }
}
