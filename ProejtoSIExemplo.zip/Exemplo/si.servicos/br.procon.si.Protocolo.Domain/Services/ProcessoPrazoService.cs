﻿using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.ValueObjects;
using System.Collections.Generic;
using System.Linq;

namespace br.procon.si.Protocolo.Domain.Services
{
    public class ProcessoPrazoService : IProcessoPrazoService
    {
        private readonly IProcessoPrazoRepository _processoPrazoRepository;
        private readonly IProcessoRepository _processoRepository;
        private readonly IDocumentoMovimentacaoRepository _documentoMovimentacaoRepository;
        private readonly IPrazoCumprimentoRepository _prazoCumprimentoRepository;

        public ProcessoPrazoService(IProcessoPrazoRepository processoPrazoRepository,
            IProcessoRepository processoRepository,
            IDocumentoMovimentacaoRepository documentoMovimentacaoRepository,
            IPrazoCumprimentoRepository prazoCumprimentoRepository)
        {
            _processoPrazoRepository = processoPrazoRepository;
            _processoRepository = processoRepository;
            _documentoMovimentacaoRepository = documentoMovimentacaoRepository;
            _prazoCumprimentoRepository = prazoCumprimentoRepository;
        }

        public IEnumerable<ProcessoPrazo> Obter()
        {
            var retorno = _processoPrazoRepository.ObterPrazoVencido().ToList();

            if (retorno != null && retorno.Count() > 0)
            {
                var processo = _processoRepository.Obter(new FiltroProcesso()).ToList();
                var docMovimentacao = _documentoMovimentacaoRepository.Obter().ToList();
                var movimento = _documentoMovimentacaoRepository.ObterMovimento();
                var prazoCumprimento = _prazoCumprimentoRepository.Obter().ToList();

                retorno.ForEach(x => x.DefinirProcesso(processo.FirstOrDefault(y => y.Codigo == x.IdProcesso)));
                retorno.ForEach(x => x.DefinirMovimentacao(docMovimentacao.FirstOrDefault(y => y.Codigo == x.IdDocumentoMovimentacao)));
                retorno.ForEach(x => x.DefinirMovimento(movimento.FirstOrDefault(y => y.Codigo == x.Movimentacao.IdMovimento)));
                retorno.ForEach(x => x.DefinirPrazoCumprimeto(prazoCumprimento.FirstOrDefault(y => y.IdPrazoCumprimento == x.IdPrazoCumprimento)));
            }

            return retorno;
        }

        public IEnumerable<ProcessoPrazo> ObterPorProcesso(int idProcesso)
        {
            var retorno = _processoPrazoRepository.ObterPorProcesso(idProcesso);

            if (retorno != null && retorno.Count() > 0)
            {
                var prazoCumprimento = _prazoCumprimentoRepository.Obter().ToList();
                var situacaoProcessoPrazo = _processoPrazoRepository.ObterSituacaoProcessoPrazo();
                retorno.ToList().ForEach(x => x.DefinirPrazoCumprimeto(prazoCumprimento.FirstOrDefault(y => y.IdPrazoCumprimento == x.IdPrazoCumprimento)));
                retorno.ToList().ForEach(x => x.DefinirSituacaoProcessoPrazo(situacaoProcessoPrazo.FirstOrDefault(y => y.Codigo == x.IdSituacaoProcessoPrazo)));
            }
            return retorno;
        }

        public ProcessoPrazo ObterPorId(int id)
        {
            var retorno = _processoPrazoRepository.ObterPorId(id);
            return retorno;
        }

        public IEnumerable<ProcessoPrazo> Obter(FiltroProcessoPrazo filtro)
        {
            var retorno = _processoPrazoRepository.Obter(filtro).ToList();

            if (retorno != null && retorno.Count() > 0)
            {
                var processo = _processoRepository.Obter(new FiltroProcesso()).ToList();
                var docMovimentacao = _documentoMovimentacaoRepository.Obter().ToList();
                var movimento = _documentoMovimentacaoRepository.ObterMovimento();
                var prazoCumprimento = _prazoCumprimentoRepository.Obter().ToList();

                retorno.ForEach(x => x.DefinirProcesso(processo.FirstOrDefault(y => y.Codigo == x.IdProcesso)));
                retorno.ForEach(x => x.DefinirMovimentacao(docMovimentacao.FirstOrDefault(y => y.Codigo == x.IdDocumentoMovimentacao)));
                retorno.ForEach(x => x.DefinirMovimento(movimento.FirstOrDefault(y => y.Codigo == x.Movimentacao.IdMovimento)));
                retorno.ForEach(x => x.DefinirPrazoCumprimeto(prazoCumprimento.FirstOrDefault(y => y.IdPrazoCumprimento == x.IdPrazoCumprimento)));
            }

            return retorno;
        }

        public IEnumerable<PrazoCumprimento> ObterPrazoCumprimento()
        {
            return _prazoCumprimentoRepository.Obter();
        }

        public IEnumerable<SituacaoProcessoPrazo> ObterSituacaoProcessoPrazo()
        {
            return _processoPrazoRepository.ObterSituacaoProcessoPrazo();
        }

        public void Incluir(List<ProcessoPrazo> entidade)
        {
            entidade.ForEach(x => _processoPrazoRepository.Incluir(x));
        }

        public void Alterar(List<ProcessoPrazo> entidade)
        {
            entidade.ForEach(x => _processoPrazoRepository.Alterar(x));
        }

        public void Exlcuir(List<ProcessoPrazo> entidade)
        {
            entidade.ForEach(x => _processoPrazoRepository.Excluir(x.IdProcessoPrazo));
        }

        public ProcessoPrazo Incluir(ProcessoPrazo entidade, int idUsuarioLogado)
        {
            entidade.IdUsuarioOperacao = idUsuarioLogado;
            return _processoPrazoRepository.Incluir(entidade);
        }

        public ProcessoPrazo Alterar(ProcessoPrazo entidade, int idUsuarioLogado)
        {
            entidade.IdUsuarioOperacao = idUsuarioLogado;
            return _processoPrazoRepository.Alterar(entidade);
        }

        public ProcessoPrazo Exlcuir(ProcessoPrazo entidade, int idUsuarioLogado)
        {
            _processoPrazoRepository.Excluir(entidade.IdProcessoPrazo);
            return entidade;
        }

        public List<ProcessoPrazo> ObterPrazoProcessoPorMovimentacao(DocumentoMovimentacao entidade, int idUsuarioLogado)
        {
            var processo = _processoRepository.ObterIdDocumento(entidade.IdDocumento);
            var prazoCumprimento = _prazoCumprimentoRepository.ObterPorMovimentacao(entidade.IdMovimento);
            var processoPrazo = new List<ProcessoPrazo>();

            foreach (var item in prazoCumprimento)
            {
                var filtro = new FiltroProcessoPrazo();
                filtro.IdDocumentoMovimentacao = entidade.Codigo;
                filtro.PrazoCumprimento = item.IdPrazoCumprimento;

                var prazoCadastrado = Obter(filtro).FirstOrDefault();
                var dataPrazo = entidade.DataMovimentacao.AddDays(item.QtdPrazoCumprimento);

                if (prazoCadastrado == null)
                {
                    processoPrazo.Add(new ProcessoPrazo(0, processo.Codigo, dataPrazo, 1, item.IdPrazoCumprimento, entidade.Codigo) { IdUsuarioOperacao = idUsuarioLogado });
                }
                else
                {
                    prazoCadastrado.DefinirDataProcessoPrazo(dataPrazo);
                    prazoCadastrado.IdUsuarioOperacao = idUsuarioLogado;
                    processoPrazo.Add(prazoCadastrado);
                }
            }

            return processoPrazo;
        }

        public void AlterarSituacaoProcessoPrazo(ProcessoPrazo entidade)
        {
            _processoPrazoRepository.AlterarSituacaoProcessoPrazo(entidade);
        }

        public List<DocumentoMovimentacao> ObterDocumentoMovimentacaoPorIdDocumento(int IdDocumento)
        {
            return _documentoMovimentacaoRepository.Obter(IdDocumento).ToList();
        }
    }
}