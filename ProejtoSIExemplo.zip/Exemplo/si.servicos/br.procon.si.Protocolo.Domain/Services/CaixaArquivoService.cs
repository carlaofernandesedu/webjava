﻿using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.Validations;
using System;
using System.Collections.Generic;

namespace br.procon.si.Protocolo.Domain.Services
{
    public class CaixaArquivoService : ICaixaArquivoService
    {
        private readonly ICaixaArquivoRepository _caixaArquivoRepository;

        public CaixaArquivoService(ICaixaArquivoRepository caixaArquivoRepository)
        {
            _caixaArquivoRepository = caixaArquivoRepository;
        }

        public IEnumerable<CaixaArquivo> ObterCaixasArquivosPorCodigoDescricao(string codigo, string descricao, bool? ativo)
        {
            var caixas = _caixaArquivoRepository.ObterPorCodigoDescricao(String.IsNullOrWhiteSpace(codigo) ? null : codigo, String.IsNullOrWhiteSpace(descricao) ? null : descricao, ativo);

            return caixas;
        }

        public CaixaArquivo SalvarCaixaArquivo(CaixaArquivo caixaArquivo)
        {
            var regrasGerais = ValidarSalvarCaixaArquivo(caixaArquivo);

            if (regrasGerais)
            {
                if (caixaArquivo.Id == 0)
                {
                    caixaArquivo.DefinirId(_caixaArquivoRepository.Inserir(caixaArquivo));
                }
                else
                {
                    _caixaArquivoRepository.Atualizar(caixaArquivo);
                }
            }
            return caixaArquivo;
        }

        public CaixaArquivo ExcluirCaixaArquivo(CaixaArquivo caixaArquivo)
        {
            var regrasGerais = ValidarSalvarCaixaArquivo(caixaArquivo);

            if (regrasGerais)
            {
                _caixaArquivoRepository.Excluir(caixaArquivo);
            }
            return caixaArquivo;
        }

        private bool ValidarSalvarCaixaArquivo(CaixaArquivo entidade)
        {
            var validationResult = new CaixaArquivoValidation(_caixaArquivoRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }
    }
}