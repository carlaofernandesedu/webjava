﻿using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.Validations;
using System;
using System.Collections.Generic;
using System.Linq;

namespace br.procon.si.Protocolo.Domain.Services
{
    public class ModeloDocumentoService : IModeloDocumentoService
    {
        private readonly IModeloDocumentoRepository _modeloDocumentoRepository;
        private readonly ISerieDocumentalRepository _serieDocumentalRepository;
        private readonly ISerieDocumentalClassificacaoRepository _serieDocumentalClassificacao;

        public ModeloDocumentoService(IModeloDocumentoRepository modeloDocumentoRepository, ISerieDocumentalRepository serieDocumentalRepository, ISerieDocumentalClassificacaoRepository serieDocumentalClassificacao)
        {
            _modeloDocumentoRepository = modeloDocumentoRepository;
            _serieDocumentalRepository = serieDocumentalRepository;
            _serieDocumentalClassificacao = serieDocumentalClassificacao;
        }

        public ModeloDocumento Incluir(ModeloDocumento entidade)
        {
            
            if(ValidarSerieDocumental(_serieDocumentalRepository, _serieDocumentalClassificacao, ref entidade))
                entidade = _modeloDocumentoRepository.Incluir(entidade);

            return entidade;
        }

        public ModeloDocumento Alterar(ModeloDocumento entidade)
        {
            if (ValidarSerieDocumental(_serieDocumentalRepository, _serieDocumentalClassificacao, ref entidade))
                entidade = _modeloDocumentoRepository.Alterar(entidade);

            return entidade;
        }

        public ModeloDocumento Obter(int idModeloDocumento)
        {
            return _modeloDocumentoRepository.Obter(idModeloDocumento);
        }

        public IEnumerable<ModeloDocumento> Obter()
        {
            return _modeloDocumentoRepository.Obter();
        }

        private bool ValidarSerieDocumental(ISerieDocumentalRepository serieDocumentalRepository, ISerieDocumentalClassificacaoRepository serieDocumentalClassificacao, ref ModeloDocumento entidade)
        {
            var validationResult = new ModeloDocumentoValidation(serieDocumentalRepository, serieDocumentalClassificacao).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }
    }
}
