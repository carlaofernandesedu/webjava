﻿using br.procon.si.Core.Domain.ValueObjects;
using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Infra;
using br.procon.si.Protocolo.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.Validations;
using br.procon.si.Protocolo.Domain.ValueObjects;
using br.procon.si.Protocolo.Domain.ValueObjects.Enums;
using System;
using System.Collections.Generic;
using System.Linq;

namespace br.procon.si.Protocolo.Domain.Services
{
    public class DocumentoVolumeService : IDocumentoVolumeService
    {
        private readonly IDocumentoRepository _documentoRepository;
        private readonly IProcessoRepository _processoRepository;
        private readonly IDocumentoVolumeRepository _documentoVolumeRepository;
        private readonly IUnidadeAdministrativaRepository _unidadeAdministrativaRepository;
        private readonly IRelatorioProtocolo _obterTermoEncerramentoInfra;
        private readonly IIdentificarParteInteressadaRepository _obterInteressado;
        private readonly IDocumentoMovimentacaoService _documentoMovimentacaoService;
        private readonly IDocumentoJuntadaRepository _documentoJuntadaRepository;
        private readonly IDocumentoIncorporacaoRepository _documentoIncorporacaoRepository;
        private readonly IDocumentoMovimentacaoRepository _documentoMovimentacaoRepository;

        public DocumentoVolumeService(IDocumentoRepository documentoRepository,
            IDocumentoVolumeRepository documentoVolumeRepository,
            IProcessoRepository processoRepository,
            IUnidadeAdministrativaRepository unidadeAdministrativaRepository,
            IRelatorioProtocolo obterTermoEncerramentoInfra,
            IIdentificarParteInteressadaRepository obterInteressado,
            IDocumentoMovimentacaoService documentoMovimentacaoService,
            IDocumentoJuntadaRepository documentoJuntadaRepository,
            IDocumentoIncorporacaoRepository documentoIncorporacaoRepository,
            IDocumentoMovimentacaoRepository documentoMovimentacaoRepository
        )
        {
            _documentoRepository = documentoRepository;
            _documentoVolumeRepository = documentoVolumeRepository;
            _unidadeAdministrativaRepository = unidadeAdministrativaRepository;
            _obterTermoEncerramentoInfra = obterTermoEncerramentoInfra;
            _processoRepository = processoRepository;
            _obterInteressado = obterInteressado;
            _documentoMovimentacaoService = documentoMovimentacaoService;
            _documentoJuntadaRepository = documentoJuntadaRepository;
            _documentoIncorporacaoRepository = documentoIncorporacaoRepository;
            _documentoMovimentacaoRepository = documentoMovimentacaoRepository;
        }

        public DocumentoVolumeService(IDocumentoVolumeRepository documentoVolume)
        {
            _documentoVolumeRepository = documentoVolume;
        }

        public DocumentoVolume ObterPorId(int idVolume)
        {
            return _documentoVolumeRepository.ObterPorId(idVolume);
        }

        public IEnumerable<DocumentoVolume> Obter(int idDocumento)
        {
            return _documentoVolumeRepository.ObterPorDocumento(idDocumento);
        }

        public IEnumerable<DocumentoVolume> ObterPorProcessoProtocolo(FiltroProcesso filtro)
        {
            return _documentoVolumeRepository.ObterPorProcessoProtocolo(filtro);
        }

        public DocumentoVolume Incluir(DocumentoVolume entidade, int idUsuarioLogado, int? idUaUsuarioLogado)
        {
            var validarRegrasGerais = ValidarRegrasGerais(entidade.IdDocumento, idUsuarioLogado, ref entidade);
            var validarUaPosse = ValidarSeUaPossuiAcessoProtocolo(_documentoRepository, _unidadeAdministrativaRepository, idUsuarioLogado, ref entidade);

            if (validarRegrasGerais && validarUaPosse)
            {
                entidade.DefinirDataEncerramentoVolume(entidade.DataAberturaVolume);

                _documentoVolumeRepository.FecharVolume(entidade.IdUsuarioCriacao, entidade.IdDocumento, entidade.NrUltimaFolha, entidade.DataEncerramentoVolume);

                var volume = _documentoVolumeRepository.ObterPorDocumento(entidade.IdDocumento).LastOrDefault();

                if (volume == null)
                {
                    var unidadeUsuarioLogado = _unidadeAdministrativaRepository.BuscaUnidadeAdiministrativaDoUsuarioLogado(idUsuarioLogado);
                    var obj = _documentoRepository.Obter(entidade.IdDocumento);

                    var novoVolume = new DocumentoVolume(obj.IdDocumento, 0, 0, DateTime.Now, DateTime.MinValue, DateTime.Now, idUsuarioLogado, (int)EnumSituacaoVolume.Andamento, unidadeUsuarioLogado.Nome);

                    _documentoVolumeRepository.Incluir(novoVolume);
                    _documentoVolumeRepository.FecharVolume(entidade.IdUsuarioCriacao, novoVolume.IdDocumento, entidade.NrUltimaFolha, entidade.DataEncerramentoVolume);
                }

                entidade.CodigoPdfEncerramento = _documentoVolumeRepository.ObterPorDocumento(entidade.IdDocumento).LastOrDefault().Codigo;
                entidade.CodigoPdfAbertura = _documentoVolumeRepository.Incluir(entidade).Codigo;

                _documentoVolumeRepository.AtualizarQtdeVolumesDocumento(entidade.IdDocumento, idUsuarioLogado);
                GerarMovimentacao(entidade.IdDocumento, idUsuarioLogado, "Volume incluido com sucesso");
            }

            return entidade;
        }

        public DocumentoVolume IncluirVolumeDocumentoSimples(DocumentoVolume entidade, int idUsuarioLogado, int? idUaUsuarioLogado)
        {
            var validarRestricaoRegrasGerais = ValidarRegrasGerais(entidade.IdDocumento, idUsuarioLogado, ref entidade);
            var validarUaPosse = ValidarSeUaPossuiAcessoProtocolo(_documentoRepository, _unidadeAdministrativaRepository, idUsuarioLogado, ref entidade);

            if (validarUaPosse)
            {
                _documentoVolumeRepository.Incluir(entidade);
                _documentoVolumeRepository.AtualizarQtdeVolumesDocumento(entidade.IdDocumento, idUsuarioLogado);
            }

            return entidade;
        }

        public int FecharVolume(int idUsuarioLogado, int idDocumento, decimal nrUltimaFolha, DateTime dtEncerramentoVolume)
        {
            _documentoVolumeRepository.FecharVolume(idUsuarioLogado, idDocumento, nrUltimaFolha, dtEncerramentoVolume);
            return _documentoVolumeRepository.ObterPorDocumento(idDocumento).LastOrDefault().Codigo;
        }

        public byte[] TermosDoVolume(int id, string localizacaoRDL, string nomeUsuarioLogado, int? IdUaUsuarioLogado, string cargoFuncionario, string nomeSolicitante, string cargoSolicitante)
        {
            var entidade = _documentoVolumeRepository.ObterPorId(id);
            var volumeAnterior = new DocumentoVolume();

            if (entidade.NrVolumeDocumento > 1)
                volumeAnterior = _documentoVolumeRepository.ObterPorDocumento(entidade.IdDocumento).Where(x => x.NrVolumeDocumento.Equals(entidade.NrVolumeDocumento - 1)).FirstOrDefault();

            var interresado = _obterInteressado.IdentificarInteressantePrincipal(entidade.IdDocumento).NomeRazaoSocial;
            var assunto = _documentoRepository.Obter(entidade.IdDocumento).Descricao;

            var unidade = _unidadeAdministrativaRepository.Obter((int)IdUaUsuarioLogado);

            var termoEncerramento = new RelatorioDocumentoVolume();
            termoEncerramento.Codigo = entidade.Codigo;
            termoEncerramento.NrVolumeDocumento = entidade.NrVolumeDocumento;
            termoEncerramento.NomeSolicitante = nomeSolicitante ?? entidade.NomeSolicitante;
            termoEncerramento.UASolicitante = entidade.UnidadeAdminidtrativa;
            termoEncerramento.Cargo = cargoSolicitante ?? entidade.Cargo;
            termoEncerramento.DataAberturaVolume = entidade.DataAberturaVolume;
            termoEncerramento.DataEncerramentoVolume = entidade.DataEncerramentoVolume;
            termoEncerramento.NrProcesso = ObterProcesso(entidade.IdDocumento).NumeroProcessoFormatado;
            termoEncerramento.Nome = nomeUsuarioLogado;
            termoEncerramento.UA = unidade.Nome;
            termoEncerramento.DataGeracaoPdf = DateTime.Now;
            termoEncerramento.NrUltimaFolha = entidade.NrUltimaFolha;
            termoEncerramento.NrUltimaFolhaVolumeAnterior = volumeAnterior.NrUltimaFolha + 2;
            termoEncerramento.CargoFuncionario = cargoFuncionario ?? entidade.CargoFuncionario;
            termoEncerramento.Interessado = interresado;
            termoEncerramento.Assunto = assunto;
            termoEncerramento.DataExtensoAbertura = DateFormatExtensions.FormataDataPorExtenso(entidade.DataAberturaVolume);
            termoEncerramento.DataExtensoEncerramento = DateFormatExtensions.FormataDataPorExtenso(entidade.DataEncerramentoVolume);

            return _obterTermoEncerramentoInfra.ObterTermoEncerramentoBytePDF(termoEncerramento, localizacaoRDL);
        }

        public byte[] FolhaLider(int id, string localizacaoRDL, int idUsuario, int idUsuarioUA)
        {
            var entidade = _documentoVolumeRepository.ObterPorId(id);
            var processo = ObterProcesso(entidade.IdDocumento);

            var parametrosFolhaLider = new FolhaLiderDocumentoVolume();
            var retornoFolhaLider = new FolhaLiderDocumentoVolume();

            parametrosFolhaLider.nr_seq_processo = processo.NrSequencial;
            parametrosFolhaLider.nr_ano_processo = processo.Ano;
            parametrosFolhaLider.cd_competencia_processo = processo.CodigoCompetencia;
            parametrosFolhaLider.id_usuario = idUsuario;
            parametrosFolhaLider.id_ua = idUsuarioUA;

            retornoFolhaLider = _documentoVolumeRepository.GerarFolhaLiderDocumentoVolume(parametrosFolhaLider);
            retornoFolhaLider.NumeroVolume = entidade.NrVolumeDocumento;

            return _obterTermoEncerramentoInfra.ObterFolhaLiderBytePDF(retornoFolhaLider, localizacaoRDL);
        }

        public Processo ObterProcesso(int idDocumento)
        {
            return _processoRepository.ObterIdDocumento(idDocumento);
        }

        public DocumentoVolume Alterar(DocumentoVolume entidade, int idUsuarioLogado, int? idUaUsuarioLogado)
        {
            var validarUaPosse = ValidarSeUaPossuiAcessoProtocolo(_documentoRepository, _unidadeAdministrativaRepository, idUsuarioLogado, ref entidade);
            var validarDataAberturaPrimeiroVolume = ValidarDataAberturaPrimeiroVolume(ref entidade);

            if (validarUaPosse && validarDataAberturaPrimeiroVolume)
            {
                _documentoVolumeRepository.Alterar(entidade);
            }
            return entidade;
        }

        public DocumentoVolume Excluir(DocumentoVolume entidade, int idUsuarioLogado, int? idUaUsuarioLogado)
        {
            var validarRegrasGerais = ValidarRegrasGerais(entidade.IdDocumento, idUsuarioLogado, ref entidade);
            var validarUaPosse = ValidarSeUaPossuiAcessoProtocolo(_documentoRepository, _unidadeAdministrativaRepository, idUsuarioLogado, ref entidade);
            var validarExclusaoVolumeAtual = ValidarExcluirDocumentoVolume(idUsuarioLogado, ref entidade);
            var validarExistenciaJuntadaIncorporadoVolumeAtual = ValidarExisteJuntadaIncorporadoVolumeAtual(ref entidade);

            if (validarRegrasGerais && validarUaPosse && validarExclusaoVolumeAtual && validarExistenciaJuntadaIncorporadoVolumeAtual)
            {
                var idVolume = _documentoVolumeRepository.ObterPorDocumento(entidade.IdDocumento).LastOrDefault().Codigo;
                _documentoVolumeRepository.Excluir(idVolume);

                _documentoVolumeRepository.AtualizarQtdeVolumesDocumento(entidade.IdDocumento, idUsuarioLogado);

                GerarMovimentacao(entidade.IdDocumento, idUsuarioLogado, "Volume excluido com sucesso");
            }

            return entidade;
        }

        public IEnumerable<DocumentoVolume> Obter()
        {
            throw new System.NotImplementedException();
        }

        private void GerarMovimentacao(int idDocumento, int idUsuarioLogado, string descricao)
        {
            var movimentacao = DocumentoMovimentacao.DocumentoMovimentacaoFactory.RegistrarMovimentacaoAutomatica(idDocumento, DateTime.Now, descricao, false, (int)EnumTipoMovimento.Volume, idUsuarioLogado);
            _documentoMovimentacaoRepository.IncluirAutomatica(movimentacao);
        }

        public bool ValidarRegrasGerais(int idDocumentoPai, int idUsuarioLogado, ref DocumentoVolume entidade)
        {
            var validationResult = _documentoMovimentacaoService.ValidarRegrasRestricaoMovimentacao(idDocumentoPai, 0, idUsuarioLogado);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public bool ValidarSeUaPossuiAcessoProtocolo(IDocumentoRepository documentoRepository, IUnidadeAdministrativaRepository unidadeAdministrativaRepository, int idUsuarioLogado, ref DocumentoVolume entidade)
        {
            var validationResult = new DocumentoVolumeValidation(documentoRepository, unidadeAdministrativaRepository, idUsuarioLogado).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public bool ValidarDataAberturaPrimeiroVolume(ref DocumentoVolume entidade)
        {
            var validationResult = new DocumentoVolumeValidation(_documentoVolumeRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public bool ValidarExcluirDocumentoVolume(int idUaUsuarioLogado, ref DocumentoVolume entidade)
        {
            var validationResult = new DocumentoVolumeValidation(_documentoVolumeRepository, _documentoRepository, _unidadeAdministrativaRepository, idUaUsuarioLogado).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private bool ValidarExisteJuntadaIncorporadoVolumeAtual(ref DocumentoVolume entidade)
        {
            var validationResult = new DocumentoVolumeValidation(_documentoVolumeRepository, _documentoRepository, _documentoIncorporacaoRepository, _documentoJuntadaRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }
    }
}