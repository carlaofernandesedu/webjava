﻿using br.procon.si.Core.Infra;
using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.Validations;
using br.procon.si.Protocolo.Domain.ValueObjects;
using System.Collections.Generic;
using System.Linq;

namespace br.procon.si.Protocolo.Domain.Services
{
    public class ProcessoService : IProcessoService
    {
        private readonly IProcessoRepository _processoRepository;
        private readonly IDocumentoRepository _documentoRepository;
        private readonly IUnidadeAdministrativaRepository _unidadeAdministrativaRepository;
        private readonly ISerieDocumentalRepository _serieDocumentalRepository;
        private readonly IDocumentoParteRepository _documentoParteRepository;
        private readonly ISituacaoProcessoRepository _situacaoRepository;
        private readonly ICompetenciaProcessoRepository _competenciaProcessoRepository;
        private readonly IDocumentoMovimentacaoService _documentoMovimentacaoService;

        public ProcessoService(IProcessoRepository processoRepository,
            IDocumentoRepository documentoRepository,
            IUnidadeAdministrativaRepository unidadeAdministrativaRepository,
            ISerieDocumentalRepository serieDocumentalRepository,
            IDocumentoParteRepository iDocumentoParteRepository,
            ISituacaoProcessoRepository situacaoProcessoRepository,
            ICompetenciaProcessoRepository competenciaProcessoRepository,
            IDocumentoMovimentacaoService documentoMovimentacaoService)
        {
            _processoRepository = processoRepository;
            _documentoRepository = documentoRepository;
            _unidadeAdministrativaRepository = unidadeAdministrativaRepository;
            _serieDocumentalRepository = serieDocumentalRepository;
            _documentoParteRepository = iDocumentoParteRepository;
            _situacaoRepository = situacaoProcessoRepository;
            _competenciaProcessoRepository = competenciaProcessoRepository;
            _documentoMovimentacaoService = documentoMovimentacaoService;
        }

        public IEnumerable<Processo> Obter(FiltroProcesso filtro, int idUsuarioLogado)
        {
            if (filtro.DataFinal.HasValue)
                filtro.DataFinal = filtro.DataFinal.Value.AddHours(23).AddMinutes(59).AddSeconds(59);

            var retorno = _processoRepository.Obter(filtro).ToList();

            retorno.ForEach(x => x.Protocolo = new Documento());

            retorno.ForEach(x => x.SituacaoProcesso = _situacaoRepository.Obter(x.Situacao));
            retorno.ForEach(x => x.CompetenciaProcesso = _competenciaProcessoRepository.Obter(x.CodigoCompetencia));
            retorno.ForEach(x => x.Protocolo = _documentoRepository.Obter(x.IdDocumento));
            retorno.ForEach(x => x.Protocolo.DocumentoParte = _documentoParteRepository.Obter(x.IdDocumento).ToList().FirstOrDefault(j => j.Principal.Equals(true)));
            retorno.ForEach(x => x.Protocolo.SerieDocumental = _serieDocumentalRepository.Obter(x.Protocolo.IdSerieDocumental));
            retorno.ForEach(x => x.Protocolo.UnidadeAdministrativa = _unidadeAdministrativaRepository.Obter(x.Protocolo.IdUA));

            return retorno;
        }

        public Processo ObterFiltro(FiltroProcesso filtro, int idUsuarioLogado)
        {
            var retorno = _processoRepository.ObterFiltro(filtro);

            if (retorno != null)
            {
                retorno.Protocolo = new Documento();

                retorno.SituacaoProcesso = _situacaoRepository.Obter(retorno.Situacao);
                retorno.CompetenciaProcesso = _competenciaProcessoRepository.Obter(retorno.CodigoCompetencia);
                retorno.Protocolo = _documentoRepository.Obter(retorno.IdDocumento);
                retorno.Protocolo.DocumentoParte = _documentoParteRepository.Obter(retorno.IdDocumento).ToList().FirstOrDefault(x => x.Principal.Equals(true));
                retorno.Protocolo.SerieDocumental = _serieDocumentalRepository.Obter(retorno.Protocolo.IdSerieDocumental);
                retorno.Protocolo.UnidadeAdministrativa = _unidadeAdministrativaRepository.Obter(retorno.Protocolo.IdUA);

                var uaProtocolo = ValidarUaProtocolo(ref retorno, _unidadeAdministrativaRepository, idUsuarioLogado);
                var posseUaUsuarioLogado = ValidarPosseUaUsuarioLogado(ref retorno, _documentoRepository, _unidadeAdministrativaRepository, idUsuarioLogado);

                if (uaProtocolo || posseUaUsuarioLogado)
                    return retorno;
            }

            return retorno;
        }

        public Processo ObterPorIdDocumento(int idDocumento, int idUsuarioLogado)
        {
            var retorno = _processoRepository.ObterIdDocumento(idDocumento);

            if (retorno == null) return retorno;

            retorno.Protocolo = _documentoRepository.Obter(retorno.IdDocumento);
            retorno.Protocolo.SerieDocumental = _serieDocumentalRepository.Obter(retorno.Protocolo.IdSerieDocumental);
            retorno.Protocolo.UnidadeAdministrativa = _unidadeAdministrativaRepository.Obter(retorno.Protocolo.IdUA);
            retorno.Protocolo.DocumentoParte = _documentoParteRepository.Obter(retorno.IdDocumento).ToList().FirstOrDefault(x => x.Principal.Equals(true));
            retorno.SituacaoProcesso = _situacaoRepository.Obter(retorno.Situacao);
            retorno.CompetenciaProcesso = _competenciaProcessoRepository.Obter(retorno.CodigoCompetencia);

            var uaProtocolo = ValidarUaProtocolo(ref retorno, _unidadeAdministrativaRepository, idUsuarioLogado);
            var posseUaUsuarioLogado = ValidarPosseUaUsuarioLogado(ref retorno, _documentoRepository, _unidadeAdministrativaRepository, idUsuarioLogado);

            // Todo: Aplicar regra de sigilo quando implementar tela de Solicitação de Autuação
            var documentoSigiloso = ValidarPosseUaUsuarioLogado(ref retorno, _documentoRepository, _unidadeAdministrativaRepository, idUsuarioLogado);

            if (uaProtocolo || posseUaUsuarioLogado)
                return retorno;

            return retorno;
        }

        public Processo Atualizar(Processo obj, int idUsuarioLogado)
        {
            obj.Protocolo = new Documento();
            obj.Protocolo = _documentoRepository.Obter(obj.IdDocumento);
            obj.Protocolo.UnidadeAdministrativa = _unidadeAdministrativaRepository.Obter(obj.Protocolo.IdUA);

            var regrasGerais = ValidarRegrasRestricaoMovimentacao(obj.IdDocumento, idUsuarioLogado, ref obj);
            var uaProtocolo = ValidarUaProtocolo(ref obj, _unidadeAdministrativaRepository, idUsuarioLogado);
            var posseUaUsuarioLogado = ValidarPosseUaUsuarioLogado(ref obj, _documentoRepository, _unidadeAdministrativaRepository, idUsuarioLogado);
            var uaProdutoraUsuarioLogado = ValidarUaProdutoraUsuario(ref obj, _documentoRepository, _unidadeAdministrativaRepository, idUsuarioLogado);

            if (regrasGerais && uaProtocolo && posseUaUsuarioLogado && uaProdutoraUsuarioLogado)
            {
                obj.Codigo = _processoRepository.Atualizar(obj);
                var doc = _documentoRepository.Obter(obj.IdDocumento);

                var serieDoc = _serieDocumentalRepository.Obter(doc.IdSerieDocumental);

                if (serieDoc != null)
                {
                    doc.IdUsuarioOperacao = idUsuarioLogado;

                    if (serieDoc.IdTipoPrazoGuardaProdutora == 3)
                    {
                        doc.DataAprovacaoConta = obj.DataAprovacaoConta;
                    }
                    else
                    {
                        doc.DataAprovacaoConta = null;
                    }
                    _documentoRepository.Alterar(doc);
                }

                return obj;
            }

            return obj;
        }

        public bool ValidarRegrasRestricaoMovimentacao(int idDocumento, int idUsuarioLogado, ref Processo entidade)
        {
            var validationResult = _documentoMovimentacaoService.ValidarRegrasRestricaoMovimentacao(idDocumento, 0, idUsuarioLogado);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private bool ValidarUaProtocolo(ref Processo entity, IUnidadeAdministrativaRepository unidadeAdministrativaRepository, int idUsuarioLogado)
        {
            var validationResult = new ProcessoValidation(unidadeAdministrativaRepository, idUsuarioLogado).Valid(entity);

            foreach (var validationResultError in validationResult.Errors)
            {
                entity.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private bool ValidarPosseUaUsuarioLogado(ref Processo entity, IDocumentoRepository documentoRepository, IUnidadeAdministrativaRepository unidadeAdministrativaRepository, int idUsuarioLogado)
        {
            var validationResult = new ProcessoValidation(documentoRepository, unidadeAdministrativaRepository, idUsuarioLogado).Valid(entity);

            foreach (var validationResultError in validationResult.Errors)
            {
                entity.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private bool ValidarDocumentoSigiloso(ref Processo entity, IDocumentoRepository documentoRepository, IUnidadeAdministrativaRepository unidadeAdministrativaRepository, int idUsuarioLogado)
        {
            var validationResult = new ProcessoValidation(documentoRepository, unidadeAdministrativaRepository, idUsuarioLogado).Valid(entity);

            foreach (var validationResultError in validationResult.Errors)
            {
                entity.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private bool ValidarUaProdutoraUsuario(ref Processo entity, IDocumentoRepository documentoRepository, IUnidadeAdministrativaRepository unidadeAdministrativaRepository, int idUsuarioLogado)
        {
            var validationResult = new ProcessoEditarDadosValidation(documentoRepository, unidadeAdministrativaRepository, idUsuarioLogado).Valid(entity);

            foreach (var validationResultError in validationResult.Errors)
            {
                entity.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public IEnumerable<SituacaoProcesso> ObterSituacao()
        {
            return _situacaoRepository.Obter();
        }

        public IEnumerable<CompetenciaProcesso> ObterCompetencia()
        {
            return _competenciaProcessoRepository.Obter();
        }

        public ResultadoPaginado<ProcessoListaVO> Obter(FiltroProcesso filtro)
        {
            var resultado = _processoRepository.ObterPaginado(filtro);

            return resultado;
        }
    }
}