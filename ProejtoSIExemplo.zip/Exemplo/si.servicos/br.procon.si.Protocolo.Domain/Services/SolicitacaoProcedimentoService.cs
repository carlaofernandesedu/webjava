﻿using System.Collections.Generic;
using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.Validations;
using br.procon.si.Protocolo.Domain.ValueObjects;
using System;
using System.Linq;
using br.procon.si.Protocolo.Domain.ValueObjects.Enums;

namespace br.procon.si.Protocolo.Domain.Services
{
    public class SolicitacaoProcedimentoService : ISolicitacaoProcedimentoService
    {
        private readonly ISolicitacaoProcedimentoRepository _solicitacaoProcedimentoRepository;
        private readonly IUnidadeAdministrativaRepository _unidadeAdministrativaRepository;
        private readonly IDocumentoRepository _documentoRepository;
        private readonly IProcessoRepository _processoRepository;
        private readonly IDocumentoParteRepository _documentoParteRepository;
        private readonly ISerieDocumentalRepository _serieDocumentalRepository;
        private readonly IDocumentoDestinoRepository _documentoDestinoRepository;

        public SolicitacaoProcedimentoService(ISolicitacaoProcedimentoRepository solicitacaoProcedimentoRepository, IUnidadeAdministrativaRepository unidadeAdministrativaRepository, IDocumentoRepository documentoRepository, IProcessoRepository processoRepository, IDocumentoParteRepository documentoParteRepository, ISerieDocumentalRepository serieDocumentalRepository, IDocumentoDestinoRepository documentoDestinoRepository)
        {
            _solicitacaoProcedimentoRepository = solicitacaoProcedimentoRepository;
            _unidadeAdministrativaRepository = unidadeAdministrativaRepository;
            _documentoRepository = documentoRepository;
            _processoRepository = processoRepository;
            _documentoParteRepository = documentoParteRepository;
            _serieDocumentalRepository = serieDocumentalRepository;
            _documentoDestinoRepository = documentoDestinoRepository;
        }

        public IEnumerable<SolicitacaoProcedimento> Obter(FiltroSolicitacaoProcedimento entidade, int idUsuarioLogado)
        {
            UnidadeAdministrativa ua = _unidadeAdministrativaRepository.ObterUADoUsuarioLogado(idUsuarioLogado);
            var obj = _solicitacaoProcedimentoRepository.Obter(entidade);
            List<SolicitacaoProcedimento> retorno = new List<SolicitacaoProcedimento>();
            obj.ToList().ForEach(x =>
            {
                if (x.IdUASolicitante == ua.IdUA || x.IdUAProtocolo == ua.IdUA)
                {
                    x.DefinirNomeUASolicitante(_unidadeAdministrativaRepository.Obter(x.IdUASolicitante).Nome);
                    
                    var processo = _processoRepository.ObterIdDocumento(x.IdDocumento);
                    if (processo != null)
                        x.DefinirNrProcessoFormatado(processo.NumeroProcessoFormatado);

                    var documento = _documentoRepository.Obter(x.IdDocumento);
                    if (documento != null)
                        x.DefinirAssunto(documento.Descricao);
                    SolicitacaoProcedimento t = new SolicitacaoProcedimento();
                    t = x;
                    retorno.Add(t);
                }
            });
            return retorno;
        }

        public IEnumerable<SolicitacaoProcedimento> ObterPorUsuario(int idUsuarioLogado)
        {
            var unidadeAdm = _unidadeAdministrativaRepository.ObterUADoUsuarioLogado(idUsuarioLogado);
            var verificarAtribuicaoProtocolo = VerificarAtribuicaoProtocolo(unidadeAdm);

            var retorno = verificarAtribuicaoProtocolo ? _solicitacaoProcedimentoRepository.ObterPorUsuario(null, unidadeAdm.IdUA).ToList() : _solicitacaoProcedimentoRepository.ObterPorUsuario(unidadeAdm.IdUA, null).ToList();

            var listaSolicitacaoProcedimento = retorno.Where(x => x.IdSituacaoSolicitacao.Equals((int)EnumSituacaoSolicitacao.Aberta)).ToList();

            listaSolicitacaoProcedimento.ToList().ForEach(x =>
            {
                x.DefinirNomeUASolicitante(_unidadeAdministrativaRepository.Obter(x.IdUASolicitante).Nome);

                var processo = _processoRepository.ObterIdDocumento(x.IdDocumento);
                if (processo != null)
                    x.DefinirNrProcessoFormatado(processo.NumeroProcessoFormatado);

                var documento = _documentoRepository.Obter(x.IdDocumento);
                if(documento != null)
                    x.DefinirAssunto(documento.Descricao);
            });

            return listaSolicitacaoProcedimento;
        }

        public IEnumerable<SituacaoSolicitacao> ObterSituacaoSolicitacao(int? idSitucaoSolicitacao)
        {
            return _solicitacaoProcedimentoRepository.ObterSituacaoSolicitacao(idSitucaoSolicitacao);
        }

        public SolicitacaoProcedimento Obter(int idSolicitacaoProcedimento)
        {
            var entidade = _solicitacaoProcedimentoRepository.Obter(idSolicitacaoProcedimento);

            var documento = _documentoRepository.Obter(entidade.IdDocumento);
            entidade.DefinirNrProtocoloFormatado(documento.DocumentoFormatado);
            entidade.DefinirSerieDocumental(_serieDocumentalRepository.Obter(documento.IdSerieDocumental).Descricao);
            entidade.DefinirInteressado(_documentoParteRepository.Obter(entidade.IdDocumento).Where(x => x.Principal.Equals(true)).FirstOrDefault().Nome);
            entidade.DefinirAssunto(documento.Descricao);

            if (entidade.IdDocumentoSecundario > 0)
            {
                var documentoSec = _documentoRepository.Obter(Convert.ToInt32(entidade.IdDocumentoSecundario));
                entidade.DefinirNrProtocoloFormatadoSec(documentoSec.DocumentoFormatado);
                entidade.DefinirSerieDocumentalSec(_serieDocumentalRepository.Obter(documentoSec.IdSerieDocumental).Descricao);
                entidade.DefinirInteressadoSec(_documentoParteRepository.Obter(Convert.ToInt32(entidade.IdDocumentoSecundario)).Where(x => x.Principal.Equals(true)).FirstOrDefault().Nome);
                entidade.DefinirAssuntoSec(documentoSec.Descricao);
            }

            return entidade;
        }

        public SolicitacaoProcedimento Incluir(SolicitacaoProcedimento entidade)
        {
            entidade.DefinirUASolicitante((short)_unidadeAdministrativaRepository.ObterUADoUsuarioLogado(entidade.IdUsuarioOperacao).IdUA);

            var validarInsercaoProcedimento = ValidarInsercaoProcedimento(_solicitacaoProcedimentoRepository, _unidadeAdministrativaRepository, _documentoRepository, _documentoDestinoRepository, ref entidade);
            var validarSeDocumentoExisteDocumentoDestino = ValidarSeDocumentoExisteDocumentoDestino(_documentoDestinoRepository, ref entidade);
            
            if (!validarInsercaoProcedimento) return entidade;

            entidade = _solicitacaoProcedimentoRepository.Incluir(entidade);

            if (!validarSeDocumentoExisteDocumentoDestino) return entidade;

            _documentoDestinoRepository.Incluir(new DocumentoDestino(0, entidade.IdDocumento, Convert.ToByte(entidade.IdUASolicitante), Convert.ToByte(entidade.IdUAProtocolo)));
            if (entidade.IdDocumentoSecundario > 0)
                _documentoDestinoRepository.Incluir(new DocumentoDestino(0, Convert.ToInt32(entidade.IdDocumentoSecundario), Convert.ToByte(entidade.IdUASolicitante), Convert.ToByte(entidade.IdUAProtocolo)));
            return entidade;
        }

        public SolicitacaoProcedimento Alterar(SolicitacaoProcedimento entidade)
        {
            entidade.DefinirUASolicitante((short)_unidadeAdministrativaRepository.ObterUADoUsuarioLogado(entidade.IdUsuarioOperacao).IdUA);

            if (ValidarAlteracaoProcedimento(_solicitacaoProcedimentoRepository, _unidadeAdministrativaRepository, _documentoRepository, ref entidade))
            {
                entidade = _solicitacaoProcedimentoRepository.Alterar(entidade);
            }

            return entidade;
        }

        public bool AlterarSituacaoProcedimento(SolicitacaoProcedimento entidade)
        {
            var retorno = false;

            var validarAlteracaoSituacao = ValidarAlterarSituacaoProcedimento(_solicitacaoProcedimentoRepository, _documentoDestinoRepository, _unidadeAdministrativaRepository, ref entidade);

            if (validarAlteracaoSituacao)
            {
                retorno = Convert.ToBoolean(_solicitacaoProcedimentoRepository.AlterarSituacaoProcedimento(entidade));
            }

            return retorno;
        }

        private static bool ValidarInsercaoProcedimento(ISolicitacaoProcedimentoRepository solicitacaoProcedimentoRepository, IUnidadeAdministrativaRepository unidadeAdministrativaRepository, IDocumentoRepository documentoRepository, IDocumentoDestinoRepository documentoDestinoRepository, ref SolicitacaoProcedimento entidade)
        {
            var validationResult = new SolicitacaoProcedimentoInserirValidation(solicitacaoProcedimentoRepository, unidadeAdministrativaRepository, documentoRepository, documentoDestinoRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private static bool ValidarAlteracaoProcedimento(ISolicitacaoProcedimentoRepository solicitacaoProcedimentoRepository, IUnidadeAdministrativaRepository unidadeAdministrativaRepository, IDocumentoRepository documentoRepository, ref SolicitacaoProcedimento entidade)
        {
            var validationResult = new SolicitacaoProcedimentoAlterarValidation(solicitacaoProcedimentoRepository, unidadeAdministrativaRepository, documentoRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private static bool ValidarAlterarSituacaoProcedimento(ISolicitacaoProcedimentoRepository solicitacaoProcedimentoRepository, IDocumentoDestinoRepository documentoDestinoRepository, IUnidadeAdministrativaRepository unidadeAdministrativaRepository, ref SolicitacaoProcedimento entidade)
        {
            var validationResult = new SolicitacaoProcedimentoAlterarSituacaoValidation(solicitacaoProcedimentoRepository, documentoDestinoRepository, unidadeAdministrativaRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private static bool VerificarAtribuicaoProtocolo(UnidadeAdministrativa unidadeAdministrativa)
        {
            return unidadeAdministrativa.Protocolo && unidadeAdministrativa.Ativo;
        }

        private static bool ValidarSeDocumentoExisteDocumentoDestino(IDocumentoDestinoRepository documentoDestinoRepository, ref SolicitacaoProcedimento entidade)
        {
            var validationResult = new SolicitacaoProcedimentoInserirValidation(documentoDestinoRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }
    }
}
