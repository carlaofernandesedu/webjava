﻿using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.ValueObjects;

namespace br.procon.si.Protocolo.Domain.Services
{
    public class PrazoCumprimentoService : IPrazoCumprimentoService
    {
        private readonly IPrazoCumprimentoRepository _PrazoRepository;

        public PrazoCumprimentoService(IPrazoCumprimentoRepository PrazoRepository)
        {
            _PrazoRepository = PrazoRepository;
        }

        public List<PrazoCumprimento> Obter()
        {
            return _PrazoRepository.Obter().ToList();
        }

        public PrazoCumprimento Obter(int idPrazo)
        {
            return _PrazoRepository.Obter(idPrazo);
        }

        public PrazoCumprimento Incluir(PrazoCumprimento entidade)
        {
            return _PrazoRepository.Incluir(entidade);
        }

        public PrazoCumprimento Alterar(PrazoCumprimento entidade)
        {
            return _PrazoRepository.Alterar(entidade);
        }

        public PrazoCumprimento Exlcuir(PrazoCumprimento idProcessoPrazo)
        {
            return _PrazoRepository.Exlcuir(idProcessoPrazo);
        }

        public PrazoCumprimento AlterarSituacaoPrazoCumprimento(PrazoCumprimento entidade)
        {
            return _PrazoRepository.AlterarSituacaoPrazoCumprimento(entidade);
        }
    }
}
