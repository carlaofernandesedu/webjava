﻿using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.Validations;
using System;
using System.Collections.Generic;
using System.Linq;

namespace br.procon.si.Protocolo.Domain.Services
{
    public class DocumentoSolicitanteService : IDocumentoSolicitanteService
    {
        private readonly IDocumentoSolicitanteRepository _documentoSolicitanteRepository;
        private readonly IDocumentoRepository _documentoRepository;
        private readonly IUnidadeAdministrativaRepository _unidadeAdministrativaRepository;

        public DocumentoSolicitanteService(IDocumentoSolicitanteRepository documentoSolicitanteRepository, IDocumentoRepository documentoRepository, IUnidadeAdministrativaRepository unidadeAdministrativaRepository)
        {
            _documentoSolicitanteRepository = documentoSolicitanteRepository;
            _documentoRepository = documentoRepository;
            _unidadeAdministrativaRepository = unidadeAdministrativaRepository;
        }

        public IEnumerable<DocumentoSolicitante> Obter(int idDocumento, int? idUAUsuarioLogado)
        {
            var retorno = _documentoSolicitanteRepository.Obter(idDocumento);
            return retorno.ToList().OrderBy(x => x.Nome);
        }

        public DocumentoSolicitante ObterPorId(int idDocumentoSolicitante, int? idUAUsuarioLogado)
        {
            return _documentoSolicitanteRepository.ObterPorId(idDocumentoSolicitante);
        }

        public DocumentoSolicitante Alterar(DocumentoSolicitante obj, int? idUAUsuarioLogado, int idUsuarioLogado)
        {
            var doc = _documentoRepository.Obter(obj.IdDocumento);

            var uaProdutoraUsuarioLogado = ValidarUaProdutoraUsuario(ref doc, _documentoRepository, _unidadeAdministrativaRepository, idUsuarioLogado);

            if (uaProdutoraUsuarioLogado)
            {
                obj = _documentoSolicitanteRepository.Alterar(obj);
            }

            obj.ValidationResult.Add(doc.ValidationResult);
            return obj;
        }

        public DocumentoSolicitante Incluir(DocumentoSolicitante obj, int? idUAUsuarioLogado, int idUsuarioLogado)
        {
            var doc = _documentoRepository.Obter(obj.IdDocumento);

             var uaProdutoraUsuarioLogado = ValidarUaProdutoraUsuario(ref doc, _documentoRepository, _unidadeAdministrativaRepository, idUsuarioLogado);

             if (uaProdutoraUsuarioLogado)
             {
                 obj = _documentoSolicitanteRepository.Incluir(obj);
             }

             obj.ValidationResult.Add(doc.ValidationResult);
             return obj;
        }

        private bool ValidarUaProdutoraUsuario(ref Documento entity, IDocumentoRepository documentoRepository, IUnidadeAdministrativaRepository unidadeAdministrativaRepository, int idUsuarioLogado)
        {
            var validationResult = new DocumentoEditarDadosValidation(documentoRepository, unidadeAdministrativaRepository, idUsuarioLogado).Valid(entity);

            foreach (var validationResultError in validationResult.Errors)
            {
                entity.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public int Excluir(int idDocumentoSolicitante, int? idUAUsuarioLogado)
        {
            int retorno = _documentoSolicitanteRepository.Excluir(idDocumentoSolicitante);

            return retorno;
        }
    }
}
