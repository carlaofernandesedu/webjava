﻿using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.Validations;
using br.procon.si.Protocolo.Domain.ValueObjects;
using br.procon.si.Protocolo.Domain.ValueObjects.Enums;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace br.procon.si.Protocolo.Domain.Services
{
    public class DocumentoMovimentacaoService : IDocumentoMovimentacaoService
    {
        private readonly IDocumentoMovimentacaoRepository _documentoMovimentacaoRepository;
        private readonly IDocumentoRepository _documentoRepository;
        private readonly IUnidadeAdministrativaRepository _unidadeAdministrativaRepository;
        private readonly IProcessoRepository _processoRepository;
        private readonly IPrazoCumprimentoRepository _prazoCumprimentoRepository;
        private readonly IProcessoPrazoService _processoPrazoService;

        private readonly IDocumentoVolumeRepository _documentoVolumeRepository;
        private readonly IDocumentoIncorporacaoRepository _documentoIncorporacaoRepository;
        private readonly IDocumentoApensarRepository _documentoApensarRepository;
        private readonly IArquivamentoRepository _arquivamentoRepository;
        private readonly IRemessaRepository _remessaRepository;
        private readonly IDocumentoDestinoRepository _documentoDestinoRepository;

        private readonly IRemessaItemRepository _remessaItemRepository;       

        public DocumentoMovimentacaoService(
            IDocumentoMovimentacaoRepository documentoMovimentacaoRepository,
            IDocumentoRepository documentoRepository,
            IUnidadeAdministrativaRepository unidadeAdministrativaRepository,
            IProcessoRepository processoRepository,
            IPrazoCumprimentoRepository prazoCumprimentoRepository,
            IProcessoPrazoService processoPrazoService,
            IDocumentoVolumeRepository documentoVolumeRepository,
            IDocumentoIncorporacaoRepository documentoIncorporacaoRepository,
            IDocumentoApensarRepository documentoApensarRepository,
            IArquivamentoRepository arquivamentoRepository,
            IRemessaItemRepository remessaItemRepository,
            IDocumentoDestinoRepository documentoDestinoRepository,
            IRemessaRepository remessaRepository
        )
        {
            _documentoMovimentacaoRepository = documentoMovimentacaoRepository;
            _documentoRepository = documentoRepository;
            _unidadeAdministrativaRepository = unidadeAdministrativaRepository;
            _processoRepository = processoRepository;
            _prazoCumprimentoRepository = prazoCumprimentoRepository;
            _processoPrazoService = processoPrazoService;
            _documentoVolumeRepository = documentoVolumeRepository;
            _documentoIncorporacaoRepository = documentoIncorporacaoRepository;
            _documentoApensarRepository = documentoApensarRepository;
            _arquivamentoRepository = arquivamentoRepository;
            _remessaItemRepository = remessaItemRepository;
            _documentoDestinoRepository = documentoDestinoRepository;
            _remessaRepository = remessaRepository;
        }

        public DocumentoMovimentacaoService(
            IDocumentoMovimentacaoRepository documentoMovimentacaoRepository)
        {
            _documentoMovimentacaoRepository = documentoMovimentacaoRepository;
        }

        public IEnumerable<DocumentoMovimentacao> Obter()
        {
            return _documentoMovimentacaoRepository.Obter();
        }

        public IEnumerable<DocumentoMovimentacao> Obter(int idDocumento)
        {
            var resultado = _documentoMovimentacaoRepository.Obter(idDocumento);
            return resultado;
        }

        public IEnumerable<Movimento> ObterMovimento()
        {
            return _documentoMovimentacaoRepository.ObterMovimento();
        }

        public Movimento ObterMovimentoPorId(int idMovimento)
        {
            return _documentoMovimentacaoRepository.ObterMovimentoPorId(idMovimento);
        }

        public DocumentoMovimentacao ObterPorId(int idDocMovimentacao)
        {
            return _documentoMovimentacaoRepository.ObterPorId(idDocMovimentacao);
        }

        public DocumentoMovimentacao Incluir(DocumentoMovimentacao entidade, int idUsuarioLogado)
        {
            var validarUsuarioPosse = ValidarUsuarioPosse(_documentoRepository, _unidadeAdministrativaRepository, idUsuarioLogado, ref entidade);
            var validarDataAutuacaoProcesso = ValidarDataAutuacaoProcesso(_processoRepository, ref entidade);
            var validarRegraMovimentacao = ValidarRegraMovimentacao(entidade.IdDocumento, idUsuarioLogado, ref entidade);

            if (validarUsuarioPosse && validarDataAutuacaoProcesso && validarRegraMovimentacao)
            {
                var retorno = _documentoMovimentacaoRepository.Incluir(entidade);

                var objPrazo = _processoPrazoService.ObterPrazoProcessoPorMovimentacao(retorno, idUsuarioLogado);
                _processoPrazoService.Incluir(objPrazo);
            }

            return entidade;
        }

        public DocumentoMovimentacao Alterar(DocumentoMovimentacao entidade, int idUsuarioLogado)
        {
            var validarMovimentoManual = ValidarMovimentoManual(ref entidade);
            var validarUsuarioRegistrou = ValidarUsuarioRegistrou(_documentoMovimentacaoRepository, _unidadeAdministrativaRepository, idUsuarioLogado, ref entidade);
            var validarDataAutuacaoProcesso = ValidarDataAutuacaoProcesso(_processoRepository, ref entidade);
            var validarRegraMovimentacao = ValidarRegraMovimentacao(entidade.IdDocumento, idUsuarioLogado, ref entidade);

            if (validarMovimentoManual && validarUsuarioRegistrou && validarDataAutuacaoProcesso && validarRegraMovimentacao)
            {
                entidade = _documentoMovimentacaoRepository.Alterar(entidade);

                var objPrazo = _processoPrazoService.ObterPrazoProcessoPorMovimentacao(entidade, idUsuarioLogado);
                _processoPrazoService.Alterar(objPrazo);
            }

            return entidade;
        }

        public DocumentoMovimentacao Excluir(DocumentoMovimentacao entidade, int idUsuarioLogado)
        {
            var validarMovimentoManual = ValidarMovimentoManual(ref entidade);
            var validarUsuarioRegistrou = ValidarUsuarioRegistrou(_documentoMovimentacaoRepository, _unidadeAdministrativaRepository, idUsuarioLogado, ref entidade);
            var validarRegraMovimentacao = ValidarRegraMovimentacao(entidade.IdDocumento, idUsuarioLogado, ref entidade);

            if (validarUsuarioRegistrou && validarMovimentoManual && validarRegraMovimentacao)
            {
                var objPrazo = _processoPrazoService.ObterPrazoProcessoPorMovimentacao(entidade, idUsuarioLogado);
                _processoPrazoService.Exlcuir(objPrazo);

                entidade = _documentoMovimentacaoRepository.Excluir(entidade);
            }

            return entidade;
        }

        public bool ValidarMovimentoManual(ref DocumentoMovimentacao entidade)
        {
            var validationResult = new DocumentoMovimentacaoValidation().Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public bool ValidarUsuarioRegistrou(IDocumentoMovimentacaoRepository documentoMovimentacaoRepository, IUnidadeAdministrativaRepository unidadeAdministrativaRepository, int idUsuarioLogado, ref DocumentoMovimentacao entidade)
        {
            var validationResult = new DocumentoMovimentacaoValidation(documentoMovimentacaoRepository, unidadeAdministrativaRepository, idUsuarioLogado).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public bool ValidarUsuarioPosse(IDocumentoRepository documentoRepository, IUnidadeAdministrativaRepository unidadeAdministrativaRepository, int idUsuarioLogado, ref DocumentoMovimentacao entidade)
        {
            var validationResult =
                new DocumentoMovimentacaoValidation(documentoRepository, unidadeAdministrativaRepository,
                    idUsuarioLogado).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public bool ValidarDataAutuacaoProcesso(IProcessoRepository processoRepository, ref DocumentoMovimentacao entidade)
        {
            var validationResult = new DocumentoMovimentacaoValidation(processoRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private bool ValidarRegraMovimentacao(int idDocumento, int idUsuarioLogado, ref DocumentoMovimentacao entidade)
        {
            var validationResult = ValidarRegrasRestricaoMovimentacao(idDocumento, 0, idUsuarioLogado);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public Core.Domain.ValueObjects.ValidationResult ValidarRegrasRestricaoMovimentacao(int idDocumentoPai, int idDocumentoFilho, int idUsuarioLogado)
        {
            var regrasGerais = new DocumentoRegrasGerais();
            var idUaLogado = _unidadeAdministrativaRepository.ObterUADoUsuarioLogado(idUsuarioLogado).IdUA;
            regrasGerais.IdDocumentoPai = idDocumentoPai;
            regrasGerais.IdDocumentoFilho = idDocumentoFilho;

            var validationResult = new DocumentoRegrasGeraisValidation(_processoRepository, _documentoDestinoRepository, _remessaRepository, _remessaItemRepository, _documentoVolumeRepository, _documentoApensarRepository, _documentoIncorporacaoRepository, _documentoRepository, idUaLogado).Valid(regrasGerais);

            foreach (var validationResultError in validationResult.Errors)
            {
                regrasGerais.AdicionarResultadoDeValidacao(validationResultError);
            }

            return regrasGerais.ValidationResult;
        }

        public void RegistrarMovimentacaoAutomatica(string[] parametros, EnumTipoMovimento tipoMovimento, int idDocumento, int idUsuarioLogado)
        {
            var movimento = _documentoMovimentacaoRepository.ObterMovimentoPorId((int)tipoMovimento);

            if (movimento != null)
            {
                var descricao = movimento.DescricaoMovimento;
                var matchCol = Regex.Matches(movimento.DescricaoMovimento, @"#\{(.*?)\}");

                for (int i = 0; i < matchCol.Count; i++)
                {
                    string result = matchCol[i].Groups[0].Value;
                    descricao = descricao.Replace(result, parametros[i]);
                }

                var movimentacao = DocumentoMovimentacao.DocumentoMovimentacaoFactory.RegistrarMovimentacaoAutomatica(idDocumento, DateTime.Now, descricao, false, (Int16)movimento.Codigo, idUsuarioLogado);
                _documentoMovimentacaoRepository.IncluirAutomatica(movimentacao);
            }
        }
    }
}