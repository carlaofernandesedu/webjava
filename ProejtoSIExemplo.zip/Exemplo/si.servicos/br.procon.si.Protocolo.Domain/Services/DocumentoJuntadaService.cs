﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.Validations;
using br.procon.si.Protocolo.Domain.ValueObjects.Enums;

namespace br.procon.si.Protocolo.Domain.Services
{
    public class DocumentoJuntadaService : IDocumentoJuntadaService
    {
        private readonly IDocumentoJuntadaRepository _documentoJuntadaRepository;
        private readonly IDocumentoRepository _documentoRepository;
        private readonly IUnidadeAdministrativaRepository _unidadeAdministrativaRepository;
        private readonly IDocumentoMovimentacaoRepository _documentoMovimentacaoRepository;
        private readonly IDocumentoMovimentacaoService _documentoMovimentacaoService;
        private DocumentoMovimentacao _movimentacao;

        public DocumentoJuntadaService(IDocumentoJuntadaRepository documentoJuntadaRepository, IDocumentoRepository documentoRepository,
            IDocumentoMovimentacaoRepository documentoMovimentacaoRepository, IDocumentoMovimentacaoService documentoMovimentacaoService, IUnidadeAdministrativaRepository unidadeAdministrativaRepository)
        {
            _documentoJuntadaRepository = documentoJuntadaRepository;
            _documentoRepository = documentoRepository;
            _unidadeAdministrativaRepository = unidadeAdministrativaRepository;
            _documentoMovimentacaoRepository = documentoMovimentacaoRepository;
            _documentoMovimentacaoService = documentoMovimentacaoService;
            _movimentacao = null;
        }

        public DocumentoJuntada ObterPorId(int idJuntada)
        {
            return _documentoJuntadaRepository.ObterPorId(idJuntada);
        }

        public IEnumerable<DocumentoJuntada> Obter(int idDocumento)
        {
            return _documentoJuntadaRepository.Obter(idDocumento);
        }

        public DocumentoJuntada Incluir(DocumentoJuntada entidade, int idUsuarioLogado)
        {
            var validarUaPosse = ValidarUaPosse(_documentoRepository, _unidadeAdministrativaRepository, idUsuarioLogado, ref entidade);
            var validarRegrasRestricaoMovimentacao = ValidarRegrasRestricaoMovimentacao(entidade.IdDocumento, entidade.IdDocumento, idUsuarioLogado, ref entidade);

            if (validarUaPosse && validarRegrasRestricaoMovimentacao)
            {
                _documentoJuntadaRepository.Incluir(entidade);
                string[] descricaoJuntada = { entidade.DescricaoJuntada };
                _documentoMovimentacaoService.RegistrarMovimentacaoAutomatica(descricaoJuntada, EnumTipoMovimento.Juntada, entidade.IdDocumento, idUsuarioLogado);
            }
            return entidade;
        }

        public DocumentoJuntada Alterar(DocumentoJuntada entidade, int idUsuarioLogado, int idUaUsuarioLogado)
        {
            var validarUaPosse = ValidarUaPosse(_documentoRepository, _unidadeAdministrativaRepository, idUsuarioLogado, ref entidade);
            var validarUsuarioPertencenteDocJuntado = ValidarUsuarioPertecenteDocumentoJuntada(_unidadeAdministrativaRepository, idUaUsuarioLogado, ref entidade);
            var validarRegrasRestricaoMovimentacao = ValidarRegrasRestricaoMovimentacao(entidade.IdDocumento, entidade.IdDocumento, idUsuarioLogado, ref entidade);

            if (validarUaPosse && validarUsuarioPertencenteDocJuntado && validarRegrasRestricaoMovimentacao)
            {
                _documentoJuntadaRepository.Alterar(entidade);
                // Todo: Foi identificado pelo Sérgio que o modelo atual da movimentação não permite a alteração pois não tem vinculo com a tabela de juntada. Possível melhoria
            }

            return entidade;
        }

        public DocumentoJuntada Excluir(DocumentoJuntada entidade, int idUsuarioLogado, int idUaUsuarioLogado)
        {
            var validarPosse = ValidarUaPosse(_documentoRepository, _unidadeAdministrativaRepository, idUsuarioLogado, ref entidade);
            var validarUsuarioPertencenteDocJuntado = ValidarUsuarioPertecenteDocumentoJuntada(_unidadeAdministrativaRepository, idUaUsuarioLogado, ref entidade);
            var validarRegrasRestricaoMovimentacao = ValidarRegrasRestricaoMovimentacao(entidade.IdDocumento, entidade.IdDocumento, idUsuarioLogado, ref entidade);

            if (validarPosse && validarUsuarioPertencenteDocJuntado && validarRegrasRestricaoMovimentacao)
            {
                _documentoJuntadaRepository.Excluir(entidade);
                string[] descricaoJuntada = { entidade.DescricaoJuntada };
                _documentoMovimentacaoService.RegistrarMovimentacaoAutomatica(descricaoJuntada, EnumTipoMovimento.JuntadaCancelamento, entidade.IdDocumento, idUsuarioLogado);
            }

            return entidade;
        }

        public bool ValidarUaPosse(IDocumentoRepository documentoRepository, IUnidadeAdministrativaRepository unidadeAdministrativaRepository, int idUsuarioLogado, ref DocumentoJuntada entidade)
        {
            var validationResult = new DocumentoJuntadaValidation(documentoRepository, unidadeAdministrativaRepository, idUsuarioLogado).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public bool ValidarUsuarioPertecenteDocumentoJuntada(IUnidadeAdministrativaRepository unidadeAdministrativaRepository, int idUaUsuarioLogado, ref DocumentoJuntada entidade)
        {
            var validationResult = new DocumentoJuntadaValidation(unidadeAdministrativaRepository, idUaUsuarioLogado).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public bool ValidarRegrasRestricaoMovimentacao(int idDocumentoPai, int idDocumentoFilho, int idUsuarioLogado, ref DocumentoJuntada entidade)
        {
            var validationResult = _documentoMovimentacaoService.ValidarRegrasRestricaoMovimentacao(idDocumentoPai, idDocumentoFilho, idUsuarioLogado);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }
    }
}
