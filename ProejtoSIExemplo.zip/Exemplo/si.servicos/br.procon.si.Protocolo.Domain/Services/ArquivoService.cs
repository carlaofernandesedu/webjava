﻿using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.Validations;
using br.procon.si.Protocolo.Domain.ValueObjects;
using br.procon.si.Protocolo.Domain.ValueObjects.Arquivamento;
using br.procon.si.Protocolo.Domain.ValueObjects.Enums;
using System;
using System.Collections.Generic;
using System.Linq;

namespace br.procon.si.Protocolo.Domain.Services
{
    public class ArquivoService : IArquivoService
    {
        private readonly IMovelArquivoRepository _movelArquivoRepository;
        private readonly IMovelDivisaoRepository _movelDivisaoRepository;
        private readonly ILocalArquivoRepository _localArquivoRepository;
        private readonly ITipoMovelArquivoRepository _tipoMovelArquivoRepository;
        private readonly ICaixaArquivoRepository _caixaArquivoRepository;
        private readonly IArquivamentoRepository _arquivamentoRepository;
        private readonly IDocumentoVolumeRepository _documentoVolumeRepository;
        private readonly IDocumentoRepository _documentoRepository;
        private readonly IUnidadeAdministrativaRepository _unidadeAdministrativaRepository;
        private readonly ISerieDocumentalRepository _serieDocumentalRepository;
        private readonly IPropostaEliminacaoRepository _propostaEliminacaoRepository;
        private readonly IPropostaCaixaRepository _propostaCaixaRepository;
        private readonly IPropostaItemRepository _propostaItemRepository;
        private readonly IProcessoRepository _processoRepository;

        public ArquivoService(
            IMovelArquivoRepository movelArquivoRepository,
            IMovelDivisaoRepository movelDivisaoRepository,
            ILocalArquivoRepository localArquivoRepository,
            ICaixaArquivoRepository caixaArquivoRepository,
            ITipoMovelArquivoRepository tipoMovelArquivoRepository,
            IArquivamentoRepository arquivamentoRepository,
            IDocumentoRepository documentoRepository,
            IDocumentoVolumeRepository documentoVolumeRepository,
            IUnidadeAdministrativaRepository unidadeAdministrativaRepository,
            ISerieDocumentalRepository serieDocumentalRepository,
            IPropostaCaixaRepository propostaCaixaRepository,
            IPropostaItemRepository propostaItemRepository,
            IProcessoRepository processoRepository)
        {
            _movelArquivoRepository = movelArquivoRepository;
            _movelDivisaoRepository = movelDivisaoRepository;
            _localArquivoRepository = localArquivoRepository;
            _caixaArquivoRepository = caixaArquivoRepository;
            _tipoMovelArquivoRepository = tipoMovelArquivoRepository;
            _arquivamentoRepository = arquivamentoRepository;
            _documentoRepository = documentoRepository;
            _documentoVolumeRepository = documentoVolumeRepository;
            _unidadeAdministrativaRepository = unidadeAdministrativaRepository;
            _serieDocumentalRepository = serieDocumentalRepository;
            _propostaCaixaRepository = propostaCaixaRepository;
            _processoRepository = processoRepository;
            _propostaItemRepository = propostaItemRepository;
        }

        public IEnumerable<MovelArquivo> ObterMoveisArquivosPorIdLocalArquivo(int idLocalArquivo)
        {
            List<MovelArquivo> moveis = _movelArquivoRepository.ObterPorIdLocalArquivo(idLocalArquivo).ToList();

            LocalArquivo local = _localArquivoRepository.Obter(new FiltroLocalArquivo { IdLocalArquivo = idLocalArquivo });

            foreach (MovelArquivo movel in moveis)
            {
                movel.DefinirLocalArquivo(local);
                movel.DefinirTipoMovelArquivo(_tipoMovelArquivoRepository.Obter(movel.IdTipoMovelArquivo));
            }

            return moveis;
        }

        public IEnumerable<MovelArquivo> ObterMoveisArquivos(FiltroLocalArquivo filtro)
        {
            List<MovelArquivo> moveis = new List<MovelArquivo>();

            if (filtro.IdLocalArquivo.HasValue)
            {
                LocalArquivo local = _localArquivoRepository.Obter(filtro);

                moveis = _movelArquivoRepository.ObterPorIdLocalArquivo(filtro.IdLocalArquivo.Value).ToList();
                foreach (MovelArquivo movel in moveis)
                {
                    movel.DefinirLocalArquivo(local);
                    movel.DefinirTipoMovelArquivo(_tipoMovelArquivoRepository.Obter(movel.IdTipoMovelArquivo));
                }
            }
            else if (filtro.IdUA.HasValue)
            {
                var locais = _localArquivoRepository.ObterPorIdUa(filtro.IdUA.Value, null);

                foreach (var local in locais)
                {
                    var moveisDoLocal = _movelArquivoRepository.ObterPorIdLocalArquivo(local.Id);

                    foreach (var movel in moveisDoLocal)
                    {
                        movel.DefinirLocalArquivo(local);
                        movel.DefinirTipoMovelArquivo(_tipoMovelArquivoRepository.Obter(movel.IdTipoMovelArquivo));
                        moveis.Add(movel);
                    }
                }
            }

            return moveis;
        }

        public MovelArquivo SalvarMovelArquivo(MovelArquivo movelArquivo)
        {
            if (ValidarSalvarMovelArquivo(movelArquivo))
            {
                foreach (var divisao in movelArquivo.Divisoes)
                {
                    divisao.DefinirIdMovelArquivo(movelArquivo.Id);
                }

                List<MovelDivisao> divisoesExcluidas = null;

                if (movelArquivo.Id != 0)
                {
                    IEnumerable<MovelDivisao> divisoesDB = _movelDivisaoRepository.ObterPorIdMovelArquivo(movelArquivo.Id);

                    divisoesExcluidas = divisoesDB.Where(x => !movelArquivo.Divisoes.Any(y => y.Id == x.Id)).ToList();

                    if (divisoesExcluidas != null)
                    {
                        foreach (MovelDivisao divisao in divisoesExcluidas)
                        {
                            if (!ValidarExcluirMovelDivisao(movelArquivo, divisao))
                            {
                                return movelArquivo;
                            }
                        }
                    }
                }

                if (movelArquivo.Id == 0)
                {
                    movelArquivo.DefinirId(_movelArquivoRepository.Inserir(movelArquivo));
                }
                else
                {
                    if (divisoesExcluidas != null)
                    {
                        foreach (MovelDivisao divisao in divisoesExcluidas)
                        {
                            _movelDivisaoRepository.Excluir(divisao);
                        }
                    }
                    _movelArquivoRepository.Atualizar(movelArquivo);
                }

                if (movelArquivo.Divisoes != null)
                {
                    foreach (MovelDivisao divisao in movelArquivo.Divisoes)
                    {
                        if (divisao.Id == 0)
                        {
                            divisao.DefinirIdMovelArquivo(movelArquivo.Id);
                            divisao.DefinirId(_movelDivisaoRepository.Inserir(divisao));
                        }
                        else
                        {
                            _movelDivisaoRepository.Atualizar(divisao);
                        }
                    }
                }
            }

            return movelArquivo;
        }

        private bool ValidarSalvarMovelArquivo(MovelArquivo entidade)
        {
            var validationResult = new MovelArquivoValidation(_movelArquivoRepository, _unidadeAdministrativaRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public MovelArquivo ExcluirMovelArquivo(MovelArquivo movelArquivo)
        {
            var divisoesBD = _movelDivisaoRepository.ObterPorIdMovelArquivo(movelArquivo.Id);
            movelArquivo.DefinirDivisoes(divisoesBD);

            if (ValidarExcluirMovelArquivo(movelArquivo))
            {
                if (movelArquivo.Divisoes != null)
                {
                    foreach (MovelDivisao divisao in movelArquivo.Divisoes)
                    {
                        _movelDivisaoRepository.Excluir(divisao);
                    }
                }
                _movelArquivoRepository.Excluir(movelArquivo);
            }

            return movelArquivo;
        }

        public MovelDivisao ExcluirMovelDivisao(MovelDivisao divisao)
        {
            if (ValidarExcluirMovelDivisao(divisao.Id))
            {
                _movelDivisaoRepository.Excluir(divisao);
            }

            return divisao;
        }

        private bool ValidarExcluirMovelDivisao(MovelArquivo movelArquivo, MovelDivisao entidade)
        {
            var validationResult = new MovelDivisaoExclusaoValidation(_caixaArquivoRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                movelArquivo.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public bool ValidarExcluirMovelDivisao(int id)
        {
            var entidade = _movelDivisaoRepository.Obter(id);

            var validationResult = new MovelDivisaoExclusaoValidation(_caixaArquivoRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private bool ValidarExcluirMovelArquivo(MovelArquivo entidade)
        {
            var validationResult = new MovelArquivoExclusaoValidation(_caixaArquivoRepository, _unidadeAdministrativaRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public IEnumerable<CaixaArquivo> ObterCaixasArquivosPorCodigoDescricao(string codigo, string descricao, bool? ativo)
        {
            var caixas = _caixaArquivoRepository.ObterPorCodigoDescricao(String.IsNullOrWhiteSpace(codigo) ? null : codigo, String.IsNullOrWhiteSpace(descricao) ? null : descricao, ativo);

            if (caixas != null && caixas.Count() > 0)
            {
                foreach (var item in caixas)
                {
                    if (item.IdSerieDocumental != null)
                    {
                        item.DefinirSerieDocumental(_serieDocumentalRepository.Obter( Convert.ToInt32(item.IdSerieDocumental)).Descricao);
                    }
                }
            }

            return caixas;
        }

        public CaixaArquivo SalvarCaixaArquivo(CaixaArquivo caixaArquivo)
        {
            var regrasGerais = ValidarSalvarCaixaArquivo(caixaArquivo);
            var regrasEdicao = ValidarEdicao(caixaArquivo);
            var regrasPropostaEliminacao = ValidarExistePropostaEliminacao(caixaArquivo);

            if (regrasGerais && regrasPropostaEliminacao && regrasEdicao)
            {
                if (caixaArquivo.Id == 0)
                {
                    caixaArquivo.DefinirId(_caixaArquivoRepository.Inserir(caixaArquivo));
                }
                else
                {
                    _caixaArquivoRepository.Atualizar(caixaArquivo);
                }
            }
            return caixaArquivo;
        }

        public CaixaArquivo ExcluirCaixaArquivo(CaixaArquivo caixaArquivo)
        {
            var regrasGerais = ValidarSalvarCaixaArquivo(caixaArquivo);
            var regrasArquivamento = ValidarExisteArquivamento(caixaArquivo);
            var regrasPropostaEliminacao = ValidarExistePropostaEliminacao(caixaArquivo);

            if (regrasGerais && regrasPropostaEliminacao && regrasArquivamento)
            {
                _caixaArquivoRepository.Excluir(caixaArquivo);
            }
            return caixaArquivo;
        }

        private bool ValidarSalvarCaixaArquivo(CaixaArquivo entidade)
        {
            var validationResult = new CaixaArquivoValidation(_caixaArquivoRepository, _unidadeAdministrativaRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private bool ValidarExistePropostaEliminacao(CaixaArquivo entidade)
        {
            var validationResult = new CaixaArquivoValidation(_propostaCaixaRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private bool ValidarExisteArquivamento(CaixaArquivo entidade)
        {
            var validationResult = new CaixaArquivoValidation(_arquivamentoRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private bool ValidarEdicao(CaixaArquivo entidade)
        {
            var validationResult = new CaixaArquivoValidation(_arquivamentoRepository, _caixaArquivoRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private bool ValidarExcluirCaixaArquivo(CaixaArquivo entidade)
        {
            var validationResult = new CaixaArquivoExclusaoValidation(_documentoVolumeRepository, _unidadeAdministrativaRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public Arquivamento ArquivarDocumento(Arquivamento arquivamento)
        {
            var regrasGerais = ValidarArquivamento(arquivamento);
            var regrasDuplicidade = ValidarDuplicidade(arquivamento);
            var regrasVolumeEmAndamento = ValidarVolumeEmAndamento(arquivamento);          

            if (regrasGerais && regrasDuplicidade && regrasVolumeEmAndamento)
            {
                DocumentoVolume volume = _documentoVolumeRepository.ObterPorId(arquivamento.IdDocumentoVolume);

                volume.DefinirIdCaixaArquivo(arquivamento.IdCaixaArquivo);
                volume.DefinirSituacaoVolume((int)EnumSituacaoVolume.Arquivado);
                volume.IdUsuarioOperacao = arquivamento.IdUsuarioOperacao;
                volume.DefinirIdUsuarioAlteracao((int)arquivamento.IdUsuarioOperacao);
                _documentoVolumeRepository.Alterar(volume);

                Documento documento = _documentoRepository.Obter(volume.IdDocumento);
                SerieDocumental serieDocumental = _serieDocumentalRepository.Obter(documento.IdSerieDocumental);

                if (serieDocumental.IdSerieDocumentalClassificacao == 5 || serieDocumental.IdTipoPrazoGuardaProdutora != 3)
                {
                    documento.IdUsuarioOperacao = arquivamento.IdUsuarioOperacao;
                    documento.DefinirDtEncerramento((DateTime?)DateTime.Now);
                    _documentoRepository.Alterar(documento);
                }

                arquivamento.DefinirIdTipoArquivamento((int)EnumTipoArquivamento.ARQUIVAMENTO);
                arquivamento.DefinirId(_arquivamentoRepository.Inserir(arquivamento));
            }
            return arquivamento;
        }

        private bool ValidarArquivamento(Arquivamento entidade)
        {
            var validationResult = new ArquivamentoValidation(_documentoRepository, _documentoVolumeRepository, _caixaArquivoRepository, _unidadeAdministrativaRepository, _processoRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private bool ValidarDuplicidade(Arquivamento entidade)
        {
            var validationResult = new ArquivamentoValidation(_caixaArquivoRepository, _documentoVolumeRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private bool ValidarVolumeEmAndamento(Arquivamento entidade)
        {
            var validationResult = new ArquivamentoValidation(_documentoVolumeRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }       

        public Arquivamento RearquivarDocumento(Arquivamento arquivamento)
        {
            var regrasGerais = ValidarArquivamento(arquivamento);

            if (regrasGerais)
            {
                DocumentoVolume volume = _documentoVolumeRepository.ObterPorId(arquivamento.IdDocumentoVolume);
                volume.DefinirIdCaixaArquivo(arquivamento.IdCaixaArquivo);
                volume.DefinirSituacaoVolume((int)EnumSituacaoVolume.Arquivado);
                volume.IdUsuarioOperacao = arquivamento.IdUsuarioOperacao;
                volume.DefinirIdUsuarioAlteracao((int)arquivamento.IdUsuarioOperacao);
                _documentoVolumeRepository.Alterar(volume);

                arquivamento.DefinirIdTipoArquivamento((int)EnumTipoArquivamento.REARQUIVAMENTO);

                arquivamento.DefinirId(_arquivamentoRepository.Inserir(arquivamento));
            }
            return arquivamento;
        }

        private bool ValidarRearquivamento(Arquivamento entidade)
        {
            var validationResult = new RearquivamentoValidation(_documentoRepository, _documentoVolumeRepository, _caixaArquivoRepository, _unidadeAdministrativaRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public Arquivamento DesarquivarDocumentoParaAndamento(Arquivamento arquivamento)
        {
            var regrasGerais = ValidarArquivamento(arquivamento);

            if (regrasGerais)
            {
                DocumentoVolume volume = _documentoVolumeRepository.ObterPorId(arquivamento.IdDocumentoVolume);

                volume.DefinirIdCaixaArquivo(null);
                volume.DefinirSituacaoVolume((int)EnumSituacaoVolume.Andamento);
                volume.IdUsuarioOperacao = arquivamento.IdUsuarioOperacao;
                volume.DefinirIdUsuarioAlteracao((int)arquivamento.IdUsuarioOperacao);

                _documentoVolumeRepository.Alterar(volume);

                var processo = _processoRepository.ObterIdDocumento(volume.IdDocumento);

                processo.DefinirSituacao((int)EnumSituacaoVolume.Andamento);

                _processoRepository.Atualizar(processo);

                arquivamento.DefinirIdTipoArquivamento((int)EnumTipoArquivamento.DESARQUIVAMENTO_PARA_ANDAMENTO);

                arquivamento.DefinirId(_arquivamentoRepository.Inserir(arquivamento));
            }
            return arquivamento;
        }

        private bool ValidarDesarquivamento(Arquivamento entidade)
        {
            var validationResult = new DesarquivamentoValidation(_documentoRepository, _documentoVolumeRepository, _caixaArquivoRepository, _unidadeAdministrativaRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public Arquivamento DesarquivarDocumentoSemReabertura(Arquivamento arquivamento)
        {
            if (ValidarDesarquivamento(arquivamento))
            {
                DocumentoVolume volume = _documentoVolumeRepository.ObterPorId(arquivamento.IdDocumentoVolume);
                volume.DefinirSituacaoVolume((int)EnumSituacaoVolume.Desarquivado);
                volume.IdUsuarioOperacao = arquivamento.IdUsuarioOperacao;
                volume.DefinirIdUsuarioAlteracao((int)arquivamento.IdUsuarioOperacao);
                _documentoVolumeRepository.Alterar(volume);

                arquivamento.DefinirIdTipoArquivamento((int)EnumTipoArquivamento.DESARQUIVAMENTO_SEM_REABERTURA);

                arquivamento.DefinirId(_arquivamentoRepository.Inserir(arquivamento));
            }
            return arquivamento;
        }

        public Arquivamento EditarUltimoArquivamento(Arquivamento arquivamento)
        {
            if (ValidarEdicaoArquivamento(arquivamento))
            {
                var ultimoArquivamento = _arquivamentoRepository.ObterUltimoArquivamento(arquivamento.IdCaixaArquivo, arquivamento.IdDocumentoVolume);

                ultimoArquivamento.DefinirDataArquivamento(arquivamento.DataArquivamento);
                ultimoArquivamento.IdUsuarioOperacao = arquivamento.IdUsuarioOperacao;

                _arquivamentoRepository.Atualizar(ultimoArquivamento);

                return ultimoArquivamento;
            }

            return arquivamento;
        }

        private bool ValidarEdicaoArquivamento(Arquivamento entidade)
        {
            var validationResult = new ArquivamentoEdicaoValidation(_documentoRepository, _documentoVolumeRepository, _caixaArquivoRepository, _unidadeAdministrativaRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public IEnumerable<CaixaArquivo> ObterCaixaPorPrazoVencido(int idUsuarioLogado)
        {
            List<CaixaArquivo> listCaixas = new List<CaixaArquivo>();
            List<CaixaArquivo> listCaixasLivres = new List<CaixaArquivo>();
            List<CaixaArquivo> listCaixasProcessoEliminacao = new List<CaixaArquivo>();

            UnidadeAdministrativa ua = _unidadeAdministrativaRepository.ObterUADoUsuarioLogado(idUsuarioLogado);

            var siglaDiretoriaPai = ua.Sigla.Split('/').Length > 0 ? ua.Sigla.Split('/')[0] : ua.Sigla;

            var listaUnidadesDiretoriaPai = _unidadeAdministrativaRepository.Obter().Where(u => u.Sigla.StartsWith(siglaDiretoriaPai.Trim())).ToList();

            foreach (var item in listaUnidadesDiretoriaPai)
            {
                var caixas = item.Sigla.Equals("DRI")
                   ? _caixaArquivoRepository.ObterPorUaSituacao(0, null, true).Where(x => x.IdSerieDocumental > 0 && x.DtFim.Value.Date < DateTime.Now.Date)
                   : _caixaArquivoRepository.ObterPorUAProdutora(item.IdUA).Where(x => x.IdSerieDocumental > 0 && x.DtFim.Value.Date < DateTime.Now.Date);

                listCaixasLivres.AddRange(caixas);
            }

            List<PropostaCaixa> itemsPropostaCaixa = new List<PropostaCaixa>();

            listCaixasLivres.ForEach(x =>
            {
                var propostaCaixas = _propostaCaixaRepository.ObterPorCaixa(x.Id).Distinct().ToList();

                var listItens = new List<PropostaEliminacaoItem>();
                var encontradoPropostaEliminacao = false;

                foreach (var pCaixa in propostaCaixas)
                {
                    listItens.AddRange(_propostaItemRepository.ObterPropostaItem(new FiltroPropostaEliminacaoItem() { IdPropostaItem = pCaixa.IdPropostaItem, Situacao = EnumSituacaoPropostaEliminacaoItem.Aprovado }).ToList());

                    if (listItens.Count() > 0)
                    {
                        encontradoPropostaEliminacao = true;
                        break;
                    }
                }

                if (encontradoPropostaEliminacao)
                {
                    return;
                }

                if (listCaixas.Count(c => c.Id == x.Id) == 0)
                {
                    listCaixas.Add(x);
                }
            });

            listCaixas.ForEach(x =>
            {
                x.DefinirSerieDocumental(_serieDocumentalRepository.Obter(Convert.ToInt32(x.IdSerieDocumental)).Descricao);
            });

            return listCaixas;
        }

        public IEnumerable<CaixaArquivo> ObterCaixaPorPrazoVencidoPorPeriodo(DateTime dtInicio, DateTime dtFim, int idUsuarioLogado)
        {
            var listCaixas = ObterCaixaPorPrazoVencido(idUsuarioLogado).ToList();

            return listCaixas.Where(x => x.DtInicio >= dtInicio && x.DtFim <= dtFim).ToList();
        }
    }
}