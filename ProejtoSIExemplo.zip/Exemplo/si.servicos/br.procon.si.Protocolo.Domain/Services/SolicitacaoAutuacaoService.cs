﻿using br.procon.si.Core.Domain.ValueObjects;
using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Infra;
using br.procon.si.Protocolo.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.Validations;
using br.procon.si.Protocolo.Domain.ValueObjects;
using br.procon.si.Protocolo.Domain.ValueObjects.Enums;
using System;
using System.Collections.Generic;
using System.Linq;

namespace br.procon.si.Protocolo.Domain.Services
{
    public class SolicitacaoAutuacaoService : ISolicitacaoAutuacaoService
    {
        private readonly ISolicitacaoAutuacaoRepository _solicitacaoAutuacaoRepository;
        private readonly IDocumentoRepository _documentoRepository;
        private readonly IUnidadeAdministrativaRepository _unidadeAdministrativaRepository;
        private readonly IDocumentoDestinoRepository _documentoDestinoRepository;
        private readonly ISerieDocumentalRepository _serieDocumentalRepository;
        private readonly IDocumentoParteRepository _documentoParteRepository;
        private readonly IRelatorioProtocolo _relatorioProtocolo;

        public SolicitacaoAutuacaoService(ISolicitacaoAutuacaoRepository solicitacaoAutuacaoRepository, IDocumentoRepository documentoRepository, IUnidadeAdministrativaRepository unidadeAdministrativaRepository
            , IDocumentoDestinoRepository documentoDestinoRepository, ISerieDocumentalRepository serieDocumentalRepository, IDocumentoParteRepository documentoParteRepository, IRelatorioProtocolo relatorioProtocolo)
        {
            _solicitacaoAutuacaoRepository = solicitacaoAutuacaoRepository;
            _documentoRepository = documentoRepository;
            _unidadeAdministrativaRepository = unidadeAdministrativaRepository;
            _documentoDestinoRepository = documentoDestinoRepository;
            _serieDocumentalRepository = serieDocumentalRepository;
            _documentoParteRepository = documentoParteRepository;

            _relatorioProtocolo = relatorioProtocolo;
        }

        public IEnumerable<UnidadeAdministrativa> Obter(int idUsuarioLogado)
        {
            var ua = _unidadeAdministrativaRepository.ObterUADoUsuarioLogado(idUsuarioLogado);
            return _unidadeAdministrativaRepository.Obter().Where(x => x.IdUA != ua.IdUA && x.Ativo == true);
        }

        public IEnumerable<UnidadeAdministrativa> ObterUAProtocolo(int idUsuarioLogado)
        {
            var ua = _unidadeAdministrativaRepository.ObterUADoUsuarioLogado(idUsuarioLogado);
            return _unidadeAdministrativaRepository.Obter().Where(x => x.IdUA != ua.IdUA && x.Protocolo == true && x.Ativo == true);
        }

        public IEnumerable<SolicitacaoAutuacao> ObterPorUASolicitante(int idUsuarioLogado)
        {
            var ua = _unidadeAdministrativaRepository.ObterUADoUsuarioLogado(idUsuarioLogado);
            var retorno = ua.Protocolo ? _solicitacaoAutuacaoRepository.ObterPorUa(null, ua.IdUA) : _solicitacaoAutuacaoRepository.ObterPorUa(ua.IdUA, null);

            List<SolicitacaoAutuacao> listaSolicitacaoAutuacao = null;

            if (retorno != null)
            {
                listaSolicitacaoAutuacao = retorno.Where(x => x.IdSituacaoSolicitacao.Equals((int)EnumSituacaoSolicitacao.Aberta)).ToList();

                listaSolicitacaoAutuacao.ToList().ForEach(obj =>
                {
                    obj.DefinirNomeUASolicitante(_unidadeAdministrativaRepository.Obter(obj.IdUASolicitante).Nome);
                    obj.Protocolo = obj.IdDocumento.HasValue ? _documentoRepository.Obter(obj.IdDocumento.Value) : null;

                    if (obj.Protocolo != null && obj.IdDocumento.HasValue)
                    {
                        obj.Protocolo.SerieDocumental = _serieDocumentalRepository.Obter(obj.IdSerieDocumental);
                        obj.Protocolo.DocumentoParte = _documentoParteRepository.Obter(obj.IdDocumento.Value).FirstOrDefault(y => y.Ativo && y.Principal);
                    }
                    else
                    {
                        obj.Protocolo = new Documento();
                        obj.Protocolo.SerieDocumental = _serieDocumentalRepository.Obter(obj.IdSerieDocumental);
                        obj.Protocolo.DocumentoParte = new DocumentoParte();
                        obj.Protocolo.DocumentoParte.DefinirNome(obj.Interessado);
                    }
                });
            }

            return listaSolicitacaoAutuacao;
        }

        public IEnumerable<SolicitacaoAutuacao> Obter(FiltroAutuacaoProcesso filtro, int idUsuarioLogado)
        {
            var ua = _unidadeAdministrativaRepository.ObterUADoUsuarioLogado(idUsuarioLogado);

            if (ua != null)
            {
                if (ua.Protocolo)
                    filtro.UaProtocolo = filtro.UaProtocolo ?? ua.IdUA;
                else
                    filtro.UaSolicitante = filtro.UaSolicitante ?? ua.IdUA;
            }

            var retorno = _solicitacaoAutuacaoRepository.Obter(filtro).ToList();

            if (retorno != null)
            {
                retorno.ToList().ForEach(obj =>
                {
                    obj.DefinirNomeUASolicitante(_unidadeAdministrativaRepository.Obter(obj.IdUASolicitante).Nome);
                    obj.Protocolo = obj.IdDocumento.HasValue ? _documentoRepository.Obter(obj.IdDocumento.Value) : null;

                    if (obj.Protocolo != null && obj.IdDocumento.HasValue)
                    {
                        obj.Protocolo.SerieDocumental = _serieDocumentalRepository.Obter(obj.IdSerieDocumental);
                        obj.Protocolo.DocumentoParte = _documentoParteRepository.Obter(obj.IdDocumento.Value).FirstOrDefault(y => y.Ativo && y.Principal);
                    }
                    else
                    {
                        obj.Protocolo = new Documento();
                        obj.Protocolo.SerieDocumental = _serieDocumentalRepository.Obter(obj.IdSerieDocumental);
                        obj.Protocolo.DocumentoParte = new DocumentoParte();
                        obj.Protocolo.DocumentoParte.DefinirNome(obj.Interessado);
                    }
                });
            }

            return retorno;
        }

        public SolicitacaoAutuacao ObterPorId(int idSolicitacaoAutuacao)
        {
            var obj = _solicitacaoAutuacaoRepository.Obter(idSolicitacaoAutuacao);

            obj.Protocolo = obj.IdDocumento.HasValue ? _documentoRepository.Obter(obj.IdDocumento.Value) : null;

            if (obj.Protocolo != null && obj.IdDocumento.HasValue)
            {
                obj.Protocolo.SerieDocumental = _serieDocumentalRepository.Obter(obj.IdSerieDocumental);
                obj.Protocolo.DocumentoParte = _documentoParteRepository.Obter(obj.IdDocumento.Value).FirstOrDefault(y => y.Ativo && y.Principal);
            }
            else
            {
                obj.Protocolo = new Documento();
                obj.Protocolo.SerieDocumental = _serieDocumentalRepository.Obter(obj.IdSerieDocumental);
                obj.Protocolo.DocumentoParte = new DocumentoParte();
                obj.Protocolo.DocumentoParte.DefinirNome(obj.Interessado);
            }
            return obj;
        }

        public SolicitacaoAutuacao Incluir(SolicitacaoAutuacao entidade)
        {
            entidade.DefinirUASolicitante((short)_unidadeAdministrativaRepository.ObterUADoUsuarioLogado(entidade.IdUsuarioOperacao).IdUA);

            var validarSolicitacaoAutuacao = ValidarSolicitacaoAutuacao(_solicitacaoAutuacaoRepository, ref entidade);
            var validarUaPosse = ValidarUaPosse(_unidadeAdministrativaRepository, ref entidade);
            var validarDocumentoAnexo = ValidarDocumentoAnexo(_documentoRepository, ref entidade);
            var validarSeDocumentoExisteDocumentoDestino = ValidarSeDocumentoExisteDocumentoDestino(_documentoDestinoRepository, ref entidade);

            if (validarSolicitacaoAutuacao && validarUaPosse && validarDocumentoAnexo)
            {
                entidade = _solicitacaoAutuacaoRepository.Incluir(entidade);

                if (validarSeDocumentoExisteDocumentoDestino && entidade.IdDocumento.HasValue)
                {
                    _documentoDestinoRepository.Incluir(new DocumentoDestino(0, entidade.IdDocumento.Value, (byte)entidade.IdUASolicitante, (byte)entidade.IdUADestinatario));
                }
            }

            return entidade;
        }

        public SolicitacaoAutuacao Alterar(SolicitacaoAutuacao entidade)
        {
            entidade.DefinirUASolicitante((short)_unidadeAdministrativaRepository.ObterUADoUsuarioLogado(entidade.IdUsuarioOperacao).IdUA);
            var validarDocumentoAnexo = ValidarDocumentoAnexo(_documentoRepository, ref entidade);
            var validarUaPosse = ValidarUaPosse(_unidadeAdministrativaRepository, ref entidade);

            if (validarDocumentoAnexo && validarUaPosse)
            {
                entidade = _solicitacaoAutuacaoRepository.Alterar(entidade);
            }

            return entidade;
        }

        public bool AlterarSituacaoAutuacao(SolicitacaoAutuacao entidade)
        {
            bool retorno = false;

            entidade.DefinirUASolicitante((short)_unidadeAdministrativaRepository.ObterUADoUsuarioLogado(entidade.IdUsuarioOperacao).IdUA);
            var validarSolicitacaoAutuacaoAlterarSituacao = ValidarSolicitacaoAutucaoAlterarSituacao(_solicitacaoAutuacaoRepository, ref entidade);
            var validarUaPosse = ValidarUaPosse(_unidadeAdministrativaRepository, ref entidade);

            if (validarSolicitacaoAutuacaoAlterarSituacao && validarUaPosse)
            {
                retorno = Convert.ToBoolean(_solicitacaoAutuacaoRepository.AlterarSituacaoAutuacao(entidade));
            }

            return retorno;
        }

        public byte[] TermoSolicitacaoAutuacao(int id, string localizacaoRDL, string nomeUsuarioLogado, int idUsuarioLogado)
        {
            var entidade = _solicitacaoAutuacaoRepository.Obter(id);
            var ua = _unidadeAdministrativaRepository.ObterUADoUsuarioLogado(idUsuarioLogado);
            var uaAutoridade = _unidadeAdministrativaRepository.Obter(entidade.IdUAAutoridade);
            //var documento = _documentoRepository.Obter(entidade.IdDocumento);
            var serieDocumental = _serieDocumentalRepository.Obter(entidade.IdSerieDocumental);
            //var documentoParte = _documentoParteRepository.Obter(entidade.IdDocumento).Where(x => x.Ativo == true && x.Principal == true).FirstOrDefault();

            var rel = new RelatorioSolicitacaoAutuacao();

            rel.NomeDoTermo = "Termo de Solicitação de Autuação";
            rel.IdSolicitacaoAutuacao = entidade.IdSolicitacaoAutuacao;

            if (serieDocumental != null)
                rel.SerieDocumental = serieDocumental.Descricao;

            rel.Interessado = entidade.Interessado;
            rel.Assunto = entidade.Assunto;

            rel.UADestino = _unidadeAdministrativaRepository.Obter(entidade.IdUADestinatario).Nome;

            rel.NomeAutoridade = entidade.NomeSolicitante;
            rel.CargoAutoridade = entidade.CargoSolicitante;
            rel.UAAutoridade = uaAutoridade != null ? uaAutoridade.Nome : string.Empty;
            rel.Usuario = nomeUsuarioLogado;
            rel.UAUsuario = ua.Nome;
            rel.DataGeracaoPDF = DateTime.Now;
            rel.DataSolicitacao = entidade.DataSolicitacao;
            rel.DataExtenso = DateFormatExtensions.FormataDataPorExtenso(entidade.DataSolicitacao);

            return _relatorioProtocolo.ObterTermoSolicitacaoAutuacaoBytePDF(rel, localizacaoRDL);
        }

        private static bool ValidarSolicitacaoAutuacao(ISolicitacaoAutuacaoRepository solicitacaoAutuacaoRepository, ref SolicitacaoAutuacao entidade)
        {
            var validationResult = new SolicitacaoAutuacaoValidation(solicitacaoAutuacaoRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private static bool ValidarSolicitacaoAutucaoAlterarSituacao(ISolicitacaoAutuacaoRepository solicitacaoAutuacaoRepository, ref SolicitacaoAutuacao entidade)
        {
            var validationResult = new SolicitacaoAutuacaoAlterarSituacaoValidation(solicitacaoAutuacaoRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private static bool ValidarUaPosse(IUnidadeAdministrativaRepository unidadeAdministrativaRepository, ref SolicitacaoAutuacao entidade)
        {
            var validationResult = new SolicitacaoAutuacaoValidation(unidadeAdministrativaRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private static bool ValidarDocumentoAnexo(IDocumentoRepository documentoRepository, ref SolicitacaoAutuacao entidade)
        {
            var validationResult = new SolicitacaoAutuacaoValidation(documentoRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        private static bool ValidarSeDocumentoExisteDocumentoDestino(IDocumentoDestinoRepository documentoDestinoRepository, ref SolicitacaoAutuacao entidade)
        {
            var validationResult = new SolicitacaoAutuacaoValidation(documentoDestinoRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }

        public bool ValidarAcoesSolicitacaoAutuacao(EnumAcoesSolicitacaoAutuacao acoesSolicitacaoAutuacao, int idUsuarioLogado, ref SolicitacaoAutuacao entidade)
        {
            var validationResult = new SolicitacaoAutuacaoValidation(acoesSolicitacaoAutuacao, idUsuarioLogado, _solicitacaoAutuacaoRepository, _unidadeAdministrativaRepository).Valid(entidade);

            foreach (var validationResultError in validationResult.Errors)
            {
                entidade.AdicionarResultadoDeValidacao(validationResultError);
            }

            return validationResult.IsValid;
        }
    }
}