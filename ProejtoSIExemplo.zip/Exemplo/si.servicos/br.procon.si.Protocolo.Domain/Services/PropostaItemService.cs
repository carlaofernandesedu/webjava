﻿using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Interfaces;
using System.Collections.Generic;

namespace br.procon.si.Protocolo.Domain.Services
{
    public class PropostaItemService : IPropostaItemService
    {
        private readonly IPropostaItemRepository _propostaItemRepository;
        private readonly IPropostaCaixaRepository _propostaCaixaRepository;

        public PropostaItemService(IPropostaItemRepository propostaItemRepository, IPropostaCaixaRepository propostaCaixaRepository)
        {
            _propostaItemRepository = propostaItemRepository;
            _propostaCaixaRepository = propostaCaixaRepository;
        }

        public IEnumerable<PropostaEliminacaoItem> Obter(int idPropostaEliminacao)
        {
            return _propostaItemRepository.Obter(idPropostaEliminacao);
        }

        public PropostaEliminacaoItem ObterPorId(int id)
        {
            return _propostaItemRepository.ObterPorId(id);
        }

        public PropostaEliminacaoItem Incluir(PropostaEliminacaoItem entidade)
        {
            return _propostaItemRepository.Incluir(entidade);
        }

        public PropostaEliminacaoItem AlterarSituacao(PropostaEliminacaoItem entidade)
        {
            return _propostaItemRepository.AlterarSituacao(entidade);
        }
    }
}