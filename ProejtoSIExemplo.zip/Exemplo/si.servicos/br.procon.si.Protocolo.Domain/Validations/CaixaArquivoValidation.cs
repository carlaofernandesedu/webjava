﻿using br.procon.si.Core.Domain.ValueObjects;
using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.Specifications.CaixaArquivo;

namespace br.procon.si.Protocolo.Domain.Validations
{
    public class CaixaArquivoValidation : Validation<CaixaArquivo>
    {
        public CaixaArquivoValidation(ICaixaArquivoRepository caixaArquivoRepository)
        {
            AddRule(new ValidationRule<CaixaArquivo>(new CaixaArquivoDeveValidarDuplicidadeCodigoSpec(caixaArquivoRepository)));
        }
    }
}