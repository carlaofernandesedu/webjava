﻿using br.procon.si.Core.Data.ADO;
using br.procon.si.Core.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.Entities;
using br.procon.si.Protocolo.Domain.Interfaces;
using br.procon.si.Protocolo.Domain.ValueObjects;
using System.Collections.Generic;

namespace br.procon.si.Protocolo.Data.Repository
{
    public class CaixaArquivoRepository : ICaixaArquivoRepository
    {
        private readonly DataHelperUnitOfWork _unidadeDeTrabalho;

        public CaixaArquivoRepository(IUnitOfWork unidadeDeTrabalho)
        {
            _unidadeDeTrabalho = (DataHelperUnitOfWork)unidadeDeTrabalho;
        }

        public IEnumerable<DocumentoCaixaArquivo> ObterDocumentosDaCaixa(int id_caixa_arquivo)
        {
            const string proc = "protocolo.pr_caixa_arquivo_consultar_documentos";

            return _unidadeDeTrabalho.List<DocumentoCaixaArquivo>(proc,
                DataHelperParameters.CreateParameter("@id_caixa_arquivo", id_caixa_arquivo));
        }

        public IEnumerable<CaixaArquivo> ObterPorCodigoDescricao(string codigo, string descricao, bool? ativo)
        {
            const string proc = "protocolo.pr_caixa_arquivo_consultar";

            return _unidadeDeTrabalho.List<CaixaArquivo>(proc,
                DataHelperParameters.CreateParameter("@cd_caixa_arquivo", codigo),
                DataHelperParameters.CreateParameter("@ds_caixa_arquivo", descricao),
                DataHelperParameters.CreateParameter("@bl_ativo_caixa_arquivo", ativo));
        }

        public CaixaArquivo Obter(int id)
        {
            const string proc = "protocolo.pr_caixa_arquivo_consultar";

            return _unidadeDeTrabalho.Get<CaixaArquivo>(proc,
                DataHelperParameters.CreateParameter("@id_caixa_arquivo", id));
        }

        public int Inserir(CaixaArquivo obj)
        {
            const string proc = "protocolo.pr_caixa_arquivo_incluir";

            return _unidadeDeTrabalho.Get<int>(proc,
                DataHelperParameters.CreateParameter("@cd_caixa_arquivo", obj.Codigo),
                DataHelperParameters.CreateParameter("@ds_caixa_arquivo", obj.Descricao),
                DataHelperParameters.CreateParameter("@bl_ativo_caixa_arquivo", obj.Ativo),
                DataHelperParameters.CreateParameter("@id_movel_divisao", obj.IdMovelDivisao, 0),
                DataHelperParameters.CreateParameter("@id_ua", obj.IdUa),
                DataHelperParameters.CreateParameter("@id_serie_documental", obj.IdSerieDocumental),
                DataHelperParameters.CreateParameter("@dt_criacao", obj.DataOperacao),
                DataHelperParameters.CreateParameter("@id_usuario_criacao", obj.IdUsuarioOperacao),
                DataHelperParameters.CreateParameter("@dt_inicio_caixa", obj.DtInicio),
                DataHelperParameters.CreateParameter("@dt_fim_caixa", obj.DtFim),
                DataHelperParameters.CreateParameter("@id_ua_produtora", obj.IdUAProdutora));
        }

        public int Atualizar(CaixaArquivo obj)
        {
            const string proc = "protocolo.pr_caixa_arquivo_alterar";

            return _unidadeDeTrabalho.Get<int>(proc,
                DataHelperParameters.CreateParameter("@id_caixa_arquivo", obj.Id),
                DataHelperParameters.CreateParameter("@ds_caixa_arquivo", obj.Descricao),
                DataHelperParameters.CreateParameter("@bl_ativo_caixa_arquivo", obj.Ativo),
                DataHelperParameters.CreateParameter("@id_movel_divisao", obj.IdMovelDivisao, 0),
                DataHelperParameters.CreateParameter("@id_ua", obj.IdUa),
                DataHelperParameters.CreateParameter("@id_serie_documental", obj.IdSerieDocumental),
                DataHelperParameters.CreateParameter("@dt_alteracao", obj.DataOperacao),
                DataHelperParameters.CreateParameter("@id_usuario_alteracao", obj.IdUsuarioOperacao),
                DataHelperParameters.CreateParameter("@dt_inicio_caixa", obj.DtInicio),
                DataHelperParameters.CreateParameter("@dt_fim_caixa", obj.DtFim),
                DataHelperParameters.CreateParameter("@id_ua_produtora", obj.IdUAProdutora));
        }

        public void Excluir(CaixaArquivo obj)
        {
            const string proc = "protocolo.pr_caixa_arquivo_excluir";

            _unidadeDeTrabalho.Get<int>(proc,
                DataHelperParameters.CreateParameter("@id_caixa_arquivo", obj.Id));
        }
    }
}