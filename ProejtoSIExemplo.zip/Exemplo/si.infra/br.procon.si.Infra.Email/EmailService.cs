﻿using br.procon.si.Core.Infra.Interfaces;
using System.Threading.Tasks;
using System;
using Microsoft.AspNet.Identity;
using System.Net.Mail;
using System.Net.Configuration;
using System.Linq;
using System.Net;

namespace br.procon.si.Infra.Email
{
    public class EmailService : IEmail ,IIdentityMessageService
    {
        private readonly SmtpSection _smtpSection;
         
        public EmailService(object smtpConfiguration)
        {
            _smtpSection = (SmtpSection)smtpConfiguration;

            if (_smtpSection == null)
                throw new NullReferenceException(
                    "Não foi possível obter as informações do servidor SMTP para envio de e-mail.");

        }
        /// <summary>
        /// Implementacao de uso generico para envio de email retorna uma Task
        /// </summary>
        /// <param name="mensagem"></param>
        /// <returns></returns>
        public async Task EnviarAsync(MensagemEmail mensagem)
        {
            string[] destinatarios = new string[] { mensagem.Destination };
            await EnviarEmailAsync(mensagem.Subject, destinatarios, mensagem.Body, MailPriority.Normal);
        }
        /// <summary>
        /// Implementacao de uso generico para envio de email forma Sincrono
        /// </summary>
        /// <param name="mensagem"></param>
        /// <returns></returns>
        public void Enviar(MensagemEmail mensagem)
        {
            string[] destinatarios = new string[] { mensagem.Destination };
            EnviarEmail(mensagem.Subject, destinatarios, mensagem.Body, MailPriority.Normal);
        }


        /// <summary>
        /// Implementacao para atender infra do AspNet Identity para uso de envio de email
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public async Task SendAsync(IdentityMessage message)
        {
            string[] destinatarios = new string[]{message.Destination};
            await EnviarEmailAsync(message.Subject, destinatarios, message.Body, MailPriority.Normal);
        }

        #region "metodos privados"
        private void EnviarEmail(string assunto, string[] destinatarios, string mensagem, MailPriority prioridade = MailPriority.Normal)
        {
            ValidarParametros(assunto, destinatarios);
            var mailMessage = new MailMessage
            {
                From = new MailAddress(_smtpSection.From),
                Subject = assunto,
                Body = mensagem,
                IsBodyHtml = true,
                Priority = prioridade
            };

            foreach (string adress in destinatarios)
            {
                mailMessage.To.Add(adress);
            }

            using (SmtpClient smtpClient = new SmtpClient
            {
                Host = _smtpSection.Network.Host,
                EnableSsl = _smtpSection.Network.EnableSsl,
                Credentials = new NetworkCredential(_smtpSection.Network.UserName, _smtpSection.Network.Password)
            })
            {
                if (_smtpSection.Network.Port > 0)
                {
                    smtpClient.Port = _smtpSection.Network.Port;
                }
                smtpClient.Send(mailMessage);
            }
        }

        private void ValidarParametros(string assunto, string[] destinatarios)
        {
            if (string.IsNullOrWhiteSpace(assunto))
            {
                throw new ArgumentNullException("subject");
            }
            if (string.IsNullOrWhiteSpace(_smtpSection.From))
            {
                throw new ArgumentNullException("remetente");
            }
            if (!destinatarios.Any<string>())
            {
                throw new ArgumentNullException("destinatarios");
            }
        }


        ///Codigo Legado deve ser validado para os testes de envio de email
        private async Task EnviarEmailAsync(string assunto, string[] destinatarios, string mensagem, MailPriority prioridade = MailPriority.Normal)
        {
            ValidarParametros(assunto, destinatarios);
            var mailMessage = new MailMessage
            {
                From = new MailAddress(_smtpSection.From),
                Subject = assunto,
                Body = mensagem,
                IsBodyHtml = true,
                Priority = prioridade
            };

            foreach (string adress in destinatarios)
            {
                mailMessage.To.Add(adress);
            }

            using (SmtpClient smtpClient = new SmtpClient
            {
                Host = _smtpSection.Network.Host,
                EnableSsl = _smtpSection.Network.EnableSsl,
                Credentials = new NetworkCredential(_smtpSection.Network.UserName, _smtpSection.Network.Password)
            })
            {
                if (_smtpSection.Network.Port > 0)
                {
                    smtpClient.Port = _smtpSection.Network.Port;
                }
                await smtpClient.SendMailAsync(mailMessage);
            }
        }
        #endregion
    }
}
