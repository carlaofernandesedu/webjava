﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using br.procon.si.Infra.Email;
using System.Net;
using System.Net.Configuration;
using System.Net.Mail;
using System.Configuration;
using Microsoft.AspNet.Identity;

namespace br.procon.si.Infra.Tests
{
    [TestClass]
    public class EmailTest
    {
        [TestMethod]
        public void ValidarEnvioMailEnvioGenericoSincrono()
        {
            var smtpsection = (SmtpSection)ConfigurationManager.GetSection("system.net/mailSettings/smtp"); 
            var email = new EmailService(smtpsection);
            var assunto = "assunto generico" + DateTime.Now.ToUniversalTime().ToString();
            email.Enviar(new Core.Infra.Interfaces.MensagemEmail { Body = "corpo email generico", Destination = "si_procon_recebe@redegov.sp.gov.br", Subject = assunto});
        }

        [TestMethod]
        public void ValidarEnvioMailEnvioIdentity()
        {
            var smtpsection = (SmtpSection)ConfigurationManager.GetSection("system.net/mailSettings/smtp");
            var email = new EmailService(smtpsection);
            var dadosEmail = new Microsoft.AspNet.Identity.IdentityMessage();
            dadosEmail.Body = "corpo teste identity";
            dadosEmail.Subject = "assunto teste assincrono identity" + DateTime.Now.ToUniversalTime().ToString();
            dadosEmail.Destination = "si_procon_recebe@redegov.sp.gov.br";
            email.SendAsync(dadosEmail);
        }

        [TestMethod]
        public void ValidarEnvioMailEnvioGenericoAssincrono()
        {
            var smtpsection = (SmtpSection)ConfigurationManager.GetSection("system.net/mailSettings/smtp");
            var email = new EmailService(smtpsection);
            var assunto = "assunto generico assicrono" + DateTime.Now.ToUniversalTime().ToString();
            email.EnviarAsync(new Core.Infra.Interfaces.MensagemEmail { Body = "corpo email generico", Destination = "si_procon_recebe@redegov.sp.gov.br", Subject = assunto });
        }

    }
}
