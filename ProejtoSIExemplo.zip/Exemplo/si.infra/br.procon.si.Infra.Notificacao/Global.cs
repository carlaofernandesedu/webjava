﻿using System.Configuration;

namespace br.procon.si.Infra.Notificacao
{
    internal class Global
    {
        private const string graphBaseUrl = "facebookGraphBaseUrl";
        private const string twitterApiBaseUrl = "twitterApiBaseUrl";

        public static string GraphBaseUrl
        {
            get
            {
                return ConfigurationManager.AppSettings[graphBaseUrl];
            }
        }

        public static string TwitterBaseUrl
        {
            get
            {
                return ConfigurationManager.AppSettings[twitterApiBaseUrl];
            }
        }
    }
}