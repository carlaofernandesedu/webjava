﻿using br.procon.si.Core.Infra;
using br.procon.si.Infra.Notificacao.Facebook;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Infra.Notificacao
{
    public static class AppConfigNotificacao
    {
        private static FacebookNotificationType _tipoNotificacao;
        public static FacebookNotificationType TipoNotificacao
        {
            get { return _tipoNotificacao; }
            set { _tipoNotificacao = value; }
        }

        public static void Inicializar()
        {
            int tipoNotificacaoConfig = String.IsNullOrWhiteSpace(ConfigurationManager.AppSettings["facebookTipoNotificacao"]) ? (int)FacebookNotificationType.Notification : Convert.ToInt32(ConfigurationManager.AppSettings["facebookTipoNotificacao"]);
            _tipoNotificacao = (FacebookNotificationType)tipoNotificacaoConfig;
        }
    }
}