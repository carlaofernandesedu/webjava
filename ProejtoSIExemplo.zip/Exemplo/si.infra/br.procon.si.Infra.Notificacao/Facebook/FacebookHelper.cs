﻿using br.procon.si.Infra.Notificacao.Common.Oauth;
using br.procon.si.Infra.Notificacao.Facebook.Objects;
using System;
using System.Collections.Generic;

namespace br.procon.si.Infra.Notificacao.Facebook
{
    public class FacebookHelper
    {
        private FacebookManager manager = new FacebookManager();

        private Dictionary<FacebookEndpoints, FacebookRequest> EndPoints { get; set; }

        public string AppId { get; private set; }

        public string AppSecret { get; set; }

        public FacebookHelper(string appId, string appSecret)
        {
            this.AppId = appId;
            this.AppSecret = appSecret;

            EndPoints = new Dictionary<FacebookEndpoints, FacebookRequest>();

            EndPoints.Add(FacebookEndpoints.AccessToken, new FacebookRequest { Caminho = "oauth/access_token" });
            EndPoints.Add(FacebookEndpoints.Feed, new FacebookRequest { Caminho = "feed" });
            EndPoints.Add(FacebookEndpoints.Notifications, new FacebookRequest { Caminho = "notifications" });

            AppConfigNotificacao.Inicializar();
        }

        public AccessTokenResponse ObterToken()
        {
            try
            {
                var request = EndPoints[FacebookEndpoints.AccessToken];

                var resposta = manager.ObterToken(request, AppId, AppSecret);

                return resposta;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public FacebookBaseObject Postar(string userId, string texto, string url)
        {
            switch (AppConfigNotificacao.TipoNotificacao)
            {
                case FacebookNotificationType.Notification:
                    return Notificar(userId, texto, url);
                case FacebookNotificationType.Timeline:
                default:
                    return PostarNaLinhaDoTempo(userId, texto, url);
            }
        }

        public FacebookBaseObject PostarNaLinhaDoTempo(string userId, string texto, string url)
        {
            var accessToken = ObterToken().AccessToken;

            var request = EndPoints[FacebookEndpoints.Feed];
            request.UserId = userId;
            request.AccessToken = accessToken;

            FacebookPostagem postagem = new FacebookPostagem();
            postagem.Mensagem = texto;
            postagem.Link = url;

            var postData = postagem.GetPostData();

            FacebookBaseObject response = manager.EnviarDados<FacebookBaseObject>(request, postData);

            return response;
        }

        public FacebookBaseObject Notificar(string userId, string texto, string url)
        {
            var accessToken = ObterToken().AccessToken;

            var request = EndPoints[FacebookEndpoints.Notifications];
            request.UserId = userId;
            request.AccessToken = accessToken;

            FacebookNotificacao postagem = new FacebookNotificacao();
            postagem.Mensagem = texto;
            postagem.Link = url;

            var postData = postagem.GetQueryParameters();

            request.QueryParameters = postData;

            FacebookBaseObject response = manager.ObterDados<FacebookBaseObject>(request);

            return response;
        }
    }
}