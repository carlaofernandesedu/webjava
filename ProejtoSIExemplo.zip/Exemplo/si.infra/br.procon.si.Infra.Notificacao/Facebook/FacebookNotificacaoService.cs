﻿using br.procon.si.Core.Infra.Interfaces;
using br.procon.si.Infra.Notificacao.Facebook;
using System;

namespace br.procon.si.Infra.Notificacao
{
    public class FacebookNotificacaoService : INotificacaoProviderService
    {
        private FacebookHelper helper;

        public FacebookNotificacaoService(string appId, string appSecret)
        {
            helper = new FacebookHelper(appId, appSecret);
        }

        public void Enviar(string destinatario, string mensagem, string url)
         {
            if (!destinatario.Contains("@"))
            {
                var retorno = helper.Postar(destinatario, mensagem, url); 
            }
            else
            {
                throw new Exception(String.Format("Notificação por Facebook Incorreta: {0} - {1} - {2}", destinatario, mensagem, url));
            }
        }
    }
}