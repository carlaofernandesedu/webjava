﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Infra.Notificacao.Facebook
{
    public enum FacebookNotificationType
    {
        Timeline = 1,
        Notification = 2
    }
}
