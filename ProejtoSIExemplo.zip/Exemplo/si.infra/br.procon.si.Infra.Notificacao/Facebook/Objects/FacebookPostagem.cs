﻿using System;
using System.Runtime.Serialization;
using System.Text;

namespace br.procon.si.Infra.Notificacao.Facebook.Objects
{
    [DataContract]
    public class FacebookPostagem
    {
        [DataMember(Name = "message", EmitDefaultValue = true, IsRequired = false)]
        public string Mensagem { get; set; }

        [DataMember(Name = "link", EmitDefaultValue = true, IsRequired = false)]
        public string Link { get; set; }

        [DataMember(Name = "place", EmitDefaultValue = true, IsRequired = false)]
        public string Place { get; set; }

        [DataMember(Name = "tags", EmitDefaultValue = true, IsRequired = false)]
        public string Tags { get; set; }

        internal string GetPostData()
        {
            StringBuilder postData = new StringBuilder();
            postData.Append("message=").Append(Mensagem);

            if (!string.IsNullOrEmpty(Link))
                postData.Append("&link=").Append(Link.ToString());

            if (!string.IsNullOrEmpty(Place))
                postData.Append("&place=").Append(Place);

            if (!string.IsNullOrEmpty(Tags))
                postData.Append("&tags=").Append(Tags);

            return postData.ToString();
        }
    }
}