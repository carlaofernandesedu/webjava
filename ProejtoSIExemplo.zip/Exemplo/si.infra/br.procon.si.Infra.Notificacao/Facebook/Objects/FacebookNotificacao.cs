﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Runtime.Serialization;
using System.Text;

namespace br.procon.si.Infra.Notificacao.Facebook.Objects
{
    [DataContract]
    public class FacebookNotificacao
    {
        [DataMember(Name = "template", EmitDefaultValue = true, IsRequired = false)]
        public string Mensagem { get; set; }

        [DataMember(Name = "href", EmitDefaultValue = true, IsRequired = false)]
        public string Link { get; set; }

        [DataMember(Name = "pretty", EmitDefaultValue = true, IsRequired = false)]
        public bool Pretty { get; set; }

        [DataMember(Name = "sdk", EmitDefaultValue = true, IsRequired = false)]
        public string Sdk { get; set; }

        [DataMember(Name = "method", EmitDefaultValue = true, IsRequired = false)]
        public string Method { get; set; }

        public FacebookNotificacao()
        {
            Pretty = false;
            Sdk = "joey";
            Method = "post";
        }

        internal List<string> GetQueryParameters()
        {
            List<string> parametros = new List<string>();
            parametros.Add("template=" + WebUtility.UrlEncode(Mensagem));
            parametros.Add("pretty=" + Convert.ToInt16(Pretty));
            parametros.Add("sdk=" + Sdk);
            parametros.Add("method=" + Method);

            if (!string.IsNullOrEmpty(Link))
                parametros.Add("href=" + Link.ToString());

            return parametros;
        }
    }
}