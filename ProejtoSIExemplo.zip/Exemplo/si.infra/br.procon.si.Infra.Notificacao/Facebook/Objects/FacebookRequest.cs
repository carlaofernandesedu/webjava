﻿using System.Collections.Generic;
namespace br.procon.si.Infra.Notificacao.Facebook.Objects
{
    public class FacebookRequest
    {
        public string UserId { get; set; }

        public string Caminho { get; set; }

        public string AccessToken { get; set; }

        public List<string> QueryParameters { get; set; }

        public FacebookRequest()
        {
            QueryParameters = new List<string>();
        }

        public FacebookRequest(string userId, string accessToken)
        {
            this.UserId = userId;
            this.AccessToken = accessToken;
            QueryParameters = new List<string>();
        }

        public FacebookRequest(string nodeId, string caminho, string accessToken)
        {
            this.AccessToken = accessToken;
            this.UserId = nodeId;
            this.Caminho = caminho;
            QueryParameters = new List<string>();
        }
    }
}