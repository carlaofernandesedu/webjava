﻿namespace br.procon.si.Infra.Notificacao.Facebook
{
    public enum FacebookEndpoints
    {
        AccessToken,
        Feed,
        Notifications
    }
}