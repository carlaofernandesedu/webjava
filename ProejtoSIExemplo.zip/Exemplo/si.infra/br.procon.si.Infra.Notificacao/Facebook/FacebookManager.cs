﻿using br.procon.si.Infra.Notificacao.Common;
using br.procon.si.Infra.Notificacao.Common.Oauth;
using br.procon.si.Infra.Notificacao.Facebook.Objects;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace br.procon.si.Infra.Notificacao.Facebook
{
    public class FacebookManager
    {
        public AccessTokenResponse ObterToken(FacebookRequest request, string appId, string appSecret)
        {
            AccessTokenResponse response;

            try
            {
                RequestHandler handler = new RequestHandler();

                var uri = CriarUriToken(request, appId, appSecret);
                response = handler.GetData<AccessTokenResponse>(uri);
            }
            catch (WebException ex)
            {
                LogHelper.Logar("FacebookManager-EXCEPTION: " + ex.ToString());
                throw new Exception(ex.Message, ex);
            }
            catch (Exception ex)
            {
                LogHelper.Logar("FacebookManager-EXCEPTION: " + ex.ToString());
                throw new Exception("Erro ao conectar ao Facebook", ex);
            }
            return response;
        }

        public T ObterDados<T>(FacebookRequest request) where T : class
        {
            T fbObject = default(T);
            try
            {
                RequestHandler handler = new RequestHandler();
                fbObject = handler.GetData<T>(CriarUri(request));
            }
            catch (WebException ex)
            {
                throw new Exception(ex.Message, ex);
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao conectar ao Facebook", ex);
            }
            return fbObject;
        }

        public T EnviarDados<T>(FacebookRequest request, string postData)
        {
            T retorno = default(T);
            try
            {
                RequestHandler handler = new RequestHandler();
                var uri = CriarUri(request);
                LogHelper.Logar("URI: " + uri.ToString());

                retorno = handler.PostData<T>(uri, postData);
            }
            catch (WebException ex)
            {
                throw new Exception(ex.Message, ex);
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao conectar ao Facebook", ex);
            }
            return retorno;
        }

        private Uri CriarUri(FacebookRequest request)
        {
            if (request == null)
                return null;

            StringBuilder uriString = new StringBuilder();
            uriString.Append(Global.GraphBaseUrl);

            List<string> urlParameters = new List<string>();

            if (!string.IsNullOrEmpty(request.UserId))
                uriString.AppendFormat("/{0}", request.UserId);

            if (!string.IsNullOrEmpty(request.Caminho))
                uriString.AppendFormat("/{0}", request.Caminho);

            uriString.Append("?");

            if (!string.IsNullOrEmpty(request.AccessToken))
                urlParameters.Add(string.Format("access_token={0}", request.AccessToken));

            if (request.QueryParameters.Count > 0)
            {
                urlParameters.AddRange(request.QueryParameters);
            }

            var joinedParameters = string.Join("&", urlParameters);

            uriString.Append("&").Append(joinedParameters);

            LogHelper.Logar("FacebookManager.CriarUri-URI: " + uriString.ToString());
            return new Uri(uriString.ToString());
        }

        private Uri CriarUriToken(FacebookRequest request, string appId, string appSecret)
        {
            if (request == null)
                return null;

            StringBuilder uriString = new StringBuilder();
            uriString.Append(Global.GraphBaseUrl);

            List<string> urlParameters = new List<string>();

            if (!string.IsNullOrEmpty(request.UserId))
                uriString.AppendFormat("/{0}", request.UserId);

            if (!string.IsNullOrEmpty(request.Caminho))
                uriString.AppendFormat("/{0}", request.Caminho);

            uriString.Append("?");
            urlParameters.Add("grant_type=client_credentials");
            urlParameters.Add("client_id=" + appId + "&client_secret=" + appSecret);

            uriString.Append("&").Append(string.Join("&", urlParameters));


            LogHelper.Logar("FacebookManager.CriarUriToken-URI: " + uriString.ToString());
            return new Uri(uriString.ToString());
        }
    }
}