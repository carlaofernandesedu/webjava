﻿using System.Runtime.Serialization;

namespace br.procon.si.Infra.Notificacao.Facebook
{
    [DataContract]
    public class FacebookBaseObject
    {
        [DataMember(Name = "id", IsRequired = false, EmitDefaultValue = true)]
        public string Id { get; set; }
    }
}