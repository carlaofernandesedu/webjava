﻿using br.procon.si.Core.Data.ADO;
using br.procon.si.Core.Domain.Interfaces;
using br.procon.si.Core.Infra.Interfaces;
using System;

namespace br.procon.si.Infra.Notificacao
{
    public class NotificacaoService : INotificacaoService, IDisposable
    {
        private DataHelperUnitOfWork _unidadeDeTrabalho;

        public NotificacaoService(string connectionString)
        {
            _unidadeDeTrabalho = new DataHelperUnitOfWork(connectionString);
        }

        public NotificacaoService(IUnitOfWork unidadeDeTrabalho)
        {
            _unidadeDeTrabalho = (DataHelperUnitOfWork)unidadeDeTrabalho;
        }

        public void Criar(int idFormaNotificacao, string nomeDestinatario, string destinatario, string assunto, string mensagem, int idUsuarioCriacao)
        {
            const string sql = "atendimento.pr_notificacao_incluir";

            var paramIdFormaNotificacao = DataHelperParameters.CreateParameter("@id_forma_notificacao", idFormaNotificacao);
            var paramNomeDestinatario = DataHelperParameters.CreateParameter("@no_destinatario", nomeDestinatario);
            var paramDestinatario = DataHelperParameters.CreateParameter("@ds_destinatario", destinatario);
            var paramAssunto = DataHelperParameters.CreateParameter("@ds_assunto", assunto);
            var paramMensagem = DataHelperParameters.CreateParameter("@ds_mensagem", mensagem);
            var paramDataCriacao = DataHelperParameters.CreateParameter("@dt_criacao", DateTime.Now);
            var paramIdUsuarioCriacao = DataHelperParameters.CreateParameter("@id_usuario_criacao", idUsuarioCriacao);

            _unidadeDeTrabalho.Get<int>(sql, paramIdFormaNotificacao, paramNomeDestinatario, paramDestinatario, paramAssunto, paramMensagem, paramDataCriacao, paramIdUsuarioCriacao);
        }

        public void Atualizar(int idNotificacao, int idFormaNotificacao, string nomeDestinatario, string destinatario, string assunto, string mensagem, bool enviado, DateTime? dataEnvio, DateTime? dataAlteracao, int? idUsuarioAlteracao, int numeroTentativas)
        {
            const string sql = "atendimento.pr_notificacao_alterar";

            var paramIdNotificacao = DataHelperParameters.CreateParameter("@id_notificacao", idNotificacao);
            var paramIdFormaNotificacao = DataHelperParameters.CreateParameter("@id_forma_notificacao", idFormaNotificacao);
            var paramNomeDestinatario = DataHelperParameters.CreateParameter("@no_destinatario", nomeDestinatario);
            var paramDestinatario = DataHelperParameters.CreateParameter("@ds_destinatario", destinatario);
            var paramAssunto = DataHelperParameters.CreateParameter("@ds_assunto", assunto);
            var paramMensagem = DataHelperParameters.CreateParameter("@ds_mensagem", mensagem);
            var paramBlEnviado = DataHelperParameters.CreateParameter("@bl_enviado", enviado);
            var paramDataEnvio = DataHelperParameters.CreateParameter("@dt_envio", dataEnvio);
            var paramDataAlteracao = DataHelperParameters.CreateParameter("@dt_alteracao", dataAlteracao);
            var paramIdUsuarioAlteracao = DataHelperParameters.CreateParameter("@id_usuario_alteracao", idUsuarioAlteracao, 0);
            var paramnrTentativas = DataHelperParameters.CreateParameter("@nr_tentativas_envio", numeroTentativas, 0);

            _unidadeDeTrabalho.Get<int>(sql, paramIdNotificacao, paramIdFormaNotificacao, paramNomeDestinatario, paramDestinatario, paramAssunto, paramMensagem, paramBlEnviado, paramDataEnvio, paramDataAlteracao, paramIdUsuarioAlteracao, paramnrTentativas);
        }

        public System.Collections.Generic.IEnumerable<Core.Infra.Models.Notificacao> ObterPendentes()
        {
            return Obter(new Core.Infra.Models.Notificacao(), false);
        }
        public System.Collections.Generic.IEnumerable<Core.Infra.Models.Notificacao> Obter(Core.Infra.Models.Notificacao filtro, bool? enviadas)
        {
            const string sql = "atendimento.pr_notificacao_consultar";

            var paramIdNotificacao = DataHelperParameters.CreateParameter("@id_notificacao", filtro.Id, 0);
            var paramIdFormaNotificacao = DataHelperParameters.CreateParameter("@id_forma_notificacao", filtro.IdFormaNotificacao, 0);
            var paramNomeDestinatario = DataHelperParameters.CreateParameter("@no_destinatario", filtro.NomeDestinatario);
            var paramDestinatario = DataHelperParameters.CreateParameter("@ds_destinatario", filtro.Destinatario);
            var paramAssunto = DataHelperParameters.CreateParameter("@ds_assunto", filtro.Assunto);
            var paramMensagem = DataHelperParameters.CreateParameter("@ds_mensagem", filtro.Mensagem);
            var paramBlEnviado = DataHelperParameters.CreateParameter("@bl_enviado", enviadas);
            var paramDataEnvio = DataHelperParameters.CreateParameter("@dt_envio", filtro.DataEnvio);
            var paramDataCriacao = DataHelperParameters.CreateParameter("@dt_criacao", filtro.DataCriacao, DateTime.MinValue);
            var paramIdUsuarioCriacao = DataHelperParameters.CreateParameter("@id_usuario_criacao", filtro.IdUsuarioCriacao, 0);
            var paramDataAlteracao = DataHelperParameters.CreateParameter("@dt_alteracao", filtro.DataAlteracao);
            var paramIdUsuarioAlteracao = DataHelperParameters.CreateParameter("@id_usuario_alteracao", filtro.UsuarioAlteracao);

            var resultado = _unidadeDeTrabalho.List<Core.Infra.Models.Notificacao>(sql, paramIdNotificacao, paramIdFormaNotificacao, paramNomeDestinatario, paramDestinatario, paramAssunto, paramMensagem, paramBlEnviado, paramDataEnvio, paramDataCriacao, paramIdUsuarioCriacao, paramDataAlteracao, paramIdUsuarioAlteracao);

            return resultado;
        }

        public Core.Infra.Models.Notificacao Obter(int id)
        {
            const string sql = "atendimento.pr_notificacao_consultar";

            var paramIdNotificacao = DataHelperParameters.CreateParameter("@id_notificacao", id);

            var resultado = _unidadeDeTrabalho.Get<Core.Infra.Models.Notificacao>(sql, paramIdNotificacao);

            return resultado;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        ~NotificacaoService()
        {
            Dispose(false);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_unidadeDeTrabalho != null)
                {
                    _unidadeDeTrabalho.Dispose();
                    _unidadeDeTrabalho = null;
                }
            }
        }
    }
}