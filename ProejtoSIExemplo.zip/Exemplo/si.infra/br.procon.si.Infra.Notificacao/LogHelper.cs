﻿using br.procon.si.Core.Infra;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Infra.Notificacao
{
    public static class LogHelper
    {
        public static void Logar(string msg)
        {
            msg = "Notificação: " + msg;

            var acao = new br.procon.si.Core.Domain.Events.AcaoRegistradaEvent(AppConfig.IdUsuarioNotificacao, msg);
            acao.Aplicacao = "Consumidor";
            br.procon.si.Core.Domain.Events.DomainEvent.Raise<br.procon.si.Core.Domain.Events.AcaoRegistradaEvent>(acao);
        }
    }
}
