﻿using br.procon.si.Core.Infra;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Security.Cryptography;
using System.Text;

namespace br.procon.si.Infra.Notificacao.Common
{
    public class RequestHandler
    {
        private WebRequest GetWebRequest(Uri url)
        {
            WebRequest webRequest = WebRequest.Create(url);
            //TODO: Para buscar os dados do arquivo de configuracoes
            AppConfig.Inicializar();            
            if (!String.IsNullOrEmpty(AppConfig.Proxy))
            {
                var userproxy = ObterProxy(AppConfig.Proxy);
                if (userproxy != null)
                {
                    LogHelper.Logar(String.Format("Usando proxy {0}", userproxy.GetProxy(url).AbsoluteUri));
                    webRequest.Proxy = userproxy;
                }
                else
                {
                    LogHelper.Logar("Usando proxy padrão");
                }
            }
            else
            {
                LogHelper.Logar("Sem proxy configurado");
            }

            return webRequest;
        }

        internal TObject GetData<TObject>(Uri url) where TObject : class
        {
            return GetData<TObject>(url, null);
        }

        internal TObject GetData<TObject>(Uri url, Dictionary<string, string> headers) where TObject : class
        {
            TObject responseData = default(TObject);
            WebRequest webRequest = GetWebRequest(url);

            if (headers != null)
            {
                foreach (var header in headers)
                {
                    webRequest.Headers.Add(header.Key, header.Value);
                }
            }

            using (WebResponse webResponse = webRequest.GetResponse())
            {
                if (webResponse != null)
                {
                    DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(TObject), "root");

                    Stream stream = webResponse.GetResponseStream();

                    responseData = (TObject)serializer.ReadObject(stream);
                }
            }
            return responseData;
        }

        internal ReturnObject PostData<ReturnObject>(Uri url, string postData)
        {
            return PostData<ReturnObject>(url, postData, null);
        }

        internal ReturnObject PostData<ReturnObject>(Uri url, string postData, Dictionary<string, string> headers)
        {
            ReturnObject responseData = default(ReturnObject);
            WebRequest webRequest = GetWebRequest(url);
            webRequest.Method = "POST";
            webRequest.ContentType = "application/x-www-form-UrlEncoded";

            if (headers != null)
            {
                foreach (var header in headers)
                {
                    webRequest.Headers.Add(header.Key, header.Value);
                }
            }

            byte[] buffer = null;
            if (!string.IsNullOrEmpty(postData))
            {
                buffer = Encoding.UTF8.GetBytes(postData);
                webRequest.ContentLength = buffer.Length;
            }

            try
            {
                LogarRequest(webRequest);

                using (Stream stream = webRequest.GetRequestStream())
                {
                    if (buffer != null)
                    {
                        stream.Write(buffer, 0, buffer.Length);
                    }


                    #region Log provisório  // TODO remover region inteira
                    var log = Newtonsoft.Json.JsonConvert.SerializeObject(webRequest, Newtonsoft.Json.Formatting.Indented);
                    var logPostData = Newtonsoft.Json.JsonConvert.SerializeObject(postData, Newtonsoft.Json.Formatting.Indented);

                    LogHelper.Logar(String.Format("Request: {0} - {1}", log, logPostData));
                    #endregion

                    using (WebResponse webResponse = webRequest.GetResponse())
                    {
                        if (webResponse != null)
                        {
                            DataContractJsonSerializer serializer =
                                new DataContractJsonSerializer(typeof(ReturnObject), "root");
                            responseData = (ReturnObject)serializer.ReadObject(webResponse.GetResponseStream());
                        }
                    }
                }
            }
            catch (WebException webEx)
            {
                LogarException(webEx);

                throw new WebException(webEx.Message, webEx);
            }
            catch (Exception)
            {
                throw;
            }
            return responseData;
        }


        private static IWebProxy ObterProxy(string nomeproxy)
        {
            IWebProxy proxy = null;
            try
            {
                if (nomeproxy == "[local]")
                {

                    IWebProxy ieproxy = WebRequest.DefaultWebProxy;
                    if (ieproxy != null && ((WebProxy)ieproxy).Address.AbsoluteUri != String.Empty)
                    {
                        proxy = ieproxy;
                    }
                }
                else
                {
                    proxy = new WebProxy(nomeproxy);
                }
            }
            catch { }
            return proxy;
        }

        private static void LogarException(WebException webEx)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(webEx.Message);

            sb.AppendLine();
            sb.AppendLine("RESPONSE: ");
            sb.AppendLine();

            sb.AppendLine(string.Format("Status: {0}", webEx.Status));

            if (null != webEx.Response)
            {
                HttpWebResponse response = (HttpWebResponse)webEx.Response;

                sb.AppendLine(string.Format("Status Code: {0} {1}", (int)response.StatusCode, response.StatusDescription));
                if (0 != webEx.Response.ContentLength)
                {
                    using (var stream = webEx.Response.GetResponseStream())
                    {
                        if (null != stream)
                        {
                            using (var reader = new StreamReader(stream))
                            {
                                sb.AppendLine(string.Format("Response: {0}", reader.ReadToEnd()));
                            }
                        }
                    }
                }
            }

            LogHelper.Logar("EXCEPTION: " + sb.ToString());
        }

        private static void LogarRequest(WebRequest webRequest)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine();
            sb.AppendLine("REQUEST: ");
            sb.AppendLine();

            sb.AppendLine(string.Format("URL: {0} {1}", webRequest.Method, webRequest.RequestUri));
            sb.AppendLine("Headers:");
            foreach (string header in webRequest.Headers)
            {
                sb.AppendLine(header + ": " + webRequest.Headers[header]);
            }

            LogHelper.Logar(sb.ToString());
        }
    }
}