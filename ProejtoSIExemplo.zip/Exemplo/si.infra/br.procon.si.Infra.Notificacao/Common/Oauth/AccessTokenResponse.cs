﻿using br.procon.si.Infra.Notificacao.Common.Base;
using System.Runtime.Serialization;

namespace br.procon.si.Infra.Notificacao.Common.Oauth
{
    [DataContract]
    public class AccessTokenResponse : BaseObject
    {
        [DataMember(Name = "access_token", EmitDefaultValue = true, IsRequired = false)]
        public string AccessToken { get; set; }

        [DataMember(Name = "token_type", EmitDefaultValue = true, IsRequired = false)]
        public string TokenType { get; set; }
    }
}