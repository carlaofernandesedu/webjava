﻿using System.Runtime.Serialization;

namespace br.procon.si.Infra.Notificacao.Common.Base
{
    [DataContract]
    public class BaseObject
    {
        [DataMember(Name = "id", IsRequired = false, EmitDefaultValue = true)]
        public string Id { get; set; }
    }
}