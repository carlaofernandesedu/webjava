﻿using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Infra.Notificacao.Common
{
    public class ClaimsVO
    {
        [Column("claimtype")]
        public string ClaimType { get; set; }

        [Column("claimvalue")]
        public string ClaimValue { get; set; }
    }
}