﻿using br.procon.si.Core.Infra.Interfaces;
using System;
using System.Net;
using System.Net.Configuration;
using System.Net.Mail;

namespace br.procon.si.Infra.Notificacao
{
    public class EmailNotificacaoService : INotificacaoProviderService
    {
        private SmtpSection _smtpSection;

        public EmailNotificacaoService(SmtpSection smtpConfiguration)
        {
            _smtpSection = smtpConfiguration;

            if (_smtpSection == null)
                throw new NullReferenceException(
                    "Não foi possível obter as informações do servidor SMTP para envio de e-mail.");
        }

        public void Enviar(string destinatario, string mensagem, string assunto)
        {
            ValidarParametros(assunto, destinatario, mensagem);
            var mailMessage = new MailMessage
            {
                From = new MailAddress(_smtpSection.From),
                Subject = assunto,
                Body = mensagem,
                IsBodyHtml = true,
                Priority = MailPriority.Normal
            };

            mailMessage.To.Add(destinatario);

            using (SmtpClient smtpClient = new SmtpClient
            {
                Host = _smtpSection.Network.Host,
                EnableSsl = _smtpSection.Network.EnableSsl,
                Credentials = new NetworkCredential(_smtpSection.Network.UserName, _smtpSection.Network.Password)
            })
            {
                if (_smtpSection.Network.Port > 0)
                {
                    smtpClient.Port = _smtpSection.Network.Port;
                }
                smtpClient.Send(mailMessage);
            }
        }

        private void ValidarParametros(string assunto, string destinatario, string mensagem)
        {
            if (string.IsNullOrWhiteSpace(assunto))
            {
                throw new ArgumentNullException("subject");
            }
            if (string.IsNullOrWhiteSpace(_smtpSection.From))
            {
                throw new ArgumentNullException("remetente");
            }
            if (string.IsNullOrWhiteSpace(destinatario))
            {
                throw new ArgumentNullException("destinatario");
            }
        }
    }
}