﻿using System.Collections.Generic;
using System.Net;
using System.Runtime.Serialization;
using System.Text;

namespace br.procon.si.Infra.Notificacao.Twitter.Objects
{
    [DataContract]
    public class TwitterPostagem
    {
        [DataMember(Name = "status", EmitDefaultValue = true, IsRequired = false)]
        public string Mensagem { get; set; }

        internal string GetPostData()
        {
            StringBuilder postData = new StringBuilder();
            postData.Append("status=").Append(WebUtility.UrlEncode(Mensagem));

            return postData.ToString();
        }

        internal List<string> GetQueryParameters()
        {
            List<string> parametros = new List<string>();

            if (!string.IsNullOrEmpty(Mensagem))
                parametros.Add("status=" + WebUtility.UrlEncode(Mensagem));

            return parametros;
        }
    }
}