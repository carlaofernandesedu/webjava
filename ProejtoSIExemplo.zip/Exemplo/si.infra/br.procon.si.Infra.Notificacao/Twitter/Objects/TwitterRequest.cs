﻿using System.Collections.Generic;
namespace br.procon.si.Infra.Notificacao.Twitter.Objects
{
    public class TwitterRequest
    {
        public string UserId { get; set; }

        public string Caminho { get; set; }

        public TwitterAccessToken Token { get; set; }

        public List<string> QueryParameters { get; set; }

        public TwitterRequest()
        {
            QueryParameters = new List<string>();
        }

        public TwitterRequest(string nodeId, TwitterAccessToken accessToken)
        {
            this.UserId = nodeId;
            this.Token = accessToken;
            QueryParameters = new List<string>();
        }

        public TwitterRequest(string nodeId, string edgeName, TwitterAccessToken accessToken)
        {
            this.Token = accessToken;
            this.UserId = nodeId;
            this.Caminho = edgeName;
            QueryParameters = new List<string>();
        }
    }
}