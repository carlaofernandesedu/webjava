﻿namespace br.procon.si.Infra.Notificacao.Twitter.Objects
{
    public class TwitterAccessToken
    {
        public string AccessToken { get; set; }

        public string AccessTokenSecret { get; set; }
    }
}