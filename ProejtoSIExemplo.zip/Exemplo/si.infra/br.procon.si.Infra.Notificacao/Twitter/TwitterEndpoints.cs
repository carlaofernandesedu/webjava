﻿namespace br.procon.si.Infra.Notificacao.Twitter
{
    public enum TwitterEndpoints
    {
        AccessToken,
        VerifyCredentials,
        Tweet
    }
}