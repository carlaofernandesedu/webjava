﻿using br.procon.si.Infra.Notificacao.Common;
using br.procon.si.Infra.Notificacao.Twitter.Objects;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;

namespace br.procon.si.Infra.Notificacao.Twitter
{
    public class TwitterManager : IDisposable
    {
        private HMACSHA1 sigHasher;

        public TObject ObterDados<TObject>(TwitterRequest request) where TObject : class
        {
            TObject fbObject = default(TObject);
            try
            {
                RequestHandler handler = new RequestHandler();
                fbObject = handler.GetData<TObject>(CriarUri(request));
            }
            catch (WebException ex)
            {
                throw new Exception(ex.Message, ex);
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao conectar ao Twitter", ex);
            }
            return fbObject;
        }

        public ReturnObject EnviarDados<ReturnObject>(string appConsumerKey, string appSecret, TwitterRequest request, string postData)
        {
            ReturnObject retorno = default(ReturnObject);
            try
            {
                var compositeKey = string.Concat(Uri.EscapeDataString(appSecret), "&", Uri.EscapeDataString(request.Token.AccessTokenSecret));

                sigHasher = new HMACSHA1(new ASCIIEncoding().GetBytes(compositeKey));

                var uri = CriarUri(request);

                RequestHandler handler = new RequestHandler();
                var oAuthHeader = GerarHeader(request, appConsumerKey, appSecret);

                var headers = new Dictionary<string, string>();
                headers.Add("Authorization", oAuthHeader);

                retorno = handler.PostData<ReturnObject>(uri, postData, headers);


                //var requestt = GerarRequest(request, postData, request.Token.AccessToken, request.Token.AccessTokenSecret, appConsumerKey, appSecret);
                //WebResponse response = requestt.GetResponse();
                //return JsonConvert.DeserializeObject<ReturnObject>(new StreamReader(response.GetResponseStream()).ReadToEnd());
            }
            catch (WebException ex)
            {
                throw new Exception(ex.Message, ex);
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao conectar ao Twitter", ex);
            }
            return retorno;
        }

        private Uri CriarUri(TwitterRequest request)
        {
            if (request == null)
                return null;

            StringBuilder uriString = new StringBuilder();
            uriString.Append(Global.TwitterBaseUrl);

            List<string> urlParameters = new List<string>();

            if (!string.IsNullOrEmpty(request.Caminho))
                uriString.AppendFormat("/{0}", request.Caminho);

            if (request.QueryParameters.Any())
            {
                uriString.Append("?");

                if (request.QueryParameters.Count > 0)
                {
                    urlParameters.AddRange(request.QueryParameters);
                }

                var joinedParameters = string.Join("&", urlParameters);

                uriString.Append("&").Append(joinedParameters); 
            }

            LogHelper.Logar("TwitterManager.CriarUri-URI: " + uriString.ToString());
            return new Uri(uriString.ToString());
        }

        private string GerarHeader(TwitterRequest request, string appConsumerKey, string accessToken)
        {
            var data = new Dictionary<string, string>();

            Int32 timestamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            var oauth_nonce = Convert.ToBase64String(new ASCIIEncoding().GetBytes(DateTime.Now.Ticks.ToString()));

            data.Add("oauth_consumer_key", appConsumerKey);
            data.Add("oauth_nonce", oauth_nonce);
            data.Add("oauth_signature_method", "HMAC-SHA1");
            data.Add("oauth_timestamp", timestamp.ToString());
            data.Add("oauth_token", request.Token.AccessToken);
            data.Add("oauth_version", "1.0");

            var signature = GenerateSignature(Global.TwitterBaseUrl + "/" + request.Caminho, data);

            data.Add("oauth_signature", signature);

            var oAuthHeader = GenerateOAuthHeader(data);

            return oAuthHeader;
        }

        private string GenerateSignature(string url, Dictionary<string, string> data)
        {
            var data2 = data
                    .Union(data)
                    .Select(kvp => string.Format("{0}={1}", Uri.EscapeDataString(kvp.Key), Uri.EscapeDataString(kvp.Value)))
                    .OrderBy(s => s);

            var sigString = string.Join("&",data2);

            var fullSigData = string.Format(
                "{0}&{1}&{2}",
                "POST",
                Uri.EscapeDataString(url),
                Uri.EscapeDataString(sigString.ToString())
            );

            return Convert.ToBase64String(sigHasher.ComputeHash(new ASCIIEncoding().GetBytes(fullSigData.ToString())));
        }

        private string GenerateOAuthHeader(Dictionary<string, string> data)
        {
            var data2 = data
                    .Where(kvp => kvp.Key.StartsWith("oauth_"))
                    .Select(kvp => string.Format("{0}=\"{1}\"", Uri.EscapeDataString(kvp.Key), Uri.EscapeDataString(kvp.Value)))
                    .OrderBy(s => s);

            var result = "OAuth " + string.Join(",",data2);

            return result;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        ~TwitterManager()
        {
            Dispose(false);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (sigHasher != null)
                {
                    sigHasher.Dispose();
                    sigHasher = null;
                }
            }
        }


        ///// <summary>
        ///// Método 2 de geração de request
        ///// </summary>
        ///// <param name="trequest"></param>
        ///// <param name="postdata"></param>
        ///// <param name="oauth_token"></param>
        ///// <param name="oauth_token_secret"></param>
        ///// <param name="oauth_consumer_key"></param>
        ///// <param name="oauth_consumer_secret"></param>
        ///// <returns></returns>
        //private HttpWebRequest GerarRequest(TwitterRequest trequest, string postdata, string oauth_token, string oauth_token_secret, string oauth_consumer_key, string oauth_consumer_secret)
        //{
        //    // oauth implementation details
        //    var oauth_version = "1.0";
        //    var oauth_signature_method = "HMAC-SHA1";

        //    // unique request details
        //    var oauth_nonce = Convert.ToBase64String(
        //        new ASCIIEncoding().GetBytes(DateTime.Now.Ticks.ToString()));
        //    var timeSpan = DateTime.UtcNow
        //        - new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);
        //    var oauth_timestamp = Convert.ToInt64(timeSpan.TotalSeconds).ToString();

        //    var resource_url = CriarUri(trequest).ToString();
        //    var request_query = postdata;
        //    // create oauth signature
        //    var baseFormat = "oauth_consumer_key={0}&oauth_nonce={1}&oauth_signature_method={2}" +
        //                    "&oauth_timestamp={3}&oauth_token={4}&oauth_version={5}";

        //    var baseString = string.Format(baseFormat,
        //                                oauth_consumer_key,
        //                                oauth_nonce,
        //                                oauth_signature_method,
        //                                oauth_timestamp,
        //                                oauth_token,
        //                                oauth_version
        //                                );

        //    baseString = string.Concat("GET&", Uri.EscapeDataString(resource_url) + "&" + Uri.EscapeDataString(request_query), "%26", Uri.EscapeDataString(baseString));

        //    var compositeKey = string.Concat(Uri.EscapeDataString(oauth_consumer_secret),
        //                            "&", Uri.EscapeDataString(oauth_token_secret));

        //    string oauth_signature;
        //    using (HMACSHA1 hasher = new HMACSHA1(ASCIIEncoding.ASCII.GetBytes(compositeKey)))
        //    {
        //        oauth_signature = Convert.ToBase64String(
        //            hasher.ComputeHash(ASCIIEncoding.ASCII.GetBytes(baseString)));
        //    }

        //    // create the request header
        //    var headerFormat = "OAuth oauth_consumer_key=\"{0}\", oauth_nonce=\"{1}\", oauth_signature=\"{2}\", oauth_signature_method=\"{3}\", oauth_timestamp=\"{4}\", oauth_token=\"{5}\", oauth_version=\"{6}\"";

        //    var authHeader = string.Format(headerFormat,
        //                            Uri.EscapeDataString(oauth_consumer_key),
        //                            Uri.EscapeDataString(oauth_nonce),
        //                            Uri.EscapeDataString(oauth_signature),
        //                            Uri.EscapeDataString(oauth_signature_method),
        //                            Uri.EscapeDataString(oauth_timestamp),
        //                            Uri.EscapeDataString(oauth_token),
        //                            Uri.EscapeDataString(oauth_version)
        //                    );


        //    // make the request

        //    ServicePointManager.Expect100Continue = false;
        //    resource_url += "?" + postdata;
        //    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(resource_url);
        //    request.Headers.Add("Authorization", authHeader);
        //    request.Method = "POST";
        //    return request;
        //}
    }
}