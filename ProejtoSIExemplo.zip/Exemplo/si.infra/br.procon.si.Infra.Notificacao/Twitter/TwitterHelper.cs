﻿using br.procon.si.Infra.Notificacao.Common.Base;
using br.procon.si.Infra.Notificacao.Twitter.Base;
using br.procon.si.Infra.Notificacao.Twitter.Objects;
using System;
using System.Collections.Generic;
using br.procon.si.Core.Domain.ValueObjects;

namespace br.procon.si.Infra.Notificacao.Twitter
{
    public class TwitterHelper : IDisposable
    {
        private TwitterManager manager = new TwitterManager();

        private Dictionary<TwitterEndpoints, TwitterRequest> EndPoints { get; set; }

        public string AppConsumerKey { get; private set; }

        public string AppSecret { get; set; }

        public TwitterHelper(string appConsumerKey, string appSecret)
        {
            this.AppConsumerKey = appConsumerKey;
            this.AppSecret = appSecret;

            EndPoints = new Dictionary<TwitterEndpoints, TwitterRequest>
            {
                {TwitterEndpoints.AccessToken, new TwitterRequest {Caminho = "oauth/authorize"}},
                {TwitterEndpoints.VerifyCredentials, new TwitterRequest {Caminho = "account/verify_credentials.json"}},
                {TwitterEndpoints.Tweet, new TwitterRequest {Caminho = "statuses/update.json"}}
            };
        }

        public BaseObject Tuitar(string userId, TwitterAccessToken accessTokenUsuario, string texto, string url)
        {
            var request = EndPoints[TwitterEndpoints.Tweet];
            request.UserId = userId;
            request.Token = accessTokenUsuario;

            var postagem = new TwitterPostagem { Mensagem = texto.RemoverTagsHtml() };
            var postData = postagem.GetPostData();

            BaseObject response = manager.EnviarDados<TwitterBaseObject>(AppConsumerKey, AppSecret, request, postData);

            return response;
        }

        public BaseObject VerificarCredenciais(string userId, TwitterAccessToken accessTokenUsuario)
        {
            var request = EndPoints[TwitterEndpoints.Tweet];
            request.UserId = userId;
            request.Token = accessTokenUsuario;

            var postagem = new TwitterPostagem();
            var postData = postagem.GetPostData();

            BaseObject response = manager.EnviarDados<TwitterBaseObject>(AppConsumerKey, AppSecret, request, postData);

            return response;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        ~TwitterHelper()
        {
            Dispose(false);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposing) return;

            if (manager == null) return;

            manager.Dispose();
            manager = null;
        }
    }
}