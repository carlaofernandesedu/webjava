﻿using br.procon.si.Core.Data.ADO;
using br.procon.si.Core.Domain.Interfaces;
using br.procon.si.Core.Infra.Interfaces;
using br.procon.si.Infra.Notificacao.Common;
using br.procon.si.Infra.Notificacao.Twitter;
using br.procon.si.Infra.Notificacao.Twitter.Objects;
using System;
using System.Linq;

namespace br.procon.si.Infra.Notificacao
{
    public class TwitterNotificacaoService : INotificacaoProviderService, IDisposable
    {
        private DataHelperUnitOfWork _unidadeDeTrabalho;
        private TwitterHelper _helper;

        public TwitterNotificacaoService(string connectionString, string appConsumerKey, string appSecret)
        {
            _unidadeDeTrabalho = new DataHelperUnitOfWork(connectionString);

            _helper = new TwitterHelper(appConsumerKey, appSecret);
        }

        public TwitterNotificacaoService(IUnitOfWork unidadeDeTrabalho, string appConsumerKey, string appSecret)
        {
            _unidadeDeTrabalho = (DataHelperUnitOfWork)unidadeDeTrabalho;

            _helper = new TwitterHelper(appConsumerKey, appSecret);
        }

        public void Enviar(string destinatario, string mensagem, string url)
        {
            if (!destinatario.Contains("@"))
            {
                var tokens = ObterAccessToken(destinatario);

                if (tokens != null)
                {
                    _helper.Tuitar(destinatario, tokens, mensagem, url);
                }
            }
            else
            {
                throw new Exception(String.Format("Notificação por Twitter Incorreta: {0} - {1} - {2}", destinatario, mensagem, url));
            }
        }

        private TwitterAccessToken ObterAccessToken(string providerKey)
        {
            const string sql = "atendimento.pr_userclaim_identity_consultar";

            var paramIdNotificacao = DataHelperParameters.CreateParameter("@providerKey", providerKey);

            var retornoBD = _unidadeDeTrabalho.List<ClaimsVO>(sql, paramIdNotificacao);

            var resultado = new TwitterAccessToken();

            var accessToken = retornoBD.FirstOrDefault(x => x.ClaimType == "urn:tokens:twitter:accesstoken");
            var accessTokenSecret = retornoBD.FirstOrDefault(x => x.ClaimType == "urn:tokens:twitter:accesstokensecret");

            resultado.AccessToken = accessToken != null ? accessToken.ClaimValue : null;
            resultado.AccessTokenSecret = accessTokenSecret != null ? accessTokenSecret.ClaimValue : null;

            return accessTokenSecret != null && accessToken != null && (accessToken.ClaimValue == null || accessTokenSecret.ClaimValue == null) ? null : resultado;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        ~TwitterNotificacaoService()
        {
            Dispose(false);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_unidadeDeTrabalho != null)
                {
                    _unidadeDeTrabalho.Dispose();
                    _unidadeDeTrabalho = null;
                }

                if (_helper != null)
                {
                    _helper.Dispose();
                    _helper = null;
                }
            }
        }
    }
}