﻿using br.procon.si.Infra.Notificacao.Common.Base;
using System.Runtime.Serialization;

namespace br.procon.si.Infra.Notificacao.Twitter.Base
{
    [DataContract]
    public class TwitterBaseObject : BaseObject
    {
        [DataMember(Name = "id_str", IsRequired = false, EmitDefaultValue = true)]
        public string IdStr { get; set; }
    }
}