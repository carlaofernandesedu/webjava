﻿using Microsoft.Owin;
using Microsoft.Owin.Logging;
using Owin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Core.Infra.Identity
{
    public class MyCustomMiddleware : OwinMiddleware
    {
        //private readonly ILogger _logger;

        public MyCustomMiddleware(OwinMiddleware next, IAppBuilder app)
            : base(next)
        {
            //_logger = app.CreateLogger<MyCustomMiddleware>();
        }

        public async override Task Invoke(IOwinContext context)
        {
            //_logger.WriteVerbose(string.Format("{0} {1}: {2}", context.Request.Scheme, context.Request.Method, context.Request.Path));

            await Next.Invoke(context);
        }
    }
}
