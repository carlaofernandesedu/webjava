﻿using br.procon.si.Core.Infra.Identity.Models;
using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace br.procon.si.Core.Infra.Identity.Configuration
{
    public class ConsumidorUserValidator<TUser> : UserValidator<TUser, int> where TUser : ApplicationUser
    {
        private UserManager<TUser, int> Manager { get; set; }

        public ConsumidorUserValidator(UserManager<TUser, int> manager)
            : base(manager)
        {
            this.Manager = manager;
        }

        public override async Task<IdentityResult> ValidateAsync(TUser item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }
            var errors = new List<string>();

            await ValidateUserName(item, errors);

            if (errors.Count > 0)
            {
                return IdentityResult.Failed(errors.ToArray());
            }

            return IdentityResult.Success;
        }

        private async Task ValidateUserName(TUser user, List<string> errors)
        {
            try
            {
                var m = new MailAddress(user.Email);
            }
            catch (FormatException)
            {
                errors.Add("O nome de usuário deve ser um email.");
                return;
            }

            if (string.IsNullOrWhiteSpace(user.UserName))
            {
                errors.Add("Nome de usuário muito pequeno.");
            }
            else if (AllowOnlyAlphanumericUserNames && !Regex.IsMatch(user.UserName, @"^[A-Za-z0-9@_\.]+$"))
            {
                // If any characters are not letters or digits, its an illegal user name
                errors.Add("Nome de usuário inválido.");
            }
            else
            {
                var owner = await Manager.FindByNameAsync(user.UserName);
                if (owner != null && !EqualityComparer<int>.Default.Equals(owner.Id, user.Id))
                {
                    errors.Add("Esse nome de usuário já existe.");
                }
            }
        }
    }
}
