﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using br.procon.si.Core.Infra.Identity.Models;
using br.procon.si.Core.Infra.Identity.Stores;
using br.procon.si.Core.Infra.Identity.Context;
using Microsoft.Owin;

namespace br.procon.si.Core.Infra.Identity.Configuration
{
    public class ApplicationRoleManager : RoleManager<IdentityRole,int>
    {
        public ApplicationRoleManager(IRoleStore<IdentityRole, int> roleStore)
            : base(roleStore)
        {
        }

        public static ApplicationRoleManager Create(IdentityFactoryOptions<ApplicationRoleManager> options, IOwinContext context)
        {
            return new ApplicationRoleManager(new RoleStore<IdentityRole>(context.Get<ApplicationDbContext>()));
        }
    }
}
