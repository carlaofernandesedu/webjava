﻿using System.Threading.Tasks;
using Microsoft.AspNet.Identity.Owin;
using br.procon.si.Core.Infra.Identity.Models;
using Microsoft.Owin.Security;
using System.Security.Claims;
using Microsoft.Owin;
namespace br.procon.si.Core.Infra.Identity.Configuration
{
    public class ConsumidorSignInManager : SignInManager<ApplicationUser, int>
    {
        public ConsumidorSignInManager(ApplicationUserManager userManager, IAuthenticationManager authenticationManager)
            : base(userManager, authenticationManager)
        {
        }
        public override async Task<ClaimsIdentity> CreateUserIdentityAsync(ApplicationUser user)
        {
            var claimIdentity = await base.CreateUserIdentityAsync(user);

            return claimIdentity; 
        }
        public static ConsumidorSignInManager Create(IdentityFactoryOptions<ConsumidorSignInManager> options, IOwinContext context)
        {
            return new ConsumidorSignInManager(context.GetUserManager<ApplicationUserManager>(), context.Authentication);
        }
    }
}
