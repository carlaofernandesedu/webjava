﻿using br.procon.si.Core.Infra.Identity.Context;
using br.procon.si.Core.Infra.Identity.Models;
using br.procon.si.Core.Infra.Identity.Stores;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin;
using Microsoft.AspNet.Identity;
using System;

namespace br.procon.si.Core.Infra.Identity.Configuration
{
    public static class ConsumidorIdentityConfigRules
    {
        public static ApplicationUserManager CreateAppUserManager(IdentityFactoryOptions<ApplicationUserManager> options,
            IOwinContext context)
        {
            var manager = new ApplicationUserManager(new UserStore<ApplicationUser>(context.Get<ApplicationDbContext>()));

            // Configurando validator para nome de usuario
            manager.UserValidator = new UserValidator<ApplicationUser, int>(manager)
            {
                AllowOnlyAlphanumericUserNames = false,
                RequireUniqueEmail = true
            };

            // Logica de validação e complexidade de senha
            manager.PasswordValidator = new PasswordValidator
            {
                RequiredLength = 6,
                RequireNonLetterOrDigit = false,
                RequireDigit = false,
                RequireLowercase = false,
                RequireUppercase = false,
            };

            // Configuração de Lockout
            //manager.UserLockoutEnabledByDefault = true;
            //manager.DefaultAccountLockoutTimeSpan = TimeSpan.FromMinutes(5);
            //manager.MaxFailedAccessAttemptsBeforeLockout = 5;

            // Providers de Two Factor Autentication
            //RegisterTwoFactorProvider("Código via SMS", new PhoneNumberTokenProvider<ApplicationUser>
            //{
            //    MessageFormat = "Seu código de segurança é: {0}"
            //});

            //RegisterTwoFactorProvider("Código via E-mail", new EmailTokenProvider<ApplicationUser>
            //{
            //    Subject = "Código de Segurança",
            //    BodyFormat = "Seu código de segurança é: {0}"
            //});

            //// Definindo a classe de serviço de e-mail
            //EmailService = new EmailService();

            //// Definindo a classe de serviço de SMS
            //SmsService = new SmsService();

            //var provider = new DpapiDataProtectionProvider("Eduardo");
            //var dataProtector = provider.Create("ASP.NET Identity");

            //UserTokenProvider = new DataProtectorTokenProvider<ApplicationUser>(dataProtector);

            return manager;
        }
    }
}
