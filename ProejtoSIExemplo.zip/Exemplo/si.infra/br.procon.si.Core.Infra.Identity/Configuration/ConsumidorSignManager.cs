﻿using System.Threading.Tasks;
using Microsoft.AspNet.Identity.Owin;
using br.procon.si.Core.Infra.Identity.Models;
using Microsoft.Owin.Security;
using System.Security.Claims;
using Microsoft.Owin;
namespace br.procon.si.Core.Infra.Identity.Configuration
{
    public class ConsumidorSignManager : SignInManager<ApplicationUser, int>
    {
        public ConsumidorSignManager(ApplicationUserManager userManager, IAuthenticationManager authenticationManager)
            : base(userManager, authenticationManager)
        {
        }
        public override async Task<ClaimsIdentity> CreateUserIdentityAsync(ApplicationUser user)
        {
            var claimIdentity = await base.CreateUserIdentityAsync(user);
            claimIdentity.AddClaim(new Claim("UserId", user.Id.ToString()));
            claimIdentity.AddClaim(new Claim("ChaveDeAcesso", user.UserName));

            string role = "Usuario";
            if (user.UserName == "fonseca")
                role = "Administrador";

            claimIdentity.AddClaim(new Claim(ClaimTypes.Role, role));

            return claimIdentity; 
        }
        public static ConsumidorSignManager Create(IdentityFactoryOptions<ConsumidorSignManager> options, IOwinContext context)
        {
            return new ConsumidorSignManager(context.GetUserManager<ApplicationUserManager>(), context.Authentication);
        }
    }
}
