﻿using br.procon.si.Core.Infra.Identity.Context;
using br.procon.si.Core.Infra.Identity.Models;
using br.procon.si.Core.Infra.Identity.Stores;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin;
using System;
using System.Configuration;
using System.Net.Configuration;
using Microsoft.Owin.Security.DataProtection;
using br.procon.si.Infra.Email;

namespace br.procon.si.Core.Infra.Identity.Configuration
{
    public static class ConsumidorUserManager
    {
        //TODO [TIME] Rever parametrizacoes de acordo com o Consumidor - conversar com a Equipe Prodesp
        public static ApplicationUserManager Create(IdentityFactoryOptions<ApplicationUserManager> options,
            IOwinContext context)
        {
            var manager = new ApplicationUserManager(new UserStore<ApplicationUser>(context.Get<ApplicationDbContext>()));

            manager.UserLockoutEnabledByDefault = true;
            manager.DefaultAccountLockoutTimeSpan = TimeSpan.FromHours(24);
            manager.MaxFailedAccessAttemptsBeforeLockout = 3;

            var provider = new DpapiDataProtectionProvider("Consumidor"); 
            var dataProtector = provider.Create("ASP.NET Identity");
            manager.UserTokenProvider = new DataProtectorTokenProvider<ApplicationUser,int>(dataProtector);

            manager.EmailService =new EmailService((SmtpSection)ConfigurationManager.GetSection("system.net/mailSettings/smtp"));

            manager.UserValidator = new ConsumidorUserValidator<ApplicationUser>(manager)
            {
                AllowOnlyAlphanumericUserNames = false,
                RequireUniqueEmail = true
            };

            return manager;

        }
    }
}
