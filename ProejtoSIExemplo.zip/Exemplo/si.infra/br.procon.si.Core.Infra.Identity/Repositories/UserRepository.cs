﻿using System;
using System.Collections.Generic;
using br.procon.si.Core.Infra.Identity.Models;
using br.procon.si.Core.Infra.Identity.Interfaces;
using br.procon.si.Core.Data.ADO;
using br.procon.si.Core.Infra.Identity.Context;
using System.Linq;
using br.procon.si.Core.Domain.Events;

namespace br.procon.si.Core.Infra.Identity.Repositories
{
    /// <summary>
    /// Class that represents the Users table in the Database
    /// </summary>
    public class UserRepository<TUser> : IUserRepository<TUser>
        where TUser : IdentityUser, new()
    {
        private DataHelperUnitOfWork _database;
        private readonly string _schema;

        /// <summary>
        /// Constructor that takes a DataHelperUnitOfWork instance 
        /// </summary>
        /// <param name="database"></param>
        public UserRepository(DataHelperUnitOfWork database)
        {
            _database = database;
            _schema = ((ApplicationDbContext)database).Schema;
        }

        /// <summary>
        /// Returns the user's name given a user id
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public string GetUserName(int userId)
        {
            var retorno = GetUserById(userId);
            return retorno != null ? retorno.UserName : String.Empty;
        }

        /// <summary>
        /// Returns a User ID given a user name
        /// </summary>
        /// <param name="userName">The user's name</param>
        /// <returns></returns>
        public int GetUserId(string userName)
        {
            var parametros = new TUser();
            parametros.UserName = userName;
            var retorno = GetUser(parametros).FirstOrDefault();
            return retorno != null ? retorno.Id : 0;
        }

        /// <summary>
        /// Returns an TUser given the user's id
        /// </summary>
        /// <param name="userId">The user's id</param>
        /// <returns></returns>
        public TUser GetUserById(int userId)
        {
            var parametros = new TUser();
            parametros.Id = userId;
            return GetUser(parametros).FirstOrDefault();
        }

        private List<TUser> GetUser(TUser user)
        {
            DomainEvent.Raise<AcaoRegistradaEvent>(new AcaoRegistradaEvent(1, "Mantis2353: GetUser(TUser user)"));

            var _proc = String.Concat(_schema, ".", "pr_user_identity_consultar");
            var retorno = _database.List<TUser>(_proc,
                 DataHelperParameters.CreateParameter("@ds_login", user.UserName),
                  DataHelperParameters.CreateParameter("@id_usuario", user.Id),
                   DataHelperParameters.CreateParameter("@ds_email", user.Email)
                 );
            return retorno.ToList<TUser>();
        }

        /// <summary>
        /// Returns a list of TUser instances given a user name
        /// </summary>
        /// <param name="userName">User's name</param>
        /// <returns></returns>
        public List<TUser> GetUserByName(string userName)
        {
            //List<TUser> users = new List<TUser>();
            //    TUser user = (TUser)Activator.CreateInstance(typeof(TUser));
            //    user.Id = Convert.ToInt32(row["Id"]);
            var parametros = new TUser();
            parametros.UserName = userName;
            return GetUser(parametros);
        }

        public List<TUser> GetUserByEmail(string email)
        {
            var parametros = new TUser();
            parametros.Email = email;
            return GetUser(parametros);
        }

        /// <summary>
        /// Return the user's password hash
        /// </summary>
        /// <param name="userId">The user's id</param>
        /// <returns></returns>
        public string GetPasswordHash(int userId)
        {
            var retorno = GetUserById(userId);
            return retorno != null ? retorno.PasswordHash : String.Empty;
        }

        /// <summary>
        /// Sets the user's password hash
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="passwordHash"></param>
        /// <returns></returns>
        public int SetPasswordHash(int userId, string passwordHash)
        {
            var _proc = String.Concat(_schema,".", "pr_user_identity_alterar_senha");
            return _database.Get<int>(_proc,
                DataHelperParameters.CreateParameter("@id_usuario", userId),
                DataHelperParameters.CreateParameter("@ds_senha", passwordHash));

        }

        /// <summary>
        /// Returns the user's security stamp
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public string GetSecurityStamp(int userId)
        {
            var retorno = GetUserById(userId);
            return  retorno != null ? retorno.SecurityStamp : String.Empty;
        }

        /// <summary>
        /// Inserts a new user in the Users table
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public int Insert(TUser user)
        {
            var _proc = String.Concat(_schema, ".", "pr_user_identity_incluir");
            return _database.Get<int>(_proc,
                 DataHelperParameters.CreateParameter("@guid_usuario", user.GlobalId),
                 DataHelperParameters.CreateParameter("@ds_email", user.Email),
                 DataHelperParameters.CreateParameter("@bl_email_confirmado", user.EmailConfirmed),
                 DataHelperParameters.CreateParameter("@ds_login", user.UserName),
                 DataHelperParameters.CreateParameter("@ds_senha", user.PasswordHash),
                 DataHelperParameters.CreateParameter("@securitystamp", user.SecurityStamp),
                 DataHelperParameters.CreateParameter("@lockoutenabled", user.LockoutEnabled),
                 DataHelperParameters.CreateParameter("@lockoutenddateutc", user.LockoutEndDateUtc),
                 DataHelperParameters.CreateParameter("@twofactorenabled", user.TwoFactorEnabled),
                 DataHelperParameters.CreateParameter("@nr_tentativa_login_invalidas", user.AccessFailedCount),
                 //DataHelperParameters.CreateParameter("@bl_bloqueado", user.IsBlocked),
                 //DataHelperParameters.CreateParameter("@ds_token", user.SecurityStamp),
                 DataHelperParameters.CreateParameter("@ds_telefone", user.PhoneNumber),
                 DataHelperParameters.CreateParameter("@bl_ativo", true),
                 DataHelperParameters.CreateParameter("@dt_criacao", DateTime.Now),
                 DataHelperParameters.CreateParameter("@id_usuario_criacao", user.UserLoggedId),
                 DataHelperParameters.CreateParameter("@no_usuario",user.Name));
        }

        /// <summary>
        /// Deletes a user from the Users table
        /// </summary>
        /// <param name="userId">The user's id</param>
        /// <returns></returns>
        private int Delete(int userId)
        {
            var _proc = String.Concat(_schema, ".", "pr_user_identity_alterar_status");
            return _database.Get<int>(_proc,
                DataHelperParameters.CreateParameter("@id_usuario", userId),
                DataHelperParameters.CreateParameter("@bl_ativo", false));
        }

        /// <summary>
        /// Deletes a user from the Users table
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public int Delete(TUser user)
        {
            return Delete(user.Id);
        }

        /// <summary>
        /// Updates a user in the Users table
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public int Update(TUser user)
        {
            var _proc = String.Concat(_schema, ".", "pr_user_identity_alterar");
            return _database.Get<int>(_proc,
                 DataHelperParameters.CreateParameter("@id_usuario", user.Id),
                 DataHelperParameters.CreateParameter("@ds_email", user.Email),
                 DataHelperParameters.CreateParameter("@bl_email_confirmado", user.EmailConfirmed),
                 DataHelperParameters.CreateParameter("@ds_login", user.UserName),
                 DataHelperParameters.CreateParameter("@ds_senha", user.PasswordHash),
                 DataHelperParameters.CreateParameter("@securitystamp", user.SecurityStamp),
                 DataHelperParameters.CreateParameter("@lockoutenabled", user.LockoutEnabled),
                 DataHelperParameters.CreateParameter("@lockoutenddateutc", user.LockoutEndDateUtc),
                 DataHelperParameters.CreateParameter("@twofactorenabled", user.TwoFactorEnabled),
                 DataHelperParameters.CreateParameter("@nr_tentativa_login_invalidas", user.AccessFailedCount),
                 //DataHelperParameters.CreateParameter("@bl_bloqueado", user.IsBlocked),
                 DataHelperParameters.CreateParameter("@ds_telefone", user.PhoneNumber),
                 DataHelperParameters.CreateParameter("@bl_ativo", user.IsActive),
                 DataHelperParameters.CreateParameter("@dt_alteracao", DateTime.Now),
                 DataHelperParameters.CreateParameter("@id_usuario_alteracao", user.UserLoggedId)
                 );
        }
    }
}
