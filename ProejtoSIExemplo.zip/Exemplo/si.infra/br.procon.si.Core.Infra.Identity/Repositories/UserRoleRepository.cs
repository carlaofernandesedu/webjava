﻿using System.Collections.Generic;
using br.procon.si.Core.Infra.Identity.Models;
using br.procon.si.Core.Infra.Identity.Interfaces;
using br.procon.si.Core.Data.ADO;
using br.procon.si.Core.Infra.Identity.Context;
using System;
using System.Linq;

namespace br.procon.si.Core.Infra.Identity.Repositories
{
    /// <summary>
    /// Class that represents the UserRoles table in the Database
    /// </summary>
    public class UserRolesRepository : IUserRolesRepository
    {
        private DataHelperUnitOfWork _database;
        private string  _proc;
        private string _schema;

        /// <summary>
        /// Constructor that takes a MySQLDatabase instance 
        /// </summary>
        /// <param name="database"></param>
        public UserRolesRepository(DataHelperUnitOfWork database)
        {
            _database = database;
            _schema = ((ApplicationDbContext)database).Schema;
        }

        /// <summary>
        /// Returns a list of user's roles
        /// </summary>
        /// <param name="userId">The user's id</param>
        /// <returns></returns>
        public List<string> FindByUserId(int userId)
        {
            List<string> retorno = null;
            _proc = String.Concat(_schema, ".", "pr_userrole_identity_consultar");
            var rows = _database.List<IdentityRole>(_proc,
                DataHelperParameters.CreateParameter("@id_usuario", userId));
            if (rows != null)
            {
                retorno = new List<string>(rows.Count());
                foreach (var item in rows) { retorno.Add(item.Name); }
            }

            return retorno;

        }

        /// <summary>
        /// Deletes all roles from a user in the UserRoles table
        /// </summary>
        /// <param name="userId">The user's id</param>
        /// <returns></returns>
        public int Delete(int userId)
        {
            _proc = String.Concat(_schema, ".", "pr_userrole_excluir");
            return _database.Get<int>(_proc,
                DataHelperParameters.CreateParameter("@id_usuario", userId));

        }

        /// <summary>
        /// Inserts a new role for a user in the UserRoles table
        /// </summary>
        /// <param name="user">The User</param>
        /// <param name="roleId">The Role's id</param>
        /// <returns></returns>
        public int Insert(IdentityUser user, int roleId)
        {
            _proc = String.Concat(_schema, ".", "pr_userrole_incluir");
            return _database.Get<int>(_proc,
                DataHelperParameters.CreateParameter("@id_usuario", user.Id),
                DataHelperParameters.CreateParameter("@id_role", roleId));
        }
    }
}
