﻿using Microsoft.AspNet.Identity;
using System.Collections.Generic;
using br.procon.si.Core.Infra.Identity.Models;
using br.procon.si.Core.Infra.Identity.Interfaces;
using br.procon.si.Core.Data.ADO;
using br.procon.si.Core.Infra.Identity.Context;
using System;
using System.Linq;

namespace br.procon.si.Core.Infra.Identity.Repositories
{
    /// <summary>
    /// Class that represents the UserLogins table in the Database
    /// </summary>
    public class UserLoginsRepository : IUserLoginsRepository
    {
        private DataHelperUnitOfWork _database;
        private string _schema;
        private string _proc;

        /// <summary>
        /// Constructor that takes a instance 
        /// </summary>
        /// <param name="database"></param>
        public UserLoginsRepository(DataHelperUnitOfWork database)
        {
            _database = database;
            _schema = ((ApplicationDbContext)database).Schema;
        }

        /// <summary>
        /// Deletes a login from a user in the UserLogins table
        /// </summary>
        /// <param name="user">User to have login deleted</param>
        /// <param name="login">Login to be deleted from user</param>
        /// <returns></returns>
        public int Delete(IdentityUser user, UserLoginInfo login)
        {
            _proc = String.Concat(_schema, ".", "pr_userlogin_excluir");
            return _database.Get<int>(_proc,
                DataHelperParameters.CreateParameter("@id_usuario", user.Id),
                 DataHelperParameters.CreateParameter("@loginprovider", login.LoginProvider),
                  DataHelperParameters.CreateParameter("@providerkey", login.ProviderKey));
        }

        /// <summary>
        /// Deletes all Logins from a user in the UserLogins table
        /// </summary>
        /// <param name="userId">The user's id</param>
        /// <returns></returns>
        public int Delete(int userId)
        {
            _proc = String.Concat(_schema, ".", "pr_userlogin_excluir");
            return _database.Get<int>(_proc,
                DataHelperParameters.CreateParameter("@id_usuario", userId));
        }

        /// <summary>
        /// Inserts a new login in the UserLogins table
        /// </summary>
        /// <param name="user">User to have new login added</param>
        /// <param name="login">Login to be added</param>
        /// <returns></returns>
        public int Insert(IdentityUser user, UserLoginInfo login)
        {
            _proc = String.Concat(_schema, ".", "pr_userlogin_incluir");
            return _database.Get<int>(_proc,
                DataHelperParameters.CreateParameter("@id_usuario", user.Id),
                 DataHelperParameters.CreateParameter("@loginprovider", login.LoginProvider),
                  DataHelperParameters.CreateParameter("@providerkey", login.ProviderKey));
        }

        /// <summary>
        /// Return a userId given a user's login
        /// </summary>
        /// <param name="userLogin">The user's login info</param>
        /// <returns></returns>
        public int FindUserIdByLogin(UserLoginInfo userLogin)
        {
            var row = Find(new UserLoginVO() { LoginProvider = userLogin.LoginProvider, ProviderKey = userLogin.ProviderKey}).FirstOrDefault();
            return row != null ? row.Id_Usuario.Value : 0;
        }
        /// <summary>
        /// Returns a list of user's logins
        /// </summary>
        /// <param name="userId">The user's id</param>
        /// <returns></returns>
        public List<UserLoginInfo> FindByUserId(int userId)
        {
            List<UserLoginInfo> retorno = null;
            var rows = Find(new UserLoginVO() { Id_Usuario = userId });
            if (rows != null)
            {
                retorno = new List<UserLoginInfo>(rows.Count());
                foreach (var item in rows)
                {
                    retorno.Add(new UserLoginInfo(item.LoginProvider, item.ProviderKey));
                }
            }
            return retorno;
        }

        private List<UserLoginVO> Find(UserLoginVO param)
        {
            _proc = String.Concat(_schema, ".", "pr_userlogin_consultar");
            return _database.List<UserLoginVO>(_proc,
                  DataHelperParameters.CreateParameter("@id_usuario", param.Id_Usuario),
                  DataHelperParameters.CreateParameter("@loginprovider", param.LoginProvider),
                  DataHelperParameters.CreateParameter("@providerkey", param.ProviderKey)).ToList();
        }
    }
}
