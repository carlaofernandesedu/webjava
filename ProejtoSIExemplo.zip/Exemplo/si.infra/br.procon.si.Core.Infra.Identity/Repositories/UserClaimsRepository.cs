﻿using System.Collections.Generic;
using System.Security.Claims;
using br.procon.si.Core.Infra.Identity.Models;
using br.procon.si.Core.Infra.Identity.Interfaces;
using br.procon.si.Core.Data.ADO;
using System;
using br.procon.si.Core.Infra.Identity.Context;

namespace br.procon.si.Core.Infra.Identity.Repositories
{
    /// <summary>
    /// Class that represents the UserClaims table in the Database
    /// </summary>
    public class UserClaimsRepository : IUserClaimsRepository
    {
        private DataHelperUnitOfWork _database;
        private object _schema;
        private string _proc;

        /// <summary>
        /// Constructor that takes a DataHelperUnitOfWork instance 
        /// </summary>
        /// <param name="database"></param>
        public UserClaimsRepository(DataHelperUnitOfWork database)
        {
            _database = database;
            _schema = ((ApplicationDbContext)database).Schema;
        }

        /// <summary>
        /// Returns a ClaimsIdentity instance given a userId
        /// </summary>
        /// <param name="userId">The user's id</param>
        /// <returns></returns>
        public ClaimsIdentity FindByUserId(int userId)
        {
            ClaimsIdentity claims = null;
            _proc = String.Concat(_schema, ".", "pr_userclaim_identity_consultar");
            var claimsvo = _database.List<ClaimIdentityVO>(_proc,
                DataHelperParameters.CreateParameter("@id_usuario", userId));
            if (claimsvo != null)
            {
                claims = new ClaimsIdentity();
                foreach (var item in claimsvo)
                {
                    Claim claim = new Claim(item.ClaimType,item.ClaimValue);
                    claims.AddClaim(claim);
                }
            }
            return claims;
        }

        /// <summary>
        /// Deletes all claims from a user given a userId
        /// </summary>
        /// <param name="userId">The user's id</param>
        /// <returns></returns>
        public int Delete(int userId)
        {
            _proc = String.Concat(_schema, ".", "pr_userclaim_identity_excluir");
            return _database.Get<int>(_proc,
                DataHelperParameters.CreateParameter("@id_usuario", userId));
        }

        /// <summary>
        /// Inserts a new claim in UserClaims table
        /// </summary>
        /// <param name="userClaim">User's claim to be added</param>
        /// <param name="userId">User's id</param>
        /// <returns></returns>
        public int Insert(Claim userClaim, int userId)
        {
            _proc = String.Concat(_schema, ".", "pr_userclaim_identity_incluir");
            return _database.Get<int>(_proc,
                DataHelperParameters.CreateParameter("@id_usuario", userId),
                 DataHelperParameters.CreateParameter("@claimtype", userClaim.Type),
                  DataHelperParameters.CreateParameter("@claimvalue", userClaim.Value));
        }

        /// <summary>
        /// Deletes a claim from a user 
        /// </summary>
        /// <param name="user">The user to have a claim deleted</param>
        /// <param name="claim">A claim to be deleted from user</param>
        /// <returns></returns>
        public int Delete(IdentityUser user, Claim claim)
        {
            _proc = String.Concat(_schema, ".", "pr_userclaim_identity_excluir");
            return _database.Get<int>(_proc,
                DataHelperParameters.CreateParameter("@id_usuario", user.Id),
                 DataHelperParameters.CreateParameter("@claimtype", claim.Type),
                  DataHelperParameters.CreateParameter("@claimvalue", claim.Value));
        }
    }
}
