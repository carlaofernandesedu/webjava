﻿using br.procon.si.Core.Infra.Identity.Models;
using System;
using System.Collections.Generic;
using br.procon.si.Core.Infra.Identity.Interfaces;
using br.procon.si.Core.Data.ADO;
using br.procon.si.Core.Infra.Identity.Context;

namespace br.procon.si.Core.Infra.Identity.Repositories
{
    /// <summary>
    /// Class that represents the Role table in the MySQL Database
    /// </summary>
    public class RoleRepository : IRoleRepository
    {
        private DataHelperUnitOfWork _database;
        private string _proc;
        private string _schema;

        /// <summary>
        /// Constructor that takes a MySQLDatabase instance 
        /// </summary>
        /// <param name="database"></param>
        public RoleRepository(DataHelperUnitOfWork database)
        {
            _database = database;
            _schema = ((ApplicationDbContext)database).Schema;
        }

        /// <summary>
        /// Deltes a role from the Roles table
        /// </summary>
        /// <param name="roleId">The role Id</param>
        /// <returns></returns>
        public int Delete(int roleId)
        {
            _proc = String.Concat(_schema,".", "pr_role_excluir");
            return _database.Get<int>(_proc,
                DataHelperParameters.CreateParameter("@id_role", roleId));
        }

        /// <summary>
        /// Inserts a new Role in the Roles table
        /// </summary>
        /// <param name="roleName">The role's name</param>
        /// <returns></returns>
        public int Insert(IdentityRole role)
        {
            _proc = String.Concat(_schema,".", "pr_role_incluir");
            return _database.Get<int>(_proc,
                DataHelperParameters.CreateParameter("@name", role.Name));
        }

        /// <summary>
        /// Returns a role name given the roleId
        /// </summary>
        /// <param name="roleId">The role Id</param>
        /// <returns>Role name</returns>
        public string GetRoleName(int roleId)
        {
            var row = GetRoleById(roleId);
            return row != null ? row.Name : null;
        }

        /// <summary>
        /// Returns the role Id given a role name
        /// </summary>
        /// <param name="roleName">Role's name</param>
        /// <returns>Role's Id</returns>
        public int GetRoleId(string roleName)
        {
            var row = GetRoleByName(roleName);
            return row != null ? row.Id : 0;
        }

        /// <summary>
        /// Gets the IdentityRole given the role Id
        /// </summary>
        /// <param name="roleId"></param>
        /// <returns></returns>
        public IdentityRole GetRoleById(int roleId)
        {
            return GetRole(new IdentityRole() { Id = roleId });
        }

        /// <summary>
        /// Gets the IdentityRole given the role name
        /// </summary>
        /// <param name="roleName"></param>
        /// <returns></returns>
        public IdentityRole GetRoleByName(string roleName)
        {
            return GetRole(new IdentityRole() { Name = roleName });
        }

        private IdentityRole GetRole(IdentityRole role)
        {
            _proc = String.Concat(_schema, ".", "pr_role_selecionar");
            return _database.Get<IdentityRole>(_proc,
                DataHelperParameters.CreateParameter("@id_role", role.Id),
                DataHelperParameters.CreateParameter("@name", role.Name));
        }

        public int Update(IdentityRole role)
        {
            _proc = String.Concat(_schema, ".", "pr_role_alterar");
            return _database.Get<int>(_proc,
                DataHelperParameters.CreateParameter("@id_role", role.Id),
                DataHelperParameters.CreateParameter("@name", role.Name));
        }
    }
}
