﻿using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace br.procon.si.Core.Infra.Identity.Crypto
{
    internal class SICripto : IPasswordHasher
    {
        public string HashPassword(string password)
        {
            try
            {
                var clearBytes = Encoding.Unicode.GetBytes(password);
                var pdb = new System.Security.Cryptography.PasswordDeriveBytes(Hash,
                     new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });

                using (var msCreate = new MemoryStream())
                {
                    System.Security.Cryptography.Rijndael alg = System.Security.Cryptography.Rijndael.Create();
                    // ReSharper disable once CSharpWarnings::CS0618
                    alg.Key = pdb.GetBytes(32);
                    // ReSharper disable once CSharpWarnings::CS0618
                    alg.IV = pdb.GetBytes(16);

                    using (var csCreate = new System.Security.Cryptography.CryptoStream(msCreate,
                       alg.CreateEncryptor(), System.Security.Cryptography.CryptoStreamMode.Write))
                    {
                        csCreate.Write(clearBytes, 0, clearBytes.Length);
                        csCreate.Close();
                        csCreate.Clear();
                        byte[] encryptedData = msCreate.ToArray();

                        return Convert.ToBase64String(encryptedData);
                    }
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        public PasswordVerificationResult VerifyHashedPassword(string hashedPassword, string providedPassword)
        {
            PasswordVerificationResult result = PasswordVerificationResult.Failed;

            if (hashedPassword == null)
            {
                return result;
            }
            if (providedPassword == null)
            {
                throw new ArgumentNullException("password");
            }

            if (Decrypt(hashedPassword) == providedPassword)
                result = PasswordVerificationResult.Success;

            return result;
        }

        private static string Decrypt(string value)
        {
            try
            {
                var cipherBytes = Convert.FromBase64String(value);
                var pdb = new System.Security.Cryptography.PasswordDeriveBytes(Hash,
                  new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });

                using (var ms = new MemoryStream())
                {
                    System.Security.Cryptography.Rijndael alg = System.Security.Cryptography.Rijndael.Create();
                    // ReSharper disable once CSharpWarnings::CS0618
                    alg.Key = pdb.GetBytes(32);
                    // ReSharper disable once CSharpWarnings::CS0618
                    alg.IV = pdb.GetBytes(16);

                    using (var cs = new System.Security.Cryptography.CryptoStream(ms,
                        alg.CreateDecryptor(), System.Security.Cryptography.CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                        byte[] decryptedData = ms.ToArray();

                        return Encoding.Unicode.GetString(decryptedData);
                    }
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static string Hash
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["hash"];
            }
        }
    }
}
