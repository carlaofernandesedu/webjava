﻿using br.procon.si.Core.Infra.Identity.Models;
using System.Collections.Generic;

namespace br.procon.si.Core.Infra.Identity.Interfaces
{
    public interface IUserRepository<TUser>
            where TUser : IdentityUser, new()
    {
        string GetUserName(int userId);
        int GetUserId(string userName);
        TUser GetUserById(int userId);
        List<TUser> GetUserByName(string userName);
        List<TUser> GetUserByEmail(string email);
        string GetPasswordHash(int userId);
        int SetPasswordHash(int userId, string passwordHash);
        string GetSecurityStamp(int userId);
        int Insert(TUser user);
        int Delete(TUser user);
        int Update(TUser user);
    }
}
