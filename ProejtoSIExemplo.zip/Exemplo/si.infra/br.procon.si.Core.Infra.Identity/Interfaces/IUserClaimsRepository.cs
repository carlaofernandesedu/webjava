﻿using br.procon.si.Core.Infra.Identity.Models;
using System.Security.Claims;

namespace br.procon.si.Core.Infra.Identity.Interfaces
{
    public interface IUserClaimsRepository
    {
        ClaimsIdentity FindByUserId(int userId);
        int Delete(int userId);
        int Insert(Claim userClaim, int userId);
        int Delete(IdentityUser user, Claim claim);
    }
}
