﻿using br.procon.si.Core.Infra.Identity.Models;
using System.Collections.Generic;


namespace br.procon.si.Core.Infra.Identity.Interfaces
{
    public interface IUserRolesRepository
    {
        List<string> FindByUserId(int userId);
        int Delete(int userId);
        int Insert(IdentityUser user, int roleId);
    }
}
