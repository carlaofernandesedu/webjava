﻿using br.procon.si.Core.Infra.Identity.Models;
using Microsoft.AspNet.Identity;
using System.Collections.Generic;


namespace br.procon.si.Core.Infra.Identity.Interfaces
{
    public interface IUserLoginsRepository
    {
        int Delete(IdentityUser user, UserLoginInfo login);
        int Delete(int userId);
        int Insert(IdentityUser user, UserLoginInfo login);
        int FindUserIdByLogin(UserLoginInfo userLogin);
        List<UserLoginInfo> FindByUserId(int userId);
    }
}
