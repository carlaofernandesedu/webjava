﻿using br.procon.si.Core.Infra.Identity.Models;

namespace br.procon.si.Core.Infra.Identity.Interfaces
{
    public interface IRoleRepository
    {
        int Delete(int roleId);
        int Insert(IdentityRole role);
        string GetRoleName(int roleId);

        int GetRoleId(string roleName);

        IdentityRole GetRoleById(int roleId);
        IdentityRole GetRoleByName(string roleName);

        int Update(IdentityRole role);
     

    }
}
