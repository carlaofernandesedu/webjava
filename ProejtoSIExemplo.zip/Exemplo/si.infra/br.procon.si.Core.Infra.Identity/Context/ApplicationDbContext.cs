﻿using br.procon.si.Core.Infra.Identity.Repositories;
using br.procon.si.Core.Data.ADO;
using System.Configuration;
using System;

namespace br.procon.si.Core.Infra.Identity.Context
{
    public class ApplicationDbContext : DataHelperUnitOfWork, IDisposable
    {
        public string Schema { get; set; }


        public ApplicationDbContext()
            : base(ConfigurationManager.ConnectionStrings[ConfigurationManager.ConnectionStrings.Count - 1].ConnectionString)
        {
            var schema = ConfigurationManager.AppSettings["IdentitySchema"];
            Schema = string.IsNullOrEmpty(schema) ? "dbo" : schema;
        }

        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }

        public void Dispose()
        {
            base.Dispose();
        }
    }
}