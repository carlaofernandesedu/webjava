﻿using System.ComponentModel.DataAnnotations;

namespace br.procon.si.Core.Infra.Identity.Models
{
    public class ExternalLoginConfirmationViewModel
    {
        [Required(ErrorMessage = "O Nome é obrigatório")]
        [Display(Name = "Nome")]
        public string Nome { get; set; }

        [Required]
        [Display(Name = "Email")]
        public string Email { get; set; }

        public string Provider { get; set; }

        public string ProviderKey { get; set; }

        public bool Registrado { get; set; }
    }
}