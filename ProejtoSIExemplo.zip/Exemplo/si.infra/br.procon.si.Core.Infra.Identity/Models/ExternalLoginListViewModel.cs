﻿namespace br.procon.si.Core.Infra.Identity.Models
{
    public class ExternalLoginListViewModel
    {
        public string ReturnUrl { get; set; }
    }
}