﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace br.procon.si.Core.Infra.Identity.Models
{
    public class ExternalLoginOperationViewModel
    {
        public ApplicationUser User { get; set; }

        public bool Sucesso { get; set; }

        public ExternalLoginOperationViewModel(ApplicationUser user, bool pode)
        {
            this.User = user;
            this.Sucesso = pode;
        }
    }
}
