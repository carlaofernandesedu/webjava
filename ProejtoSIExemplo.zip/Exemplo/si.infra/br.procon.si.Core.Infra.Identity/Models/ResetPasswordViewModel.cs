﻿using System.ComponentModel.DataAnnotations;

namespace br.procon.si.Core.Infra.Identity.Models
{
    public class ResetPasswordViewModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "A senha deve ter no mínimo 6 caracteres. Informe novamente, por favor. ", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "As senha digitada não e igual a anterior. Informe novamente,por favor.")]
        public string ConfirmPassword { get; set; }

        public string Code { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "A senha deve ter no mínimo 6 caracteres. Informe novamente, por favor. ", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string PasswordAtual { get; set; }


    }
}