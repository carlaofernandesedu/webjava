﻿namespace br.procon.si.Core.Infra.Identity.Models
{
    public class FactorViewModel
    {
        public string Purpose { get; set; }
    }
}