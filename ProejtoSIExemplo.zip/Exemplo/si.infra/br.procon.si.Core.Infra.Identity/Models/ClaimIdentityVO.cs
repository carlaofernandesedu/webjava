﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Core.Infra.Identity.Models
{
    public class ClaimIdentityVO
    {
        public ClaimIdentityVO()
        {
                
        }

        [Column("claimtype")]
        public string ClaimType  {get;set;}
        [Column("claimvalue")]
        public string ClaimValue {get;set;}
    }
}
