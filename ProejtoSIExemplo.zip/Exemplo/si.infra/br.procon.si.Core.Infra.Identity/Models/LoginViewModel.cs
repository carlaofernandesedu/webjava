﻿using System.ComponentModel.DataAnnotations;

namespace br.procon.si.Core.Infra.Identity.Models
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "O email é obrigatório.")]
        [Display(Name = "E-mail")]
        [EmailAddress(ErrorMessage = "E-mail inválido! Informe novamente, por favor.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "A senha é necessária.")]
        [DataType(DataType.Password)]
        [Display(Name = "Senha")]
        [StringLength(100, ErrorMessage = "A senha deve ter no mínimo 6 caracteres. Informe novamente, por favor. ", MinimumLength = 6)]
        public string Password { get; set; }

        [Display(Name = "Lembrar-me")]
        public bool RememberMe { get; set; }
    }
}