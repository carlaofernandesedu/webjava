﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Core.Infra.Identity.Models
{
    public class UserLoginVO
    {
        public UserLoginVO()
        {

        }

        [Column("id_usuario")]
        public int? Id_Usuario { get; set;}  
        [Column("ProviderKey")]
        public string ProviderKey { get; set; }
        [Column("LoginProvider")]
        public string LoginProvider { get; set; }
    }
}
