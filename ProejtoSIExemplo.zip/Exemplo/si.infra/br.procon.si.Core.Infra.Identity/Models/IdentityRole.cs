﻿using Microsoft.AspNet.Identity;
using System.ComponentModel.DataAnnotations.Schema;

namespace br.procon.si.Core.Infra.Identity.Models
{
    /// <summary>
    /// Class that implements the ASP.NET Identity
    /// IRole interface 
    /// </summary>
    public class IdentityRole : IRole<int>
    {
        /// <summary>
        /// Default constructor for Role 
        /// </summary>
        public IdentityRole()
        {
            //Id = Guid.NewGuid().ToString();
        }
        /// <summary>
        /// Constructor that takes names as argument 
        /// </summary>
        /// <param name="name"></param>
        public IdentityRole(string name) : this()
        {
            Name = name;
        }

        public IdentityRole(string name, int id)
        {
            Name = name;
            Id = id;
        }

        /// <summary>
        /// Role ID
        /// </summary>
        [Column("id_role")]
        public int Id { get; set; }

        /// <summary>
        /// Role name
        /// </summary>
        [Column("name")]
        public string Name { get; set; }
    }
}
