﻿using System.ComponentModel.DataAnnotations;

namespace br.procon.si.Core.Infra.Identity.Models
{
    public class ForgotPasswordViewModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }
    }
}
