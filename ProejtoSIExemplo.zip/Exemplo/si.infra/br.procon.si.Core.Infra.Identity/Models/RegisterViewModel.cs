using System.ComponentModel.DataAnnotations;

namespace br.procon.si.Core.Infra.Identity.Models
{
    public class RegisterViewModel
    {
        [Required(ErrorMessage = "O Nome � obrigat�rio")]
        [Display(Name = "Nome")]
        public string Nome { get; set; }

        [Required]
        [EmailAddress(ErrorMessage = "E-mail inv�lido! Informe novamente, por favor.")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "A senha deve ter no m�nimo 6 caracteres. Informe novamente, por favor. ", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Senha")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirmar senha")]
        [Compare("Password", ErrorMessage = "As senha digitada n�o e igual a anterior. Informe novamente,por favor.")]
        public string ConfirmPassword { get; set; }
        
       
    }
}